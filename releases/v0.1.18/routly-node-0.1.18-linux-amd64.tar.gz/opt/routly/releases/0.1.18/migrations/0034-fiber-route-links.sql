CREATE TABLE fiber_route_links (
  id serial PRIMARY KEY,
  route_id integer NOT NULL REFERENCES fiber_routes(id) ON DELETE CASCADE,
  vertex_index integer NOT NULL CHECK (vertex_index >= 0),
  node_id integer REFERENCES fiber_nodes(id) ON DELETE CASCADE,
  nap_box_id integer REFERENCES nap_boxes(id) ON DELETE CASCADE,
  CONSTRAINT fiber_route_links_target_check CHECK ((node_id IS NOT NULL) <> (nap_box_id IS NOT NULL))
);
CREATE UNIQUE INDEX fiber_route_links_route_vertex_uq ON fiber_route_links(route_id, vertex_index);
CREATE INDEX fiber_route_links_node_idx ON fiber_route_links(node_id);
CREATE INDEX fiber_route_links_nap_idx ON fiber_route_links(nap_box_id);