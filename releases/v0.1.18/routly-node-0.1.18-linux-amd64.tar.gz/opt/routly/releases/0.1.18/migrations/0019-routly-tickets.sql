CREATE TABLE IF NOT EXISTS tickets (
  id serial PRIMARY KEY,
  department text NOT NULL,
  requester text NOT NULL,
  subject text NOT NULL,
  description text NOT NULL,
  technician text,
  created_at timestamptz NOT NULL DEFAULT now(),
  location_id integer REFERENCES locations(id) ON DELETE SET NULL,
  opened_by text NOT NULL,
  last_reply_at timestamptz,
  status text NOT NULL DEFAULT 'open'
);

CREATE INDEX IF NOT EXISTS tickets_status_idx ON tickets(status);
CREATE INDEX IF NOT EXISTS tickets_created_at_idx ON tickets(created_at);

CREATE TABLE IF NOT EXISTS ticket_replies (
  id serial PRIMARY KEY,
  ticket_id integer NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  message text NOT NULL,
  author text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ticket_replies_ticket_created_at_idx
  ON ticket_replies(ticket_id, created_at);