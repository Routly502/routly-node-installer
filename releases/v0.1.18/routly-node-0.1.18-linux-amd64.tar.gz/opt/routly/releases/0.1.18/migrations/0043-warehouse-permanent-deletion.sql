-- Product deletion explicitly removes its entire movement history.
-- Keep ordinary movement edits/deletes forbidden; permit parent cascades.
DO $migration$
DECLARE
  constraint_name text;
BEGIN
  FOR constraint_name IN
    SELECT conname FROM pg_constraint
    WHERE conrelid = 'warehouse_stock_movements'::regclass
      AND confrelid = 'warehouse_products'::regclass AND contype = 'f'
  LOOP
    EXECUTE format('ALTER TABLE warehouse_stock_movements DROP CONSTRAINT %I', constraint_name);
  END LOOP;
  ALTER TABLE warehouse_stock_movements
    ADD CONSTRAINT warehouse_stock_movements_product_id_warehouse_products_id_fk
    FOREIGN KEY (product_id) REFERENCES warehouse_products(id) ON DELETE CASCADE;
END;
$migration$;

CREATE OR REPLACE FUNCTION prevent_warehouse_stock_movement_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  IF TG_OP = 'DELETE' AND NOT EXISTS (
    SELECT 1 FROM warehouse_products WHERE id = OLD.product_id
  ) THEN
    RETURN OLD;
  END IF;
  IF TG_OP = 'UPDATE'
    AND OLD.operator_id IS NOT NULL
    AND NEW.operator_id IS NULL
    AND (to_jsonb(NEW) - 'operator_id') = (to_jsonb(OLD) - 'operator_id') THEN
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'warehouse stock movements are append-only' USING ERRCODE = '55000';
END;
$function$;