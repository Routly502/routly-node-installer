CREATE TABLE IF NOT EXISTS nap_boxes (
  id serial PRIMARY KEY,
  name text NOT NULL,
  latitude double precision,
  longitude double precision,
  location text,
  ports integer NOT NULL,
  details text,
  CONSTRAINT nap_boxes_name_check CHECK (length(btrim(name)) BETWEEN 1 AND 120),
  CONSTRAINT nap_boxes_coordinates_check CHECK (
    (latitude IS NULL AND longitude IS NULL)
    OR (latitude IS NOT NULL AND longitude IS NOT NULL AND latitude BETWEEN -90 AND 90 AND longitude BETWEEN -180 AND 180)
  ),
  CONSTRAINT nap_boxes_location_length_check CHECK (location IS NULL OR length(location) <= 255),
  CONSTRAINT nap_boxes_ports_check CHECK (ports BETWEEN 1 AND 128),
  CONSTRAINT nap_boxes_details_length_check CHECK (details IS NULL OR length(details) <= 2000)
);