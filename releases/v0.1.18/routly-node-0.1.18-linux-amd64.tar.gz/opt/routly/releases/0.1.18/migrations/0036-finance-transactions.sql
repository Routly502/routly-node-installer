CREATE TABLE IF NOT EXISTS finance_transactions (
  id serial PRIMARY KEY,
  request_id uuid NOT NULL,
  kind text NOT NULL,
  date date NOT NULL,
  description text NOT NULL,
  category text,
  amount numeric(12, 2) NOT NULL,
  payment_method text NOT NULL,
  reference text,
  notes text,
  revision integer NOT NULL DEFAULT 1,
  created_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  created_by_name text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz,
  CONSTRAINT finance_transactions_kind_check CHECK (kind IN ('income', 'expense')),
  CONSTRAINT finance_transactions_amount_positive_check CHECK (amount > 0),
  CONSTRAINT finance_transactions_description_length_check CHECK (char_length(description) <= 240),
  CONSTRAINT finance_transactions_reference_length_check CHECK (reference IS NULL OR char_length(reference) <= 120),
  CONSTRAINT finance_transactions_notes_length_check CHECK (notes IS NULL OR char_length(notes) <= 2000),
  CONSTRAINT finance_transactions_revision_positive_check CHECK (revision >= 1)
);

CREATE UNIQUE INDEX IF NOT EXISTS finance_transactions_request_id_unique ON finance_transactions (request_id);
CREATE INDEX IF NOT EXISTS finance_transactions_date_idx ON finance_transactions (date);
CREATE INDEX IF NOT EXISTS finance_transactions_kind_date_idx ON finance_transactions (kind, date);
CREATE INDEX IF NOT EXISTS finance_transactions_created_by_user_id_idx ON finance_transactions (created_by_user_id);