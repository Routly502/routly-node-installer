ALTER TABLE tickets ADD COLUMN IF NOT EXISTS closed_at timestamptz;
ALTER TABLE ticket_replies
  ADD COLUMN IF NOT EXISTS author_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS body_html text,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz,
  ADD COLUMN IF NOT EXISTS attachment_object_path text,
  ADD COLUMN IF NOT EXISTS attachment_original_name text,
  ADD COLUMN IF NOT EXISTS attachment_content_type text,
  ADD COLUMN IF NOT EXISTS attachment_size integer;
CREATE INDEX IF NOT EXISTS ticket_replies_author_id_idx ON ticket_replies(author_id);