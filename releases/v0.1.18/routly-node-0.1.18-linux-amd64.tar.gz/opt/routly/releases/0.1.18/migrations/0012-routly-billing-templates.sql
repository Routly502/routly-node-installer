CREATE TABLE IF NOT EXISTS billing_templates (
  id serial PRIMARY KEY, name text NOT NULL, active boolean NOT NULL DEFAULT true,
  billing_type text NOT NULL DEFAULT 'prepaid', invoice_day integer NOT NULL DEFAULT 1,
  due_day integer NOT NULL DEFAULT 1, cutoff_day integer NOT NULL DEFAULT 1,
  grace_days integer NOT NULL DEFAULT 0, frequency_months integer NOT NULL DEFAULT 1,
  tax_enabled boolean NOT NULL DEFAULT false, tax_percentage double precision NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT billing_templates_type_check CHECK (billing_type IN ('prepaid','postpaid')),
  CONSTRAINT billing_templates_days_check CHECK (invoice_day BETWEEN 1 AND 31 AND due_day BETWEEN 1 AND 31 AND cutoff_day BETWEEN 1 AND 31),
  CONSTRAINT billing_templates_frequency_check CHECK (frequency_months IN (1,2,3)),
  CONSTRAINT billing_templates_tax_check CHECK (tax_percentage >= 0 AND tax_percentage <= 100)
);
CREATE TABLE IF NOT EXISTS billing_template_charges (
  id serial PRIMARY KEY, billing_template_id integer NOT NULL REFERENCES billing_templates(id) ON DELETE CASCADE,
  name text NOT NULL, charge_type text NOT NULL, amount double precision, rate double precision,
  active boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT billing_template_charges_type_check CHECK (charge_type IN ('one_time','monthly','usage')),
  CONSTRAINT billing_template_charges_value_check CHECK ((amount IS NOT NULL AND amount >= 0) OR (rate IS NOT NULL AND rate >= 0))
);
ALTER TABLE customers ADD COLUMN IF NOT EXISTS billing_template_id integer REFERENCES billing_templates(id) ON DELETE RESTRICT;
INSERT INTO billing_templates (name) SELECT 'Legacy default' WHERE NOT EXISTS (SELECT 1 FROM billing_templates);
UPDATE customers SET billing_template_id = (SELECT id FROM billing_templates ORDER BY id LIMIT 1) WHERE billing_template_id IS NULL;
CREATE INDEX IF NOT EXISTS customers_billing_template_id_idx ON customers(billing_template_id);