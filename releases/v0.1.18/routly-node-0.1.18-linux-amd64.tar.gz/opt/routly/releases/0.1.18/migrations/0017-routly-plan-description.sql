ALTER TABLE plans ADD COLUMN IF NOT EXISTS description text NOT NULL DEFAULT '';

UPDATE plans
SET description = name
WHERE description = '';