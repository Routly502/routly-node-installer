CREATE TABLE IF NOT EXISTS fiber_projects (
  id serial PRIMARY KEY,
  name text NOT NULL,
  description text,
  CONSTRAINT fiber_projects_name_check CHECK (length(btrim(name)) BETWEEN 1 AND 120),
  CONSTRAINT fiber_projects_description_length_check CHECK (description IS NULL OR length(description) <= 2000)
);

ALTER TABLE fiber_nodes
  ADD COLUMN IF NOT EXISTS project_id integer REFERENCES fiber_projects(id) ON DELETE SET NULL;
ALTER TABLE fiber_routes
  ADD COLUMN IF NOT EXISTS project_id integer REFERENCES fiber_projects(id) ON DELETE SET NULL;
ALTER TABLE nap_boxes
  ADD COLUMN IF NOT EXISTS fiber_project_id integer REFERENCES fiber_projects(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS fiber_nodes_project_id_idx ON fiber_nodes (project_id);
CREATE INDEX IF NOT EXISTS fiber_routes_project_id_idx ON fiber_routes (project_id);
CREATE INDEX IF NOT EXISTS nap_boxes_fiber_project_id_idx ON nap_boxes (fiber_project_id);