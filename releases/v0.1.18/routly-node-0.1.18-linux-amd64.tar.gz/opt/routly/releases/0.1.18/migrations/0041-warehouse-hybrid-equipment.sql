ALTER TABLE warehouse_products
  ADD COLUMN inventory_mode text NOT NULL DEFAULT 'bulk',
  ADD COLUMN serial_number text,
  ADD COLUMN mac_address text,
  ADD COLUMN unit_price numeric(11, 2) NOT NULL DEFAULT 0,
  ADD COLUMN equipment_state text,
  ADD COLUMN customer_id integer REFERENCES customers(id) ON DELETE SET NULL,
  ADD COLUMN customer_name text,
  ADD COLUMN entry_at timestamptz,
  ADD COLUMN exit_at timestamptz;

CREATE UNIQUE INDEX warehouse_products_serial_number_unique
  ON warehouse_products (lower(btrim(serial_number)))
  WHERE serial_number IS NOT NULL;
CREATE UNIQUE INDEX warehouse_products_mac_address_unique
  ON warehouse_products (upper(btrim(mac_address)))
  WHERE mac_address IS NOT NULL;
CREATE INDEX warehouse_products_customer_id_idx ON warehouse_products (customer_id);

ALTER TABLE warehouse_products
  ADD CONSTRAINT warehouse_products_inventory_mode_check
    CHECK (inventory_mode IN ('bulk', 'serialized')),
  ADD CONSTRAINT warehouse_products_serial_number_length_check
    CHECK (serial_number IS NULL OR char_length(btrim(serial_number)) BETWEEN 1 AND 120),
  ADD CONSTRAINT warehouse_products_mac_address_check
    CHECK (mac_address IS NULL OR mac_address ~ '^[0-9A-F]{2}(:[0-9A-F]{2}){5}$'),
  ADD CONSTRAINT warehouse_products_unit_price_check
    CHECK (unit_price BETWEEN 0 AND 999999999.99),
  ADD CONSTRAINT warehouse_products_equipment_state_check
    CHECK (equipment_state IS NULL OR equipment_state IN ('available', 'loaned', 'rented', 'sold')),
  ADD CONSTRAINT warehouse_products_equipment_metadata_check
    CHECK (
      (inventory_mode = 'bulk'
        AND serial_number IS NULL AND mac_address IS NULL AND equipment_state IS NULL
        AND customer_id IS NULL AND customer_name IS NULL AND entry_at IS NULL AND exit_at IS NULL)
      OR
      (inventory_mode = 'serialized'
        AND (serial_number IS NOT NULL OR mac_address IS NOT NULL)
        AND equipment_state IS NOT NULL AND entry_at IS NOT NULL
        AND (
          (equipment_state = 'available' AND quantity = 1
            AND customer_id IS NULL AND customer_name IS NULL AND exit_at IS NULL)
          OR
          (equipment_state IN ('loaned', 'rented', 'sold') AND quantity = 0
            AND customer_name IS NOT NULL AND exit_at IS NOT NULL)
        ))
    );