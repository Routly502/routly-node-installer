ALTER TABLE billing_templates
  ADD COLUMN IF NOT EXISTS other_tax_1_percentage double precision NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS other_tax_2_percentage double precision NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS other_tax_3_percentage double precision NOT NULL DEFAULT 0;

ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS other_tax_1_percentage double precision NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS other_tax_1_amount double precision NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS other_tax_2_percentage double precision NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS other_tax_2_amount double precision NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS other_tax_3_percentage double precision NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS other_tax_3_amount double precision NOT NULL DEFAULT 0;

DO $$ BEGIN
  ALTER TABLE billing_templates ADD CONSTRAINT billing_templates_other_tax_percentages_check
    CHECK (other_tax_1_percentage BETWEEN 0 AND 100 AND other_tax_2_percentage BETWEEN 0 AND 100 AND other_tax_3_percentage BETWEEN 0 AND 100);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE invoices ADD CONSTRAINT invoices_other_tax_percentages_check
    CHECK (other_tax_1_percentage BETWEEN 0 AND 100 AND other_tax_2_percentage BETWEEN 0 AND 100 AND other_tax_3_percentage BETWEEN 0 AND 100);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;