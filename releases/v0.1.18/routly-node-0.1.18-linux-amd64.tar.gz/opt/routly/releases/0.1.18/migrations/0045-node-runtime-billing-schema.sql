-- Bring the packaged Node runtime schema forward to match its current Drizzle
-- model. Historical invoice amounts and legacy customer records are untouched.
ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS invoice_type text NOT NULL DEFAULT 'service',
  ADD COLUMN IF NOT EXISTS issuance_source text,
  ADD COLUMN IF NOT EXISTS other_tax_1_amount double precision NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS other_tax_2_amount double precision NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS other_tax_3_amount double precision NOT NULL DEFAULT 0;
ALTER TABLE invoices
  ADD CONSTRAINT invoices_issuance_source_valid
  CHECK (issuance_source IN ('manual', 'automatic'));

ALTER TABLE billing_templates
  ADD COLUMN IF NOT EXISTS fixed_next_payment_date date,
  ADD COLUMN IF NOT EXISTS scheduled_fixed_cutoff_date date;

CREATE TABLE IF NOT EXISTS invoice_items (
  id serial PRIMARY KEY,
  invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  description text NOT NULL,
  unit_price double precision NOT NULL,
  quantity double precision NOT NULL,
  tax_percentage double precision NOT NULL DEFAULT 0,
  position integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS invoice_items_invoice_idx
  ON invoice_items(invoice_id, position);

CREATE TABLE IF NOT EXISTS payment_methods (
  id serial PRIMARY KEY,
  key text NOT NULL UNIQUE,
  name text NOT NULL,
  description_1 text,
  description_2 text,
  description_3 text,
  description_4 text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO payment_methods (key, name)
VALUES ('cash', 'Efectivo'),
       ('bank_transfer', 'Transferencia bancaria'),
       ('card', 'Tarjeta'),
       ('other', 'Otro')
ON CONFLICT (key) DO NOTHING;

CREATE TABLE IF NOT EXISTS invoice_payments (
  id serial PRIMARY KEY,
  invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  paid_at date NOT NULL,
  payment_method text NOT NULL,
  payment_method_detail text,
  transaction_number text,
  amount double precision NOT NULL CHECK (amount > 0),
  commission double precision NOT NULL DEFAULT 0 CHECK (commission >= 0),
  notes text,
  created_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS invoice_payments_invoice_idx ON invoice_payments(invoice_id);
CREATE INDEX IF NOT EXISTS invoice_payments_customer_idx ON invoice_payments(customer_id);
CREATE INDEX IF NOT EXISTS invoice_payments_paid_at_idx ON invoice_payments(paid_at);

-- Preserve known historical payments; do not infer records without recorded
-- payment date and method, and never rewrite the invoice's historical amount.
INSERT INTO invoice_payments (invoice_id, customer_id, paid_at, payment_method, amount, notes)
SELECT i.id, i.customer_id, i.paid_at, i.payment_method, i.amount,
       'Pago histórico migrado'
FROM invoices i
WHERE i.status = 'paid'
  AND i.paid_at IS NOT NULL
  AND i.payment_method IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM invoice_payments p WHERE p.invoice_id = i.id
  );

CREATE TABLE IF NOT EXISTS invoice_credit_allocations (
  id serial PRIMARY KEY,
  customer_id integer NOT NULL REFERENCES customers(id),
  source_invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  target_invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  amount_cents integer NOT NULL CHECK (amount_cents > 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS invoice_credit_allocations_customer_idx
  ON invoice_credit_allocations(customer_id);
CREATE INDEX IF NOT EXISTS invoice_credit_allocations_source_invoice_idx
  ON invoice_credit_allocations(source_invoice_id);
CREATE INDEX IF NOT EXISTS invoice_credit_allocations_target_invoice_idx
  ON invoice_credit_allocations(target_invoice_id);

CREATE TABLE IF NOT EXISTS customer_balance_movements (
  id serial PRIMARY KEY,
  customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  kind text NOT NULL,
  amount_cents bigint NOT NULL,
  description text NOT NULL,
  source_invoice_number text,
  target_invoice_number text,
  event_key text UNIQUE,
  created_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  operator_name text,
  created_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz,
  deleted_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  paid_use_at timestamptz,
  source_adjustment_id integer,
  CONSTRAINT customer_balance_movements_kind_check
    CHECK (kind IN ('manual_adjustment', 'credit_returned', 'adjustment_returned', 'adjustment_deleted')),
  CONSTRAINT customer_balance_movements_amount_nonzero_check
    CHECK (amount_cents <> 0)
);
CREATE INDEX IF NOT EXISTS customer_balance_movements_customer_idx
  ON customer_balance_movements(customer_id, created_at);

CREATE TABLE IF NOT EXISTS customer_balance_applications (
  id serial PRIMARY KEY,
  customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  movement_id integer NOT NULL REFERENCES customer_balance_movements(id) ON DELETE CASCADE,
  invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  amount_cents bigint NOT NULL,
  invoice_item_id integer REFERENCES invoice_items(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT customer_balance_applications_movement_invoice_unique
    UNIQUE (movement_id, invoice_id),
  CONSTRAINT customer_balance_applications_amount_nonzero_check
    CHECK (amount_cents <> 0)
);
CREATE INDEX IF NOT EXISTS customer_balance_applications_invoice_idx
  ON customer_balance_applications(invoice_id);