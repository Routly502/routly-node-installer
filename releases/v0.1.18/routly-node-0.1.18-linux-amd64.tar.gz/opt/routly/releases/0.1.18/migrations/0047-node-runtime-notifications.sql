-- Notification, mail-provider, and host-monitoring schema used by the current
-- Node Drizzle runtime. Provider settings remain disabled until configured.
ALTER TABLE billing_templates
  ADD COLUMN IF NOT EXISTS new_invoice_notification text NOT NULL DEFAULT 'email_sms',
  ADD COLUMN IF NOT EXISTS screen_notification_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS payment_reminder_notification text NOT NULL DEFAULT 'email_sms',
  ADD COLUMN IF NOT EXISTS reminder_1_days integer,
  ADD COLUMN IF NOT EXISTS reminder_2_days integer,
  ADD COLUMN IF NOT EXISTS reminder_3_days integer;

ALTER TABLE billing_templates
  ADD CONSTRAINT billing_templates_notification_channels_check
  CHECK (
    new_invoice_notification IN (
      'disabled', 'email', 'sms', 'telegram', 'email_telegram', 'email_sms', 'telegram_sms'
    )
    AND payment_reminder_notification IN (
      'disabled', 'email', 'sms', 'telegram', 'email_telegram', 'email_sms', 'telegram_sms'
    )
  );
ALTER TABLE billing_templates
  ADD CONSTRAINT billing_templates_reminder_days_check
  CHECK (
    (reminder_1_days IS NULL OR reminder_1_days BETWEEN -31 AND 31)
    AND (reminder_2_days IS NULL OR reminder_2_days BETWEEN -31 AND 31)
    AND (reminder_3_days IS NULL OR reminder_3_days BETWEEN -31 AND 31)
  );

ALTER TABLE company_settings
  ADD COLUMN IF NOT EXISTS server_cpu_alert_percent double precision NOT NULL DEFAULT 90,
  ADD COLUMN IF NOT EXISTS server_memory_alert_percent double precision NOT NULL DEFAULT 90,
  ADD COLUMN IF NOT EXISTS server_disk_alert_percent double precision NOT NULL DEFAULT 90,
  ADD COLUMN IF NOT EXISTS server_backup_max_age_hours integer NOT NULL DEFAULT 24;

CREATE TABLE IF NOT EXISTS email_provider_settings (
  id integer PRIMARY KEY DEFAULT 1,
  provider text NOT NULL DEFAULT 'smtp',
  enabled boolean NOT NULL DEFAULT false,
  from_name text NOT NULL DEFAULT '',
  from_address text NOT NULL DEFAULT '',
  public_base_url text NOT NULL DEFAULT '',
  facebook_url text NOT NULL DEFAULT '',
  whatsapp_url text NOT NULL DEFAULT '',
  instagram_url text NOT NULL DEFAULT '',
  tiktok_url text NOT NULL DEFAULT '',
  website_url text NOT NULL DEFAULT '',
  smtp_host text,
  smtp_port integer,
  smtp_secure boolean NOT NULL DEFAULT true,
  smtp_username text,
  encrypted_secret text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT email_provider_settings_singleton CHECK (id = 1)
);

CREATE TABLE IF NOT EXISTS email_templates (
  key text PRIMARY KEY,
  subject text NOT NULL,
  body text NOT NULL,
  image_url text NOT NULL DEFAULT '',
  facebook_url text NOT NULL DEFAULT '',
  whatsapp_url text NOT NULL DEFAULT '',
  instagram_url text NOT NULL DEFAULT '',
  tiktok_url text NOT NULL DEFAULT '',
  website_url text NOT NULL DEFAULT '',
  enabled boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS transactional_email_deliveries (
  id serial PRIMARY KEY,
  event_key text NOT NULL UNIQUE,
  template_key text NOT NULL,
  recipient text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  provider_message_id text,
  error text,
  attempted_at timestamptz,
  sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS transactional_email_deliveries_status_idx
  ON transactional_email_deliveries(status);

CREATE TABLE IF NOT EXISTS invoice_notification_deliveries (
  id serial PRIMARY KEY,
  invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  channel text NOT NULL,
  recipient text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  provider_message_id text,
  error text,
  attempted_at timestamptz,
  sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS invoice_notification_deliveries_invoice_channel_unique
  ON invoice_notification_deliveries(invoice_id, channel);
CREATE INDEX IF NOT EXISTS invoice_notification_deliveries_status_idx
  ON invoice_notification_deliveries(status);

ALTER TABLE monitoring_hosts
  ADD COLUMN IF NOT EXISTS consecutive_failures integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS failure_alert_threshold integer NOT NULL DEFAULT 3,
  ADD COLUMN IF NOT EXISTS failure_alert_active boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS failure_incident_key text,
  ADD COLUMN IF NOT EXISTS last_failure_reason text;

CREATE TABLE IF NOT EXISTS monitoring_host_alert_deliveries (
  id serial PRIMARY KEY,
  host_id integer NOT NULL REFERENCES monitoring_hosts(id) ON DELETE CASCADE,
  incident_key text NOT NULL,
  event text NOT NULL,
  recipient text NOT NULL,
  host_name text NOT NULL,
  event_occurred_at timestamptz NOT NULL,
  consecutive_failures integer,
  failure_reason text,
  status text NOT NULL DEFAULT 'pending',
  attempt_count integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  provider_message_id text,
  error text,
  attempted_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS monitoring_host_alert_deliveries_incident_recipient_unique
  ON monitoring_host_alert_deliveries(incident_key, event, recipient);

CREATE TABLE IF NOT EXISTS monitoring_host_incidents (
  id serial PRIMARY KEY,
  host_id integer NOT NULL REFERENCES monitoring_hosts(id) ON DELETE CASCADE,
  incident_key text NOT NULL UNIQUE,
  opened_at timestamptz NOT NULL,
  recovered_at timestamptz,
  consecutive_failures integer NOT NULL,
  failure_reason text
);
CREATE INDEX IF NOT EXISTS monitoring_host_incidents_host_opened_at_idx
  ON monitoring_host_incidents(host_id, opened_at);