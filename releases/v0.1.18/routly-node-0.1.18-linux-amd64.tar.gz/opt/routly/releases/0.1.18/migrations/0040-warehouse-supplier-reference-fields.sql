ALTER TABLE finance_transaction_suppliers
  ADD COLUMN email text,
  ADD COLUMN phone text,
  ADD COLUMN address text,
  ADD CONSTRAINT finance_transaction_suppliers_email_length_check
    CHECK (email IS NULL OR char_length(email) <= 254),
  ADD CONSTRAINT finance_transaction_suppliers_phone_length_check
    CHECK (phone IS NULL OR char_length(phone) <= 50),
  ADD CONSTRAINT finance_transaction_suppliers_address_length_check
    CHECK (address IS NULL OR char_length(address) <= 2000);