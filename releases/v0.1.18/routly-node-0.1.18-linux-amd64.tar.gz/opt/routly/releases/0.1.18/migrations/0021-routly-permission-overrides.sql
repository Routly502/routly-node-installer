ALTER TABLE app_users
  ADD COLUMN IF NOT EXISTS permission_overrides jsonb;