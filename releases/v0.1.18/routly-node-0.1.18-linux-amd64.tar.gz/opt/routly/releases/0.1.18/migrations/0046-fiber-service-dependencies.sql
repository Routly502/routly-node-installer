-- Dependency records are invalidated transactionally by the service update
-- API. No trigger is installed in this compatibility migration.
CREATE TABLE IF NOT EXISTS fiber_service_dependencies (
  service_id integer PRIMARY KEY
    REFERENCES customer_services(id) ON DELETE CASCADE,
  nap_box_id integer NOT NULL
    REFERENCES nap_boxes(id) ON DELETE CASCADE,
  nap_port_number integer NOT NULL
    CHECK (nap_port_number BETWEEN 1 AND 128)
);
CREATE INDEX IF NOT EXISTS fiber_service_dependencies_nap_idx
  ON fiber_service_dependencies(nap_box_id);