ALTER TABLE nap_boxes
  ADD COLUMN IF NOT EXISTS router_id integer REFERENCES mikrotik_routers(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS nap_boxes_router_id_idx ON nap_boxes (router_id);