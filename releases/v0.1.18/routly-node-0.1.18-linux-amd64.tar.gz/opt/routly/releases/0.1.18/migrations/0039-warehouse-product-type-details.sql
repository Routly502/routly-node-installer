ALTER TABLE warehouse_product_types
  ADD COLUMN category text NOT NULL DEFAULT 'product',
  ADD COLUMN tax_percentage numeric(5, 2) NOT NULL DEFAULT 0,
  ADD COLUMN fiscal_code text,
  ADD COLUMN unit_of_measure text NOT NULL DEFAULT 'units',
  ADD CONSTRAINT warehouse_product_types_category_check CHECK (category IN ('product', 'accessory')),
  ADD CONSTRAINT warehouse_product_types_tax_percentage_check CHECK (tax_percentage BETWEEN 0 AND 100),
  ADD CONSTRAINT warehouse_product_types_fiscal_code_length_check CHECK (fiscal_code IS NULL OR char_length(fiscal_code) BETWEEN 1 AND 100),
  ADD CONSTRAINT warehouse_product_types_unit_of_measure_check CHECK (unit_of_measure IN ('units', 'meters'));

ALTER TABLE warehouse_products
  ADD COLUMN quantity numeric(12, 3) NOT NULL DEFAULT 0,
  ADD CONSTRAINT warehouse_products_quantity_check CHECK (quantity BETWEEN 0 AND 999999999.999);