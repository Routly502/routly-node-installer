ALTER TABLE fiber_routes ADD COLUMN feed_vertex_index integer;
ALTER TABLE fiber_routes ADD CONSTRAINT fiber_routes_feed_vertex_check CHECK (feed_vertex_index IS NULL OR feed_vertex_index >= 0);
ALTER TABLE fiber_routes ADD COLUMN revision integer NOT NULL DEFAULT 1;
ALTER TABLE fiber_routes ADD CONSTRAINT fiber_routes_revision_check CHECK (revision >= 1);

CREATE FUNCTION bump_fiber_route_revision_on_link_delete() RETURNS trigger AS $$ BEGIN
  UPDATE fiber_routes SET revision = revision + 1,
    feed_vertex_index = CASE WHEN feed_vertex_index = OLD.vertex_index THEN NULL ELSE feed_vertex_index END
  WHERE id = OLD.route_id;
  RETURN OLD; /* function body */ END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER fiber_route_link_deleted_revision
  AFTER DELETE ON fiber_route_links FOR EACH ROW
  EXECUTE FUNCTION bump_fiber_route_revision_on_link_delete();