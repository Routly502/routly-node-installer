ALTER TABLE tickets
  ADD COLUMN IF NOT EXISTS customer_id integer REFERENCES customers(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS technician_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS visit_date date,
  ADD COLUMN IF NOT EXISTS visit_shift text,
  ADD COLUMN IF NOT EXISTS scheduled_from text,
  ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal',
  ADD COLUMN IF NOT EXISTS email_requested boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS email_sent_at timestamptz,
  ADD COLUMN IF NOT EXISTS attachment_object_path text,
  ADD COLUMN IF NOT EXISTS attachment_original_name text,
  ADD COLUMN IF NOT EXISTS attachment_content_type text,
  ADD COLUMN IF NOT EXISTS attachment_size integer;

CREATE INDEX IF NOT EXISTS tickets_customer_id_idx ON tickets(customer_id);
CREATE INDEX IF NOT EXISTS tickets_technician_id_idx ON tickets(technician_id);