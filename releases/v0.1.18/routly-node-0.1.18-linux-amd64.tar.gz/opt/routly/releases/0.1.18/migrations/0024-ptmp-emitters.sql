CREATE TABLE IF NOT EXISTS emitters (
  id serial PRIMARY KEY,
  name text NOT NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  router_id integer REFERENCES mikrotik_routers(id) ON DELETE SET NULL,
  location_id integer REFERENCES locations(id) ON DELETE SET NULL,
  description text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT emitters_coordinates_check CHECK (latitude BETWEEN -90 AND 90 AND longitude BETWEEN -180 AND 180)
);
CREATE INDEX IF NOT EXISTS emitters_router_id_idx ON emitters(router_id);
CREATE INDEX IF NOT EXISTS emitters_location_id_idx ON emitters(location_id);