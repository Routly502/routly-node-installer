ALTER TABLE billing_templates ADD COLUMN IF NOT EXISTS system_key text;
ALTER TABLE billing_templates ADD COLUMN IF NOT EXISTS is_system boolean NOT NULL DEFAULT false;
CREATE UNIQUE INDEX IF NOT EXISTS billing_templates_system_key_unique
  ON billing_templates(system_key) WHERE system_key IS NOT NULL;
UPDATE billing_templates SET system_key = 'legacy_default', is_system = true
  WHERE lower(name) = 'legacy default' AND system_key IS NULL;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS billing_template_assigned_at date;
UPDATE customers SET billing_template_assigned_at = COALESCE(installation_date, joined_at)
  WHERE billing_template_id IS NOT NULL AND billing_template_assigned_at IS NULL;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS billing_type text;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS service_period_start date;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS service_period_end date;