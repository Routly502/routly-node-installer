CREATE INDEX IF NOT EXISTS warehouse_stock_movements_occurred_history_idx
  ON warehouse_stock_movements (occurred_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS warehouse_stock_movements_product_occurred_history_idx
  ON warehouse_stock_movements (product_id, occurred_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS warehouse_stock_movements_operator_occurred_history_idx
  ON warehouse_stock_movements (operator_id, occurred_at DESC, id DESC);