-- Preserve each legacy customer subscription as a service before permitting
-- multiple services per customer. Keep the legacy customer columns intact.
CREATE TABLE IF NOT EXISTS customer_services (
  id serial PRIMARY KEY,
  customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  plan_id integer REFERENCES plans(id) ON DELETE SET NULL,
  plan_name text NOT NULL,
  monthly_amount double precision NOT NULL,
  billing_template_id integer REFERENCES billing_templates(id) ON DELETE RESTRICT,
  billing_template_assigned_at date,
  status text NOT NULL DEFAULT 'pending',
  connection_type text NOT NULL,
  location_id integer REFERENCES locations(id) ON DELETE RESTRICT,
  router_id integer REFERENCES mikrotik_routers(id) ON DELETE SET NULL,
  ipv4_network_id integer REFERENCES ipv4_networks(id) ON DELETE SET NULL,
  service_mode text,
  service_address text,
  service_mac_address text,
  service_username text,
  encrypted_service_password text,
  provisioning_status text NOT NULL DEFAULT 'not_requested',
  provisioning_error text,
  installation_date date,
  service_address_text text,
  coordinates text,
  equipment_type text,
  equipment_model text,
  equipment_serial text,
  admin_ip text,
  nap_box text,
  nap_port text,
  joined_at date NOT NULL DEFAULT current_date,
  last_payment_at date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS service_id integer REFERENCES customer_services(id) ON DELETE SET NULL;
ALTER TABLE mikrotik_clients
  ADD COLUMN IF NOT EXISTS service_id integer REFERENCES customer_services(id) ON DELETE SET NULL;

DROP INDEX IF EXISTS invoices_customer_billing_period_active_unique;
CREATE UNIQUE INDEX IF NOT EXISTS invoices_customer_service_billing_period_active_unique
  ON invoices(customer_id, service_id, billing_period)
  WHERE billing_period <> 'legacy' AND status <> 'voided' AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS customer_services_customer_idx
  ON customer_services(customer_id);
CREATE UNIQUE INDEX IF NOT EXISTS customer_services_network_address_unique
  ON customer_services(ipv4_network_id, service_address)
  WHERE status <> 'retired' AND service_address IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS mikrotik_clients_service_unique
  ON mikrotik_clients(service_id);
DROP INDEX IF EXISTS mikrotik_clients_customer_unique;

-- Copy the legacy subscription fields without altering the source customer.
INSERT INTO customer_services (
  customer_id, plan_name, monthly_amount, billing_template_id,
  billing_template_assigned_at, status, connection_type, location_id, router_id,
  ipv4_network_id, service_mode, service_address, service_mac_address,
  service_username, encrypted_service_password, provisioning_status,
  provisioning_error, installation_date, service_address_text, coordinates,
  equipment_type, equipment_model, equipment_serial, admin_ip, nap_box, nap_port,
  joined_at, last_payment_at
)
SELECT c.id, c.plan_name, c.monthly_amount, c.billing_template_id,
  c.billing_template_assigned_at, c.status, c.connection_type, c.location_id,
  c.router_id, c.ipv4_network_id, c.service_mode, c.service_address,
  c.service_mac_address, c.service_username, c.encrypted_service_password,
  c.provisioning_status, c.provisioning_error, c.installation_date,
  c.service_address, c.coordinates, c.equipment_type, c.equipment_model,
  c.equipment_serial, c.admin_ip, c.nap_box, c.nap_port, c.joined_at,
  c.last_payment_at
FROM customers c
WHERE NOT EXISTS (
  SELECT 1 FROM customer_services s WHERE s.customer_id = c.id
);

UPDATE customer_services s
SET plan_id = p.id
FROM plans p
WHERE s.plan_id IS NULL AND p.name = s.plan_name
  AND (SELECT count(*) FROM plans candidate WHERE candidate.name = s.plan_name) = 1;

UPDATE mikrotik_clients m
SET service_id = s.id
FROM customer_services s
WHERE m.customer_id = s.customer_id
  AND m.service_id IS NULL
  AND (SELECT count(*) FROM customer_services candidate WHERE candidate.customer_id = m.customer_id) = 1
  AND NOT EXISTS (
    SELECT 1 FROM mikrotik_clients used WHERE used.service_id = s.id
  );

UPDATE invoices i
SET service_id = s.id
FROM customer_services s
WHERE i.customer_id = s.customer_id AND i.service_id IS NULL
  AND (SELECT count(*) FROM customer_services candidate WHERE candidate.customer_id = i.customer_id) = 1;