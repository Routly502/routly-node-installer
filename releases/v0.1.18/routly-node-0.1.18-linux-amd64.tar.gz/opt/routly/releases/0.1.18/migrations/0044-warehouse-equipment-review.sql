ALTER TABLE warehouse_products
  ADD COLUMN inspection_at timestamptz,
  ADD COLUMN last_customer_name text,
  ADD COLUMN retirement_reason text,
  ADD COLUMN retirement_notes text,
  ADD COLUMN retired_at timestamptz,
  ADD COLUMN retired_by_name text;

ALTER TABLE warehouse_products DROP CONSTRAINT warehouse_products_equipment_state_check;
ALTER TABLE warehouse_products ADD CONSTRAINT warehouse_products_equipment_state_check
  CHECK (equipment_state IS NULL OR equipment_state IN ('available', 'loaned', 'rented', 'sold', 'inspection', 'retired'));

ALTER TABLE warehouse_products DROP CONSTRAINT warehouse_products_equipment_metadata_check;
ALTER TABLE warehouse_products ADD CONSTRAINT warehouse_products_equipment_metadata_check CHECK (
  (inventory_mode = 'bulk' AND serial_number IS NULL AND mac_address IS NULL AND equipment_state IS NULL
    AND customer_id IS NULL AND customer_name IS NULL AND entry_at IS NULL AND exit_at IS NULL)
  OR
  (inventory_mode = 'serialized' AND (serial_number IS NOT NULL OR mac_address IS NOT NULL)
    AND equipment_state IS NOT NULL AND entry_at IS NOT NULL AND (
      (equipment_state = 'available' AND quantity = 1 AND customer_id IS NULL AND customer_name IS NULL AND exit_at IS NULL)
      OR (equipment_state IN ('loaned', 'rented', 'sold') AND quantity = 0 AND customer_name IS NOT NULL AND exit_at IS NOT NULL)
      OR (equipment_state IN ('inspection', 'retired') AND quantity = 0
        AND customer_id IS NULL AND customer_name IS NULL AND exit_at IS NULL
        AND (equipment_state <> 'inspection' OR inspection_at IS NOT NULL))
    ))
);
ALTER TABLE warehouse_products ADD CONSTRAINT warehouse_products_retirement_check CHECK (
  (equipment_state = 'retired' AND retirement_reason IS NOT NULL AND retirement_reason IN ('electrical_damage', 'wear', 'other')
    AND retired_at IS NOT NULL AND retired_by_name IS NOT NULL
    AND (retirement_reason <> 'other' OR (retirement_notes IS NOT NULL AND length(btrim(retirement_notes)) > 0)))
  OR (equipment_state IS DISTINCT FROM 'retired' AND retirement_reason IS NULL AND retirement_notes IS NULL
    AND retired_at IS NULL AND retired_by_name IS NULL)
);

ALTER TABLE warehouse_stock_movements DROP CONSTRAINT warehouse_stock_movements_kind_check;
ALTER TABLE warehouse_stock_movements ADD CONSTRAINT warehouse_stock_movements_kind_check CHECK (
  kind IN ('purchase', 'consumption', 'return', 'adjustment_in', 'adjustment_out', 'opening',
    'identification_in', 'identification_out', 'inspection_in', 'inspection_approved', 'retirement')
);