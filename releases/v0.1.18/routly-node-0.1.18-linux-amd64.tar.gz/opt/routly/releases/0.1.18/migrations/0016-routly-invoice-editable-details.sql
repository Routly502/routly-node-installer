ALTER TABLE invoices ADD COLUMN IF NOT EXISTS issue_date date NOT NULL DEFAULT CURRENT_DATE;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS description text NOT NULL DEFAULT 'Servicio de internet';
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS unit_price double precision NOT NULL DEFAULT 0;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS quantity double precision NOT NULL DEFAULT 1;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS discount double precision NOT NULL DEFAULT 0;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS prorated boolean NOT NULL DEFAULT false;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS billable_days integer;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS period_days integer;

UPDATE invoices
SET unit_price = COALESCE(subtotal, amount),
    description = 'Servicio de internet'
WHERE unit_price = 0;