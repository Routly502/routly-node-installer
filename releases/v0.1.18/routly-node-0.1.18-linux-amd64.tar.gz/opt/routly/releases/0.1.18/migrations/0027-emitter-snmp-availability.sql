ALTER TABLE emitters
  ADD COLUMN IF NOT EXISTS next_snmp_poll_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS consecutive_snmp_failures integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS snmp_alert_active boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS snmp_incident_key text;
CREATE TABLE IF NOT EXISTS emitter_snmp_samples (
  id serial PRIMARY KEY, emitter_id integer NOT NULL REFERENCES emitters(id) ON DELETE CASCADE,
  sampled_at timestamptz NOT NULL DEFAULT now(), available boolean NOT NULL,
  cpu_percent double precision, memory_used_bytes bigint, memory_total_bytes bigint,
  uptime_seconds bigint, model text, firmware_version text,
  interface_count integer, interfaces_up integer, interfaces_down integer, failure_reason text
);
CREATE INDEX IF NOT EXISTS emitter_snmp_samples_emitter_time_idx ON emitter_snmp_samples(emitter_id, sampled_at);
CREATE INDEX IF NOT EXISTS emitter_snmp_samples_time_idx ON emitter_snmp_samples(sampled_at);
CREATE TABLE IF NOT EXISTS emitter_snmp_incidents (
  id serial PRIMARY KEY, emitter_id integer NOT NULL REFERENCES emitters(id) ON DELETE CASCADE,
  incident_key text NOT NULL UNIQUE, opened_at timestamptz NOT NULL, recovered_at timestamptz,
  consecutive_failures integer NOT NULL, failure_reason text
);
CREATE INDEX IF NOT EXISTS emitter_snmp_incidents_emitter_time_idx ON emitter_snmp_incidents(emitter_id, opened_at);
CREATE TABLE IF NOT EXISTS emitter_snmp_alert_deliveries (
  id serial PRIMARY KEY, emitter_id integer NOT NULL REFERENCES emitters(id) ON DELETE CASCADE,
  incident_key text NOT NULL, event text NOT NULL, recipient text NOT NULL,
  emitter_name text NOT NULL, event_occurred_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'pending', attempt_count integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz NOT NULL DEFAULT now(), attempted_at timestamptz, sent_at timestamptz, error text
);
CREATE UNIQUE INDEX IF NOT EXISTS emitter_snmp_alert_delivery_unique ON emitter_snmp_alert_deliveries(incident_key, event, recipient);