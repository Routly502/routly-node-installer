ALTER TABLE plans ADD COLUMN IF NOT EXISTS all_routers boolean NOT NULL DEFAULT true;

CREATE TABLE IF NOT EXISTS plan_router_availability (
  plan_id integer NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
  router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS plan_router_availability_unique
  ON plan_router_availability(plan_id, router_id);
CREATE INDEX IF NOT EXISTS plan_router_availability_router_idx
  ON plan_router_availability(router_id);