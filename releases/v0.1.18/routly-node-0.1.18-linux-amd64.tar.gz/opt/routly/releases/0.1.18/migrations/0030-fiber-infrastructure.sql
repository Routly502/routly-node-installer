CREATE TABLE IF NOT EXISTS fiber_nodes (
  id serial PRIMARY KEY,
  name text NOT NULL,
  kind text NOT NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  location_id integer REFERENCES locations(id) ON DELETE SET NULL,
  notes text,
  CONSTRAINT fiber_nodes_name_check CHECK (length(btrim(name)) BETWEEN 1 AND 120),
  CONSTRAINT fiber_nodes_kind_check CHECK (kind IN ('pop', 'splice_closure', 'owned_pole')),
  CONSTRAINT fiber_nodes_latitude_check CHECK (latitude BETWEEN -90 AND 90),
  CONSTRAINT fiber_nodes_longitude_check CHECK (longitude BETWEEN -180 AND 180),
  CONSTRAINT fiber_nodes_notes_length_check CHECK (notes IS NULL OR length(notes) <= 2000)
);

CREATE INDEX IF NOT EXISTS fiber_nodes_location_id_idx ON fiber_nodes (location_id);
CREATE INDEX IF NOT EXISTS fiber_nodes_kind_idx ON fiber_nodes (kind);

CREATE TABLE IF NOT EXISTS fiber_routes (
  id serial PRIMARY KEY,
  name text NOT NULL,
  points jsonb NOT NULL,
  location_id integer REFERENCES locations(id) ON DELETE SET NULL,
  notes text,
  CONSTRAINT fiber_routes_name_check CHECK (length(btrim(name)) BETWEEN 1 AND 120),
  CONSTRAINT fiber_routes_points_check CHECK (
    jsonb_typeof(points) = 'array' AND jsonb_array_length(points) BETWEEN 2 AND 2000
  ),
  CONSTRAINT fiber_routes_notes_length_check CHECK (notes IS NULL OR length(notes) <= 2000)
);

CREATE INDEX IF NOT EXISTS fiber_routes_location_id_idx ON fiber_routes (location_id);