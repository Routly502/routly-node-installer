CREATE TABLE IF NOT EXISTS finance_transaction_suppliers (
  id serial PRIMARY KEY,
  name text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT finance_transaction_suppliers_name_length_check CHECK (char_length(name) BETWEEN 1 AND 160)
);
CREATE UNIQUE INDEX IF NOT EXISTS finance_transaction_suppliers_name_unique
  ON finance_transaction_suppliers (lower(name));

ALTER TABLE finance_transactions
  ADD COLUMN IF NOT EXISTS router_id integer REFERENCES mikrotik_routers(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS router_name_snapshot text,
  ADD COLUMN IF NOT EXISTS supplier_id integer REFERENCES finance_transaction_suppliers(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS supplier_name_snapshot text,
  ADD COLUMN IF NOT EXISTS recurrence_schedule_id integer,
  ADD COLUMN IF NOT EXISTS recurrence_occurrence_date date;

CREATE TABLE IF NOT EXISTS finance_transaction_recurrences (
  id serial PRIMARY KEY,
  root_transaction_id integer NOT NULL UNIQUE REFERENCES finance_transactions(id) ON DELETE CASCADE,
  frequency text NOT NULL,
  weekdays integer[],
  anchor_day integer,
  anchor_month integer,
  next_occurrence date NOT NULL,
  stopped_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT finance_transaction_recurrences_frequency_check
    CHECK (frequency IN ('daily', 'weekdays', 'weekly', 'monthly', 'yearly')),
  CONSTRAINT finance_transaction_recurrences_weekdays_check
    CHECK (weekdays IS NULL OR (array_length(weekdays, 1) <= 7 AND weekdays <@ ARRAY[1,2,3,4,5,6,7]::integer[])),
  CONSTRAINT finance_transaction_recurrences_anchor_day_check
    CHECK (anchor_day IS NULL OR anchor_day BETWEEN 1 AND 31),
  CONSTRAINT finance_transaction_recurrences_anchor_month_check
    CHECK (anchor_month IS NULL OR anchor_month BETWEEN 1 AND 12)
);
CREATE INDEX IF NOT EXISTS finance_transaction_recurrences_next_occurrence_idx
  ON finance_transaction_recurrences (next_occurrence) WHERE stopped_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS finance_transactions_recurrence_occurrence_unique
  ON finance_transactions (recurrence_schedule_id, recurrence_occurrence_date);
ALTER TABLE finance_transactions
  ADD CONSTRAINT finance_transactions_recurrence_occurrence_pair_check
  CHECK ((recurrence_schedule_id IS NULL) = (recurrence_occurrence_date IS NULL));

CREATE TABLE IF NOT EXISTS finance_transaction_attachments (
  id serial PRIMARY KEY,
  transaction_id integer NOT NULL REFERENCES finance_transactions(id) ON DELETE CASCADE,
  object_path text NOT NULL,
  original_name text NOT NULL,
  content_type text NOT NULL,
  content_hash text NOT NULL,
  size_bytes integer NOT NULL,
  created_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT finance_transaction_attachments_size_positive_check CHECK (size_bytes > 0)
);
CREATE INDEX IF NOT EXISTS finance_transaction_attachments_transaction_idx
  ON finance_transaction_attachments (transaction_id, id);
CREATE UNIQUE INDEX IF NOT EXISTS finance_transaction_attachments_content_hash_unique
  ON finance_transaction_attachments (transaction_id, content_hash);