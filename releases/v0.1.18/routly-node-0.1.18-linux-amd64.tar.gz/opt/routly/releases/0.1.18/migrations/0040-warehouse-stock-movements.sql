CREATE TABLE warehouse_stock_movements (
  id serial PRIMARY KEY,
  product_id integer NOT NULL REFERENCES warehouse_products(id) ON DELETE RESTRICT,
  request_id uuid NOT NULL,
  kind text NOT NULL,
  quantity numeric(12, 3) NOT NULL,
  unit_of_measure text NOT NULL,
  reason text NOT NULL,
  occurred_at timestamptz NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT now(),
  operator_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  operator_name text NOT NULL,
  balance_before numeric(12, 3) NOT NULL,
  balance_after numeric(12, 3) NOT NULL,
  CONSTRAINT warehouse_stock_movements_kind_check CHECK (kind IN ('purchase', 'consumption', 'return', 'adjustment_in', 'adjustment_out', 'opening')),
  CONSTRAINT warehouse_stock_movements_quantity_check CHECK (quantity > 0 AND quantity <= 999999999.999),
  CONSTRAINT warehouse_stock_movements_unit_of_measure_check CHECK (unit_of_measure IN ('units', 'meters')),
  CONSTRAINT warehouse_stock_movements_reason_length_check CHECK (char_length(btrim(reason)) BETWEEN 1 AND 1000),
  CONSTRAINT warehouse_stock_movements_balance_before_check CHECK (balance_before BETWEEN 0 AND 999999999.999),
  CONSTRAINT warehouse_stock_movements_balance_after_check CHECK (balance_after BETWEEN 0 AND 999999999.999)
);
CREATE UNIQUE INDEX warehouse_stock_movements_request_unique
  ON warehouse_stock_movements (request_id);
CREATE INDEX warehouse_stock_movements_product_history_idx
  ON warehouse_stock_movements (product_id, recorded_at DESC, id DESC);

INSERT INTO warehouse_stock_movements (
  product_id, request_id, kind, quantity, unit_of_measure, reason, occurred_at,
  recorded_at, operator_id, operator_name, balance_before, balance_after
)
SELECT
  product.id,
  md5('warehouse-opening:' || product.id::text)::uuid,
  'opening',
  product.quantity,
  coalesce(product_type.unit_of_measure, 'units'),
  'Saldo inicial migrado al libro de movimientos',
  product.created_at,
  now(),
  NULL,
  'Sistema (migración)',
  0,
  product.quantity
FROM warehouse_products AS product
LEFT JOIN warehouse_product_types AS product_type ON product_type.id = product.product_type_id
WHERE product.quantity > 0;

CREATE OR REPLACE FUNCTION prevent_warehouse_stock_movement_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  IF TG_OP = 'UPDATE'
    AND OLD.operator_id IS NOT NULL
    AND NEW.operator_id IS NULL
    AND (to_jsonb(NEW) - 'operator_id') = (to_jsonb(OLD) - 'operator_id') THEN
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'warehouse stock movements are append-only' USING ERRCODE = '55000';
END;
$function$;
CREATE TRIGGER warehouse_stock_movements_append_only
  BEFORE UPDATE OR DELETE ON warehouse_stock_movements
  FOR EACH ROW EXECUTE FUNCTION prevent_warehouse_stock_movement_mutation();