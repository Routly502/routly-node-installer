ALTER TABLE fiber_routes ADD COLUMN IF NOT EXISTS color text NOT NULL DEFAULT '#2563b8';
ALTER TABLE fiber_routes ADD CONSTRAINT fiber_routes_color_check CHECK (color ~ '^#[0-9A-Fa-f]{6}$');