ALTER TABLE "customers"
  ADD COLUMN IF NOT EXISTS "fixed_phone" text,
  ADD COLUMN IF NOT EXISTS "payment_code" text,
  ADD COLUMN IF NOT EXISTS "encrypted_portal_password" text;