ALTER TABLE nap_boxes
  ADD COLUMN location_id integer REFERENCES locations(id) ON DELETE SET NULL;

CREATE INDEX nap_boxes_location_id_idx ON nap_boxes (location_id);