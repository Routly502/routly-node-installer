ALTER TABLE finance_transaction_suppliers
  ADD COLUMN revision integer NOT NULL DEFAULT 1,
  ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now(),
  ADD CONSTRAINT finance_transaction_suppliers_revision_positive_check CHECK (revision >= 1);
CREATE UNIQUE INDEX finance_transaction_suppliers_normalized_name_unique
  ON finance_transaction_suppliers (lower(btrim(name)));

CREATE TABLE warehouse_product_types (
  id serial PRIMARY KEY,
  name text NOT NULL,
  description text,
  active boolean NOT NULL DEFAULT true,
  revision integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT warehouse_product_types_name_length_check CHECK (char_length(name) BETWEEN 1 AND 120),
  CONSTRAINT warehouse_product_types_description_length_check CHECK (description IS NULL OR char_length(description) <= 2000),
  CONSTRAINT warehouse_product_types_revision_positive_check CHECK (revision >= 1)
);
CREATE UNIQUE INDEX warehouse_product_types_name_unique
  ON warehouse_product_types (lower(btrim(name)));

CREATE TABLE warehouse_products (
  id serial PRIMARY KEY,
  name text NOT NULL,
  code text,
  description text,
  product_type_id integer REFERENCES warehouse_product_types(id) ON DELETE SET NULL,
  supplier_id integer REFERENCES finance_transaction_suppliers(id) ON DELETE SET NULL,
  active boolean NOT NULL DEFAULT true,
  revision integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT warehouse_products_name_length_check CHECK (char_length(name) BETWEEN 1 AND 160),
  CONSTRAINT warehouse_products_code_length_check CHECK (code IS NULL OR char_length(code) BETWEEN 1 AND 80),
  CONSTRAINT warehouse_products_description_length_check CHECK (description IS NULL OR char_length(description) <= 2000),
  CONSTRAINT warehouse_products_revision_positive_check CHECK (revision >= 1)
);
CREATE UNIQUE INDEX warehouse_products_code_unique
  ON warehouse_products (lower(btrim(code))) WHERE code IS NOT NULL;
CREATE INDEX warehouse_products_product_type_id_idx ON warehouse_products (product_type_id);
CREATE INDEX warehouse_products_supplier_id_idx ON warehouse_products (supplier_id);