ALTER TABLE warehouse_stock_movements ADD COLUMN transfer_id uuid;

ALTER TABLE warehouse_stock_movements DROP CONSTRAINT warehouse_stock_movements_kind_check;
ALTER TABLE warehouse_stock_movements ADD CONSTRAINT warehouse_stock_movements_kind_check
  CHECK (kind IN ('purchase', 'consumption', 'return', 'adjustment_in', 'adjustment_out', 'opening', 'identification_in', 'identification_out'));

CREATE UNIQUE INDEX warehouse_stock_movements_transfer_kind_unique
  ON warehouse_stock_movements (transfer_id, kind) WHERE transfer_id IS NOT NULL;

ALTER TABLE warehouse_stock_movements ADD CONSTRAINT warehouse_stock_movements_transfer_check CHECK (
  (kind IN ('identification_in', 'identification_out') AND transfer_id IS NOT NULL
    AND quantity = 1 AND unit_of_measure = 'units'
    AND balance_after = balance_before + CASE WHEN kind = 'identification_in' THEN 1 ELSE -1 END)
  OR (kind NOT IN ('identification_in', 'identification_out') AND transfer_id IS NULL)
);