ALTER TABLE customer_services
  ADD COLUMN nap_box_id integer,
  ADD COLUMN nap_port_number integer,
  ADD CONSTRAINT customer_services_nap_box_id_fkey
    FOREIGN KEY (nap_box_id) REFERENCES nap_boxes(id) ON DELETE RESTRICT,
  ADD CONSTRAINT customer_services_nap_assignment_pair_check
    CHECK (
      (nap_box_id IS NULL) = (nap_port_number IS NULL)
      AND (nap_port_number IS NULL OR nap_port_number BETWEEN 1 AND 128)
    );

CREATE UNIQUE INDEX customer_services_nap_port_unique
  ON customer_services (nap_box_id, nap_port_number);