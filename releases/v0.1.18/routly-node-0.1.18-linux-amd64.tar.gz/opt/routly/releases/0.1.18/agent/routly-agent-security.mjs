import { verify as verifySignature } from "node:crypto";

export const strictVersion = value => /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(value);
export const canonicalMetadata = assignment => JSON.stringify({
  version: assignment.version,
  artifactUrl: assignment.artifactUrl,
  packageSha256: assignment.artifactChecksum,
}) + "\n";
export const safeError = value => {
  let message = String(value?.message || value || "operation failed");
  message = message.replace(/https?:\/\/[^\s"'<>]+/gi, "[url]")
    .replace(/\b[A-Z0-9._%+-]+:[^@\s/]+@/gi, "[credentials]@")
    .replace(/\b(token|password|secret|database_url|authorization)\s*[:=]\s*[^\s,;]+/gi, "$1=[redacted]")
    .replace(/(?:postgres(?:ql)?:\/\/)[^\s]+/gi, "[database-url]")
    .replace(/\b(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?\b/g, "[address]")
    .replace(/\[[\da-f:]{3,}\](?::\d+)?/gi, "[address]")
    .replace(/(?:\/(?:var|etc|opt|root|home|tmp)\/)[^\s"'<>]*/g, "[path]");
  for (const name of ["ROUTLY_CONTROL_INSTALLATION_TOKEN", "DATABASE_URL", "PGPASSWORD"]) {
    const secret = process.env[name];
    if (secret && secret.length > 2) message = message.split(secret).join("[redacted]");
  }
  return message.slice(0, 500);
};
export function verifyAssignment(assignment, pinnedOrigin, publicKey) {
  if (!assignment || !strictVersion(assignment.version) ||
      !/^[a-f0-9]{64}$/.test(assignment.artifactChecksum || "") ||
      typeof assignment.packageSignature !== "string") throw Error("invalid signed assignment metadata");
  let artifact;
  try { artifact = new URL(assignment.artifactUrl); } catch { throw Error("invalid artifact URL"); }
  if (!["https:", ...(process.env.ROUTLY_TEST_MODE === "1" ? ["http:"] : [])].includes(artifact.protocol) ||
      artifact.origin !== pinnedOrigin || artifact.username || artifact.password) throw Error("artifact origin is not trusted");
  const canonical = canonicalMetadata(assignment);
  let signature;
  try { signature = Buffer.from(assignment.packageSignature, "base64"); } catch { throw Error("invalid metadata signature"); }
  if (!signature.length || !verifySignature(null, Buffer.from(canonical), publicKey, signature)) {
    throw Error("release signature verification failed");
  }
  return { canonical, artifactUrl: artifact.href };
}

export const phases = new Set([
  "preparing", "downloading", "retry_wait", "validating", "stopping", "stopped",
  "backed_up", "migrating", "migrated", "release_installed", "host_integrating",
  "activated", "healthy", "rolled_back", "failed",
]);

export function parseRootProgress(line, expectedVersion) {
  const prefix = "ROUTLY_PROGRESS ";
  if (!line.startsWith(prefix)) return null;
  try {
    const value = JSON.parse(line.slice(prefix.length));
    if (!value || !phases.has(value.phase) || value.version !== expectedVersion ||
        typeof value.timestamp !== "string" || !Number.isFinite(Date.parse(value.timestamp))) return null;
    return { phase: value.phase, version: expectedVersion, timestamp: new Date(value.timestamp).toISOString() };
  } catch { return null; }
}