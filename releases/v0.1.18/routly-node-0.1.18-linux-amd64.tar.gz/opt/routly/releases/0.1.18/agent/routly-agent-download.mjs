import { createHash } from "node:crypto";
import { open, lstat, mkdir, readFile, rename, unlink } from "node:fs/promises";
import { createReadStream, constants as fsConstants } from "node:fs";
import { setTimeout as sleep } from "node:timers/promises";
import { setDefaultResultOrder } from "node:dns";

// Node's native fetch/https connector tries IPv4 answers first, then its
// automatic family fallback can use IPv6 when the v4 route is unavailable.
setDefaultResultOrder("ipv4first");

const MAX_SIZE = 1024 * 1024 * 1024;
const CHUNK = 2 * 1024 * 1024;
const TOTAL_MS = 600000;
const safeFile = async path => {
  try {
    const st = await lstat(path);
    if (!st.isFile() || st.isSymbolicLink() || st.uid !== process.getuid() || (st.mode & 0o077)) throw Error("unsafe partial artifact");
    return st.size;
  } catch (e) { if (e.code === "ENOENT") return 0; throw e; }
};
const hashFile = async path => {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest("hex");
};

async function appendResponse(response, path, offset, expectedRange, onProgress, transport, retry) {
  let rangeTotal = null;
  const rejectResponse = async message => {
    await response.body?.cancel().catch(() => {});
    throw Error(message);
  };
  if (expectedRange) {
    const contentRange = response.headers.get("content-range");
    const match = contentRange?.match(/^bytes (\d+)-(\d+)\/(\d+)$/);
    if (response.status === 206 && (!match || Number(match[1]) !== expectedRange.start ||
        (expectedRange.end !== null && Number(match[2]) !== expectedRange.end) ||
        Number(match[2]) - Number(match[1]) + 1 > expectedRange.maxBytes ||
        (expectedRange.total !== null && Number(match[3]) !== expectedRange.total))) {
      await rejectResponse("relay returned a mismatched byte range");
    }
    if (response.status === 206) rangeTotal = Number(match[3]);
    if (transport === "relay" && response.status !== 206) await rejectResponse("Control relay must honor bounded byte ranges");
    if (response.status !== 206 && response.status !== 200) await rejectResponse("artifact server rejected range request");
  } else if (!response.ok) await rejectResponse("artifact server rejected download");
  const append = response.status === 206 && offset > 0;
  const flags = fsConstants.O_WRONLY | fsConstants.O_CREAT | fsConstants.O_NOFOLLOW |
    (append ? fsConstants.O_APPEND : fsConstants.O_TRUNC);
  const handle = await open(path, flags, 0o600);
  let received = append ? offset : 0;
  let responseBytes = 0;
  const responseTotal = rangeTotal || Number(response.headers.get("content-length")) || null;
  try {
    if (!response.body) throw Error("artifact response is empty");
    for await (const chunk of response.body) {
      received += chunk.length;
      responseBytes += chunk.length;
      if (expectedRange && transport === "relay" && responseBytes > CHUNK) throw Error("relay response exceeded chunk limit");
      if (received > MAX_SIZE) throw Error("artifact exceeds bounded download size");
      await handle.write(chunk);
      await onProgress({ bytesReceived: received, totalBytes: expectedRange?.total || responseTotal, retry, transport });
    }
    await handle.sync();
  } finally { await handle.close(); }
  return { received, totalBytes: rangeTotal || Number(response.headers.get("content-length")) || null, responseBytes };
}

async function request(url, { headers, timeout, headerTimeout = 30000, stallTimeout = 30000, allowGithubRedirects = false }) {
  const controller = new AbortController();
  const clearTimers = () => { clearTimeout(headerTimer); clearTimeout(totalTimer); clearTimeout(stallId); };
  const headerTimer = setTimeout(() => controller.abort(new Error("download stalled before response")), headerTimeout);
  let totalTimer, stallId;
  const resetStall = () => {
    clearTimeout(stallId);
    stallId = setTimeout(() => controller.abort(new Error("download stalled")), stallTimeout);
  };
  let response, target = new URL(url);
  try {
    for (let redirects = 0; redirects <= 3; redirects++) {
      response = await fetch(target, { headers, signal: controller.signal, redirect: "manual" });
      if (![301, 302, 303, 307, 308].includes(response.status)) break;
      if (!allowGithubRedirects || redirects === 3) {
        await response.body?.cancel().catch(() => {});
        throw Error("artifact redirect is not permitted");
      }
      const location = response.headers.get("location");
      if (!location) { await response.body?.cancel().catch(() => {}); throw Error("artifact redirect is invalid"); }
      const next = new URL(location, target);
      const githubHosts = new Set([
        "github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com", "github-releases.githubusercontent.com",
      ]);
      if (next.protocol !== "https:" || next.username || next.password ||
          !(next.hostname === target.hostname || (githubHosts.has(target.hostname) && githubHosts.has(next.hostname)))) {
        await response.body?.cancel().catch(() => {});
        throw Error("artifact redirect is outside the trusted download hosts");
      }
      await response.body?.cancel().catch(() => {});
      target = next;
    }
  } catch (error) {
    clearTimers();
    throw error;
  }
  clearTimeout(headerTimer);
  totalTimer = setTimeout(() => controller.abort(new Error("download exceeded overall limit")), timeout);
  if (response.body) {
    resetStall();
    const reader = response.body.getReader();
    const stream = new ReadableStream({
      async pull(target) {
        resetStall();
        try {
          const { value, done } = await reader.read();
          if (done) { clearTimers(); target.close(); }
          else { resetStall(); target.enqueue(value); }
        } catch (error) { clearTimers(); target.error(error); }
      },
      cancel(reason) { clearTimers(); return reader.cancel(reason); },
    });
    Object.defineProperty(response, "body", { value: stream });
  } else clearTimers();
  return response;
}
export async function probeArtifactRange(url, { timeout = 5000 } = {}) {
  const response = await request(url, {
    headers: { Range: "bytes=0-65535", "Accept-Encoding": "identity" },
    timeout, headerTimeout: timeout, stallTimeout: timeout, allowGithubRedirects: true,
  });
  if (response.status !== 206) { await response.body?.cancel().catch(() => {}); return false; }
  const match = response.headers.get("content-range")?.match(/^bytes 0-(\d+)\/(\d+)$/);
  if (!match || Number(match[1]) > 65535 || Number(match[2]) <= Number(match[1])) {
    await response.body?.cancel().catch(() => {});
    return false;
  }
  let received = 0;
  try {
    for await (const chunk of response.body || []) {
      received += chunk.length;
      if (received > 65536) { await response.body?.cancel().catch(() => {}); return false; }
    }
  } catch { return false; }
  return received === Number(match[1]) + 1;
}

export async function downloadArtifact({ assignment, artifactUrl, relayUrl, controlBase, trustedOrigin, installationId,
  token, staging, onProgress, overallMs = TOTAL_MS, directStallMs = 30000, allowInsecureTest = false }) {
  let direct;
  try { direct = new URL(artifactUrl); } catch { throw Error("invalid direct artifact URL"); }
  const insecureLoopback = allowInsecureTest && ["127.0.0.1", "::1", "localhost"].includes(direct.hostname);
  if (!/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(assignment?.version || "") ||
      !/^[a-f0-9]{64}$/.test(assignment?.artifactChecksum || "") ||
      !trustedOrigin || direct.origin !== trustedOrigin || direct.username || direct.password ||
      (direct.protocol !== "https:" && !(direct.protocol === "http:" && insecureLoopback))) throw Error("direct artifact is outside its trusted origin");
  const control = new URL(controlBase);
  if (control.protocol !== "https:" && !(allowInsecureTest && control.protocol === "http:" &&
      ["127.0.0.1", "::1", "localhost"].includes(control.hostname))) throw Error("Control relay base must use trusted HTTPS");
  await mkdir(staging, { recursive: true, mode: 0o700 });
  const stageStat = await lstat(staging);
  if (!stageStat.isDirectory() || stageStat.isSymbolicLink() || stageStat.uid !== process.getuid() ||
      (stageStat.mode & 0o077)) throw Error("unsafe staging directory");
  const archive = `${staging}/routly-node-${assignment.version}-linux-amd64.tar.gz`;
  const part = `${archive}.part`;
  try {
    const archiveSize = await safeFile(archive);
    if (archiveSize && await hashFile(archive) === assignment.artifactChecksum) return { archive, size: archiveSize, transport: "replay", retry: 0 };
    if (archiveSize) await unlink(archive);
  } catch (error) { if (error.code !== "ENOENT") throw error; }
  const lock = `${part}.lock`;
  let lockHandle;
  for (let tries = 0; tries < 2; tries++) {
    try {
      lockHandle = await open(lock, "wx", 0o600);
      await lockHandle.writeFile(`${process.pid}\n`);
      await lockHandle.sync();
      break;
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
      try {
        const lockStat = await lstat(lock);
        if (!lockStat.isFile() || lockStat.isSymbolicLink() || lockStat.uid !== process.getuid() ||
            (lockStat.mode & 0o077)) throw Error("unsafe transfer lock");
        const owner = Number((await readFile(lock, "utf8")).trim());
        if (!Number.isInteger(owner) || owner < 1) throw Error("unsafe transfer lock");
        try { process.kill(owner, 0); throw Error("another process owns the artifact transfer"); }
        catch (probeError) {
          if (probeError.message === "another process owns the artifact transfer") throw probeError;
          if (probeError.code !== "ESRCH") throw Error("cannot verify transfer lock owner");
          await unlink(lock);
        }
      } catch (lockError) { if (lockError.code !== "ENOENT") throw lockError; }
    }
  }
  if (!lockHandle) throw Error("another process owns the artifact transfer");
  const started = Date.now();
  let retry = 0, transport = "github";
  try {
    let size = await safeFile(part);
    if (size > MAX_SIZE) throw Error("partial artifact exceeds bounded size");
    if (size && await hashFile(part) === assignment.artifactChecksum) {
      await rename(part, archive);
      return { archive, size, transport, retry };
    }
    const relay = relayUrl ? new URL(relayUrl, controlBase) : null;
    if (relay && (relay.origin !== control.origin || relay.username || relay.password ||
        !installationId || relay.pathname !== `/api/control/agent/installations/${installationId}/artifact/${assignment.version}`)) {
      throw Error("relay URL is not the assigned Control artifact route");
    }
    let useRelay = false;
    while (Date.now() - started < overallMs) {
      try {
        const remaining = overallMs - (Date.now() - started);
        if (!useRelay) {
          transport = "github";
          const headers = size ? { Range: `bytes=${size}-`, "Accept-Encoding": "identity" } : { "Accept-Encoding": "identity" };
          const response = await request(artifactUrl, { headers, timeout: remaining, headerTimeout: directStallMs,
            stallTimeout: directStallMs, allowGithubRedirects: true });
          if (response.status === 416 && size > 0) {
            await response.body?.cancel().catch(() => {});
            await unlink(part).catch(() => {});
            size = 0;
            throw Error("partial range is not resumable");
          }
          await appendResponse(response, part, size, size ? { start: size, end: null, total: null, maxBytes: MAX_SIZE } : null, onProgress, transport, retry);
        } else {
          if (!relay) throw Error("trusted Control relay unavailable");
          transport = "relay";
          // Relay uses the installation credential and never forwards it to the
          // external artifact host. Each request is bounded to a 2 MiB range.
          const contentSize = Number(assignment.artifactSize) || 0;
          const end = contentSize ? Math.min(size + CHUNK - 1, contentSize - 1) : size + CHUNK - 1;
          const response = await request(relay.href, {
            headers: { "X-Routly-Installation-Token": token, Range: `bytes=${size}-${end}`, "Accept-Encoding": "identity" },
            timeout: remaining,
          });
          if (response.status === 200 && size > 0) {
            await unlink(part).catch(() => {});
            size = 0;
            throw Object.assign(Error("relay requires a safe full restart"), { restart: true });
          }
          if (response.status === 416 && size > 0) {
            await response.body?.cancel().catch(() => {});
            await unlink(part).catch(() => {});
            size = 0;
            throw Object.assign(Error("partial range is not resumable"), { restart: true });
          }
          const result = await appendResponse(response, part, size,
            { start: size, end: contentSize ? Math.min(end, contentSize - 1) : null, total: contentSize || null, maxBytes: CHUNK },
            onProgress, transport, retry);
          if (result.totalBytes) assignment.artifactSize = result.totalBytes;
        }
        size = await safeFile(part);
        if (size > MAX_SIZE) throw Error("artifact exceeds bounded download size");
        if (assignment.artifactSize && size < assignment.artifactSize && useRelay) continue;
        if (await hashFile(part) !== assignment.artifactChecksum) {
          throw Object.assign(Error("artifact checksum mismatch"), { integrity: true });
        }
        await rename(part, archive);
        return { archive, size, transport, retry };
      } catch (error) {
        if (error.restart) { size = 0; continue; }
        size = await safeFile(part);
        if (/checksum mismatch/.test(error.message)) {
          await unlink(part).catch(() => {});
          size = 0;
        }
        if (!useRelay && !error.integrity) {
          useRelay = true;
          await onProgress({ bytesReceived: await safeFile(part), totalBytes: assignment.artifactSize || null, retry, transport: "relay", phase: "retry_wait" });
          continue;
        }
        if (retry >= 3) throw error;
        retry += 1;
        await onProgress({ bytesReceived: await safeFile(part), totalBytes: assignment.artifactSize || null, retry, transport, phase: "retry_wait" });
        await sleep(Math.min(1000 * 2 ** (retry - 1), Math.max(1, overallMs - (Date.now() - started))));
      }
    }
    throw Error("artifact download exceeded the ten-minute limit");
  } finally {
    await lockHandle.close();
    await unlink(lock).catch(() => {});
  }
}