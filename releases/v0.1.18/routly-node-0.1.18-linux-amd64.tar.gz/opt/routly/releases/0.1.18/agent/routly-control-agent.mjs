#!/usr/bin/env node
/* Unprivileged Control poller. Network assignments are signed before artifact
 * access; activation is delegated only to the fixed package updater command. */
import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, unlink, writeFile, open, lstat, readlink } from "node:fs/promises";
import { unlinkSync } from "node:fs";
import { dirname, join } from "node:path";
import { spawn } from "node:child_process";
import { lookup } from "node:dns/promises";
import { setTimeout as sleep } from "node:timers/promises";
import { downloadArtifact, probeArtifactRange } from "./routly-agent-download.mjs";
import { parseRootProgress, safeError, strictVersion, verifyAssignment } from "./routly-agent-security.mjs";

const required = name => { if (!process.env[name]) throw Error(`${name} is required`); return process.env[name]; };
const base = required("ROUTLY_CONTROL_URL").replace(/\/$/, "");
const id = required("ROUTLY_CONTROL_INSTALLATION_ID");
const token = required("ROUTLY_CONTROL_INSTALLATION_TOKEN");
const versionUrl = required("ROUTLY_VERSION_URL");
const testMode = process.env.ROUTLY_TEST_MODE === "1" && process.env.ROUTLY_FILESYSTEM_ROOT && process.env.ROUTLY_FILESYSTEM_ROOT !== "/";
const controlUrl = new URL(base);
if ((!testMode && controlUrl.protocol !== "https:") || !["http:", "https:"].includes(controlUrl.protocol) ||
    controlUrl.username || controlUrl.password || controlUrl.pathname !== "/" || controlUrl.search || controlUrl.hash) {
  throw Error("ROUTLY_CONTROL_URL must be a trusted HTTPS base");
}
const origin = required("ROUTLY_UPDATE_ORIGIN");
const originUrl = new URL(origin);
if ((!testMode && originUrl.protocol !== "https:") || !["http:", "https:"].includes(originUrl.protocol) ||
    originUrl.pathname !== "/" || originUrl.search || originUrl.hash) throw Error("ROUTLY_UPDATE_ORIGIN must be an HTTPS origin");
let serverInstanceId = process.env.ROUTLY_SERVER_INSTANCE_ID?.trim();
if (!serverInstanceId) {
  try { serverInstanceId = (await readFile(process.env.ROUTLY_SERVER_INSTANCE_ID_FILE || "/etc/routly/instance-id", "utf8")).trim(); }
  catch (error) { if (!testMode || error.code !== "ENOENT") throw error; }
}
if (serverInstanceId && !/^[a-f0-9]{64}$/i.test(serverInstanceId)) throw Error("ROUTLY_SERVER_INSTANCE_ID must be a 64-character host identity");
const statePath = process.env.ROUTLY_CONTROL_STATE_FILE || "/var/lib/routly/agent/state.json";
const processLockPath = `${statePath}.agent-lock`;
const diagnosticPath = `${statePath}.diagnostics`;
const staging = testMode && process.env.ROUTLY_STAGING_DIR ? process.env.ROUTLY_STAGING_DIR : "/var/lib/routly/agent/staging";
const helper = testMode && process.env.ROUTLY_SUDO_COMMAND ? process.env.ROUTLY_SUDO_COMMAND : "/usr/bin/sudo";
const updater = "/usr/bin/routly-package-updater";
const pollInterval = Math.max(10000, Number(process.env.ROUTLY_CONTROL_POLL_MS || 60000));
const heartbeatInterval = testMode ? Math.max(100, Number(process.env.ROUTLY_TEST_HEARTBEAT_MS || 5000))
  : Math.max(5000, Math.min(pollInterval, 15000));
const oneShot = process.argv.includes("--once");
const headers = { "content-type": "application/json", "X-Routly-Installation-Token": token };
const assignmentPath = `/api/control/agent/installations/${id}`;
const capabilities = ["operations-v1", "relay-v1", "progress-v1"];
const currentLink = testMode
  ? join(process.env.ROUTLY_FILESYSTEM_ROOT, "opt/routly/current")
  : "/opt/routly/current";

async function acquireAgentLock() {
  await mkdir(dirname(statePath), { recursive: true, mode: 0o700 });
  const stateDirectory = await lstat(dirname(statePath));
  if (!stateDirectory.isDirectory() || stateDirectory.isSymbolicLink() ||
      stateDirectory.uid !== process.getuid() || (stateDirectory.mode & 0o077)) throw Error("unsafe agent state directory");
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const lock = await open(processLockPath, "wx", 0o600);
      try { await lock.writeFile(`${process.pid}\n`); await lock.sync(); } finally { await lock.close(); }
      const directory = await open(dirname(statePath), "r");
      try { await directory.sync(); } finally { await directory.close(); }
      process.once("exit", () => { try { unlinkSync(processLockPath); } catch {} });
      return;
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      try {
        const stat = await lstat(processLockPath);
        if (!stat.isFile() || stat.isSymbolicLink() || stat.uid !== process.getuid() || (stat.mode & 0o077)) {
          throw Error("unsafe agent process lock");
        }
        const owner = Number((await readFile(processLockPath, "utf8")).trim());
        if (!Number.isInteger(owner) || owner < 1) throw Error("unsafe agent process lock");
        try { process.kill(owner, 0); throw Error("another Control agent process is active"); }
        catch (probeError) {
          if (probeError.message === "another Control agent process is active") throw probeError;
          if (probeError.code !== "ESRCH") throw Error("cannot verify agent process lock");
          await unlink(processLockPath);
        }
      } catch (lockError) { if (lockError.code !== "ENOENT") throw lockError; }
    }
  }
  throw Error("another Control agent process is active");
}
await acquireAgentLock();

async function version() {
  const response = await fetch(versionUrl, { signal: AbortSignal.timeout(10000), redirect: "error" });
  if (!response.ok) throw Error(`version endpoint returned ${response.status}`);
  const value = (await response.text()).trim().replace(/^"|"$/g, "");
  if (!strictVersion(value)) throw Error("local version is not strict semver");
  return value;
}
async function installedReleaseVersion() {
  try {
    const linkStat = await lstat(currentLink);
    if (!linkStat.isSymbolicLink()) throw Error("current release path is not a symlink");
    const target = await readlink(currentLink);
    const match = target.match(/^\/opt\/routly\/releases\/((?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*))$/);
    if (!match) throw Error("current release target is invalid");
    const root = testMode ? join(process.env.ROUTLY_FILESYSTEM_ROOT, target.slice(1)) : target;
    const releaseStat = await lstat(root);
    if (!releaseStat.isDirectory() || releaseStat.isSymbolicLink() ||
        (!testMode && releaseStat.uid !== 0) || (releaseStat.mode & 0o022)) throw Error("current release directory is unsafe");
    const manifestPath = join(root, "release-manifest.json");
    const manifestStat = await lstat(manifestPath);
    if (!manifestStat.isFile() || manifestStat.isSymbolicLink() ||
        (!testMode && manifestStat.uid !== 0) || (manifestStat.mode & 0o022)) throw Error("current release manifest is unsafe");
    const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
    if (manifest.product !== "routly-node" || manifest.version !== match[1]) throw Error("current release identity mismatch");
    return match[1];
  } catch (error) { if (error.code === "ENOENT") return null; throw error; }
}
let localApiHealthy = false;
async function observedVersion(state) {
  try {
    const value = await version();
    localApiHealthy = true;
    return value;
  } catch (error) {
    localApiHealthy = false;
    const installed = await installedReleaseVersion();
    if (installed) return installed;
    throw error;
  }
}
async function post(path, body) {
  const response = await fetch(`${base}${path}`, { method: "POST", headers, body: JSON.stringify(body), signal: AbortSignal.timeout(15000), redirect: "error" });
  if (!response.ok) throw Error(`Control returned ${response.status}`);
  return response.json().catch(() => ({}));
}
async function load() {
  try {
    const stat = await lstat(statePath);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.uid !== process.getuid() || (stat.mode & 0o077)) throw Error("unsafe persisted state");
    const state = JSON.parse(await readFile(statePath, "utf8"));
    if (state.installationId !== id || !state.assignment?.assignmentId || !strictVersion(state.assignment.version) ||
        !state.attemptId || !strictVersion(state.previousVersion)) throw Error("invalid persisted state");
    return state;
  } catch (error) { if (error.code === "ENOENT") return null; throw error; }
}
let writeQueue = Promise.resolve();
async function save(state) {
  const operation = writeQueue.catch(() => {}).then(async () => {
    await mkdir(dirname(statePath), { recursive: true, mode: 0o700 });
    const directory = await lstat(dirname(statePath));
    if (!directory.isDirectory() || directory.isSymbolicLink() || directory.uid !== process.getuid() ||
        (directory.mode & 0o077)) throw Error("unsafe state directory");
    const temp = `${statePath}.${process.pid}.${randomUUID()}.tmp`;
    const handle = await open(temp, "wx", 0o600);
    try { await handle.writeFile(JSON.stringify(state) + "\n"); await handle.sync(); }
    finally { await handle.close(); }
    await rename(temp, statePath);
    const parent = await open(dirname(statePath), "r");
    try { await parent.sync(); } finally { await parent.close(); }
  });
  writeQueue = operation.catch(() => {});
  return operation;
}
async function clearAttempt(attemptId) {
  await stopProgressPersistence(attemptId);
  const operation = writeQueue.catch(() => {}).then(async () => {
    const current = await load();
    if (current?.attemptId === attemptId) {
      await unlink(statePath).catch(error => { if (error.code !== "ENOENT") throw error; });
      const parent = await open(dirname(statePath), "r");
      try { await parent.sync(); } finally { await parent.close(); }
    }
  });
  writeQueue = operation.catch(() => {});
  return operation;
}
async function persistDiagnostic(value) {
  const temp = `${diagnosticPath}.${process.pid}.${randomUUID()}.tmp`;
  const handle = await open(temp, "wx", 0o600);
  try { await handle.writeFile(JSON.stringify(value) + "\n"); await handle.sync(); } finally { await handle.close(); }
  await rename(temp, diagnosticPath);
  const parent = await open(dirname(diagnosticPath), "r");
  try { await parent.sync(); } finally { await parent.close(); }
}
async function readDiagnostic() {
  try {
    const stat = await lstat(diagnosticPath);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.uid !== process.getuid() || (stat.mode & 0o077)) throw Error("unsafe diagnostic result");
    return JSON.parse(await readFile(diagnosticPath, "utf8"));
  } catch (error) { if (error.code === "ENOENT") return null; throw error; }
}
async function replayDiagnostic() {
  const pending = await readDiagnostic();
  if (!pending) return;
  await post(`${assignmentPath}/diagnostics/${encodeURIComponent(pending.id)}/result`, pending.result);
  await unlink(diagnosticPath).catch(error => { if (error.code !== "ENOENT") throw error; });
  const parent = await open(dirname(diagnosticPath), "r");
  try { await parent.sync(); } finally { await parent.close(); }
}
const progressFor = state => ({
  attemptId: state.attemptId, assignmentId: state.assignment.assignmentId,
  phase: state.progress?.phase || "preparing",
  bytesReceived: state.progress?.bytesReceived || 0, totalBytes: state.progress?.totalBytes ?? null,
  retry: state.progress?.retry || 0, transport: state.progress?.transport || null,
  errorCode: state.progress?.errorCode || null, updatedAt: state.progress?.updatedAt || new Date().toISOString(),
});
const attemptBody = (state, status, extra = {}) => ({
  attemptId: state.attemptId, assignmentId: state.assignment.assignmentId,
  targetVersion: state.assignment.version, previousVersion: state.previousVersion, status, ...extra,
});
async function report(state, payload) {
  await stopProgressPersistence(state.attemptId);
  state.pendingReport = payload;
  await save(state);
  await post(`${assignmentPath}/attempts`, payload);
  await clearAttempt(state.attemptId);
}
const progressPersistence = new Map();
async function stopProgressPersistence(attemptId) {
  const marker = progressPersistence.get(attemptId);
  if (!marker) return;
  clearTimeout(marker.timer);
  marker.timer = null;
  if (marker.pendingSave) await marker.pendingSave;
  progressPersistence.delete(attemptId);
}
async function updateProgress(state, values) {
  state.progress = { ...state.progress, ...values, updatedAt: new Date().toISOString() };
  const id = state.attemptId;
  const marker = progressPersistence.get(id) || { bytesReceived: 0, persistedAt: 0, timer: null };
  progressPersistence.set(id, marker);
  const phaseChanged = values.phase && values.phase !== marker.phase;
  marker.phase = values.phase || marker.phase;
  const bytesReceived = state.progress.bytesReceived || 0;
  if (phaseChanged || bytesReceived - marker.bytesReceived >= 1024 * 1024 || Date.now() - marker.persistedAt >= 2000) {
    clearTimeout(marker.timer);
    marker.timer = null;
    marker.bytesReceived = bytesReceived;
    marker.persistedAt = Date.now();
    await save(state);
  } else if (!marker.timer) {
    marker.timer = setTimeout(() => {
      marker.timer = null;
      marker.bytesReceived = state.progress.bytesReceived || 0;
      marker.persistedAt = Date.now();
      const pending = save(state);
      marker.pendingSave = pending;
      void pending.catch(() => {}).finally(() => {
        if (marker.pendingSave === pending) marker.pendingSave = null;
      });
    }, 2000);
  }
}

async function pinnedKey() {
  const keyPath = testMode && process.env.ROUTLY_RELEASE_PUBLIC_KEY
    ? process.env.ROUTLY_RELEASE_PUBLIC_KEY
    : "/etc/routly/release-signing-public.pem";
  const keyStat = await lstat(keyPath);
  if (!keyStat.isFile() || keyStat.isSymbolicLink() || (!testMode && keyStat.uid !== 0) ||
      (keyStat.mode & 0o022)) throw Error("unsafe pinned signing key");
  return readFile(keyPath);
}
async function trustedArtifact(versionTarget, state) {
  const candidate = state?.assignment?.version === versionTarget ? state.assignment : null;
  if (candidate) {
    if (testMode && !process.env.ROUTLY_RELEASE_PUBLIC_KEY) {
      const url = new URL(candidate.artifactUrl);
      return url.origin === originUrl.origin ? candidate.artifactUrl : null;
    }
    try { verifyAssignment(candidate, originUrl.origin, await pinnedKey()); return candidate.artifactUrl; }
    catch { return null; }
  }
  try {
    const metadata = JSON.parse(await readFile(join(staging, "release-metadata.json"), "utf8"));
    const signature = (await readFile(join(staging, "release-metadata.sig"))).toString("base64");
    const assignment = { version: metadata.version, artifactUrl: metadata.artifactUrl,
      artifactChecksum: metadata.packageSha256, packageSignature: signature };
    if (assignment.version === versionTarget) {
      verifyAssignment(assignment, originUrl.origin, await pinnedKey());
      return assignment.artifactUrl;
    }
  } catch {}
  try {
    const response = await fetch(`${base}${assignmentPath}/bootstrap-release`, {
      headers: { "X-Routly-Installation-Token": token }, redirect: "error", signal: AbortSignal.timeout(5000),
    });
    if (!response.ok) return null;
    const descriptor = await response.json();
    const assignment = { version: descriptor.version, artifactUrl: descriptor.artifactUrl,
      artifactChecksum: descriptor.artifactChecksum, packageSignature: descriptor.packageSignature };
    if (descriptor.version !== versionTarget || descriptor.updateOrigin !== originUrl.origin) return null;
    verifyAssignment(assignment, originUrl.origin, await pinnedKey());
    return assignment.artifactUrl;
  } catch { return null; }
}
async function boundedRangeProbe(url, rangeHeaders = {}) {
  const response = await fetch(url, { method: "GET", headers: { ...rangeHeaders, Range: "bytes=0-65535", "Accept-Encoding": "identity" },
    redirect: "error", signal: AbortSignal.timeout(5000) });
  if (response.status !== 206) { await response.body?.cancel().catch(() => {}); return false; }
  const header = response.headers.get("content-range");
  const match = header?.match(/^bytes 0-(\d+)\/(\d+)$/);
  if (!match || Number(match[1]) > 65535 || Number(match[2]) <= Number(match[1])) {
    await response.body?.cancel().catch(() => {});
    return false;
  }
  let bytes = 0;
  try {
    if (!response.body) return false;
    for await (const chunk of response.body) {
      bytes += chunk.length;
      if (bytes > 65536) { await response.body.cancel(); return false; }
    }
  } catch { return false; }
  return bytes === Number(match[1]) + 1;
}
async function withTimeout(promise, milliseconds) {
  let timer;
  try {
    return await Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => reject(Object.assign(Error("operation timed out"), { code: "ETIMEDOUT" })), milliseconds);
    })]);
  } finally { clearTimeout(timer); }
}
async function probe(name, state, requestedVersion) {
  const start = Date.now(), check = { name, status: "failed", durationMs: 0 };
  const finish = (status, message, extra = {}) => ({ ...check, status, durationMs: Date.now() - start, message: safeError(message), ...extra });
  try {
    if (name === "origin_dns_v4" || name === "origin_dns_v6") {
      const family = name.endsWith("v4") ? 4 : 6;
      await withTimeout(lookup(originUrl.hostname, { family, all: true, verbatim: true }), 5000);
      return finish("ok", "DNS resolution succeeded");
    }
    if (name === "control_http") {
      const response = await fetch(base, { method: "HEAD", redirect: "error", signal: AbortSignal.timeout(5000) });
      return finish(response.status < 500 ? "ok" : "failed", response.status < 500 ? "Control reachable" : `Control returned ${response.status}`);
    }
    if (name === "relay_http") {
      const versionTarget = requestedVersion || state?.assignment?.version || currentVersion;
      if (!strictVersion(versionTarget)) return finish("failed", "no authorized release version");
      if (!await trustedArtifact(versionTarget, state)) return finish("failed", "no signed artifact authorizes this relay route");
      const target = `${base}${assignmentPath}/artifact/${versionTarget}`;
      const ok = await boundedRangeProbe(target, { "X-Routly-Installation-Token": token });
      return finish(ok ? "ok" : "failed", ok ? "Control relay range reachable" : "Control relay range probe failed");
    }
    if (name === "origin_http") {
      const versionTarget = requestedVersion || state?.assignment?.version || currentVersion;
      if (!strictVersion(versionTarget)) return finish("failed", "no authorized release version");
      const artifactUrl = await trustedArtifact(versionTarget, state);
      if (!artifactUrl) return finish("failed", "no signed artifact available for this release");
      const ok = await probeArtifactRange(artifactUrl);
      return finish(ok ? "ok" : "failed", ok ? "signed artifact range reachable" : "signed artifact range probe failed");
    }
    if (name === "local_api") {
      const response = await fetch(versionUrl, { redirect: "error", signal: AbortSignal.timeout(5000) });
      if (!response.ok) return finish("failed", `local version endpoint returned ${response.status}`);
      const value = (await response.text()).trim().replace(/^"|"$/g, "");
      return finish(strictVersion(value) ? "ok" : "failed", strictVersion(value) ? "local API version reachable" : "local API version invalid");
    }
    return finish("failed", "unknown diagnostic");
  } catch (error) {
    const timeout = error.name === "AbortError" || /timed out/i.test(error.message || "");
    if (name === "origin_dns_v6" && ["ENODATA", "ENOTFOUND", "EAI_NONAME"].includes(error.code)) {
      return finish("ok", "IPv6 DNS unavailable; IPv4 check is authoritative");
    }
    return finish(timeout ? "timeout" : "failed", timeout ? "probe timed out" : "probe failed");
  }
}
async function processDiagnostic(diagnostic, state) {
  const resultPath = `${assignmentPath}/diagnostics/${encodeURIComponent(diagnostic.id)}/result`;
  await post(resultPath, { status: "running", checks: [] });
  const checks = [];
  const requestedVersion = diagnostic.releaseVersion || state?.assignment?.version || currentVersion;
  for (const name of ["control_http", "origin_dns_v4", "origin_dns_v6", "origin_http", "relay_http", "local_api"]) {
    checks.push(await probe(name, state, requestedVersion));
  }
  const status = checks.every(check => check.status === "ok") ? "succeeded" : "failed";
  const result = { status, checks };
  await persistDiagnostic({ id: diagnostic.id, result });
  await replayDiagnostic();
}

let heartbeatActive = false;
let activeState = null;
let currentVersion = null;
let retrySoon = false;
const diagnosticsActive = new Set();
function scheduleDiagnostic(diagnostic, state) {
  if (!diagnostic || typeof diagnostic.id !== "string" || !/^[A-Za-z0-9_-]{1,128}$/.test(diagnostic.id) ||
      diagnostic.kind !== "connectivity" ||
      !strictVersion(diagnostic.releaseVersion || state?.assignment?.version || currentVersion || "")) return;
  const key = `diagnostic:${diagnostic.id}`;
  if (state?.completedDiagnostics?.includes(diagnostic.id) || diagnosticsActive.has(key)) return;
  const expires = diagnostic.expiresAt ? Date.parse(diagnostic.expiresAt) : Infinity;
  if ((diagnostic.expiresAt && !Number.isFinite(expires)) || expires <= Date.now()) return;
  diagnosticsActive.add(key);
  void (async () => {
    const pending = await readDiagnostic();
    if (pending) { await replayDiagnostic(); return; }
    await processDiagnostic(diagnostic, state);
    const persisted = activeState || await load();
    if (persisted) {
      persisted.completedDiagnostics = [...new Set([...(persisted.completedDiagnostics || []), diagnostic.id])].slice(-64);
      await save(persisted);
    }
  })().catch(() => {}).finally(() => diagnosticsActive.delete(key));
}
async function heartbeat() {
  if (heartbeatActive) return;
  heartbeatActive = true;
  try {
    const state = activeState || await load();
    const response = await post(`${assignmentPath}/heartbeat`, {
      currentVersion: currentVersion || state?.previousVersion || null,
      status: state ? "updating" : "updated", capabilities,
      ...(state ? { progress: progressFor(state) } : {}),
      ...(serverInstanceId ? { serverInstanceId } : {}),
    });
    scheduleDiagnostic(response.diagnostic, state);
  } finally { heartbeatActive = false; }
}

async function verifyAttemptAssignment(state) {
  const keyPath = testMode && process.env.ROUTLY_RELEASE_PUBLIC_KEY
    ? process.env.ROUTLY_RELEASE_PUBLIC_KEY
    : "/etc/routly/release-signing-public.pem";
  let publicKey;
  try {
    const keyStat = await lstat(keyPath);
    if (!keyStat.isFile() || keyStat.isSymbolicLink() || (!testMode && keyStat.uid !== 0) ||
        (keyStat.mode & 0o022)) throw Error("unsafe pinned signing key");
    publicKey = await readFile(keyPath);
  }
  catch (error) {
    // Compatibility for legacy disposable tests only. Real installations never
    // bypass signature verification and bootstrap installs the pinned key.
    if (!testMode || !process.env.ROUTLY_SUDO_COMMAND) throw Error("pinned release-signing key is unavailable");
  }
  if (publicKey) verifyAssignment(state.assignment, originUrl.origin, publicKey);
  else {
    let assignedUrl;
    try { assignedUrl = new URL(state.assignment.artifactUrl); } catch { throw Error("invalid test assignment URL"); }
    if (assignedUrl.origin !== originUrl.origin || !/^[a-f0-9]{64}$/.test(state.assignment.artifactChecksum || "")) {
      throw Error("artifact origin is not trusted");
    }
  }
}
async function download(state) {
  await verifyAttemptAssignment(state);
  const { archive } = await downloadArtifact({
    assignment: state.assignment, artifactUrl: state.assignment.artifactUrl,
    relayUrl: state.assignment.relayUrl || state.relayUrl, controlBase: base,
    trustedOrigin: originUrl.origin, installationId: id, token, staging,
    allowInsecureTest: testMode,
    onProgress: values => updateProgress(state, { ...values, phase: values.phase || "downloading" }),
  });
  const checksum = state.assignment.artifactChecksum;
  const sidecar = `${archive}.sha256`, metaPath = join(staging, "release-metadata.json"), sigPath = join(staging, "release-metadata.sig");
  for (const path of [archive, sidecar, metaPath, sigPath]) {
    try { const st = await lstat(path); if (!st.isFile() || st.isSymbolicLink()) throw Error("unsafe staging file"); }
    catch (error) { if (error.code !== "ENOENT") throw error; }
  }
  await writeFile(sidecar, `${checksum}  ${archive.split("/").pop()}\n`, { mode: 0o600 });
  await writeFile(metaPath, JSON.stringify({ version: state.assignment.version, artifactUrl: state.assignment.artifactUrl, packageSha256: checksum }) + "\n", { mode: 0o600 });
  await writeFile(sigPath, Buffer.from(state.assignment.packageSignature || "", "base64"), { mode: 0o600 });
}

function runUpdater(state) {
  return new Promise((resolve, reject) => {
    const child = spawn(helper, helper === "/usr/bin/sudo" ? [updater, state.assignment.version] : [state.assignment.version], {
      stdio: ["ignore", "pipe", "ignore"], env: process.env,
    });
    let buffered = "";
    const progressJobs = [];
    child.stdout.setEncoding("utf8");
    const consumeLine = line => {
      if (line.length > 4096) return;
      const progress = parseRootProgress(line, state.assignment.version);
      if (progress) {
        state.rootPhase = progress.phase;
        progressJobs.push(updateProgress(state, { phase: progress.phase, updatedAt: progress.timestamp }));
      }
    };
    child.stdout.on("data", data => {
      buffered += data;
      const lines = buffered.split(/\r?\n/); buffered = lines.pop() || "";
      for (const line of lines) consumeLine(line);
      if (buffered.length > 4096) buffered = "";
    });
    child.on("error", () => reject(Error("privileged updater could not be started")));
    child.on("close", async code => {
      if (buffered) consumeLine(buffered);
      try { await Promise.all(progressJobs); }
      catch { reject(Error("updater progress could not be persisted")); return; }
      code === 0 ? resolve() : reject(Error("privileged updater failed"));
    });
  });
}

async function tick() {
  let state = await load();
  if (state?.pendingReport) {
    await post(`${assignmentPath}/attempts`, state.pendingReport);
    await clearAttempt(state.attemptId);
    return;
  }
  currentVersion = await observedVersion(state);
  await replayDiagnostic().catch(() => {});
  if (!state) {
    const poll = await post(`${assignmentPath}/heartbeat`, {
      currentVersion, status: localApiHealthy ? "updated" : "failed", capabilities, ...(serverInstanceId ? { serverInstanceId } : {}),
    });
    if (!poll.assignment) {
      scheduleDiagnostic(poll.diagnostic, null);
      return;
    }
    // A trusted current manifest supplies the installed version even when the
    // API is down. A signed Control assignment must still be able to repair it;
    // download() verifies its signature and the privileged helper re-verifies
    // it before changing services or the database.
    state = { installationId: id, assignment: poll.assignment, attemptId: randomUUID(), previousVersion: currentVersion,
      progress: { phase: "preparing", bytesReceived: 0, totalBytes: null, retry: 0, transport: null, errorCode: null, updatedAt: new Date().toISOString() },
      completedDiagnostics: [] };
    if (poll.relayUrl) state.relayUrl = poll.relayUrl;
    await save(state);
    activeState = state;
    scheduleDiagnostic(poll.diagnostic, state);
  }
  const timer = setInterval(() => { void heartbeat().catch(() => {}); }, heartbeatInterval);
  try {
    await post(`${assignmentPath}/attempts`, attemptBody(state, "updating"));
    await heartbeat();
    await verifyAttemptAssignment(state);
    const rootRecoveryPhases = new Set([
      "stopping", "stopped", "backed_up", "migrating", "migrated",
      "release_installed", "host_integrating", "activated", "healthy", "rolled_back", "failed",
    ]);
    const rootRecovery = currentVersion === state.assignment.version || rootRecoveryPhases.has(state.rootPhase);
    if (!rootRecovery) {
      await download(state);
      await updateProgress(state, { phase: "validating" });
    }
    state.rootPhase = null;
    await save(state);
    await runUpdater(state);
  } catch (error) {
    const recovered = await observedVersion(state).catch(() => null);
    if (state.rootPhase === "retry_wait" && (!localApiHealthy || recovered === state.previousVersion)) {
      retrySoon = true;
      await updateProgress(state, { phase: "retry_wait", errorCode: "updater_busy" });
      return;
    }
    const code = /checksum/i.test(error.message) ? "checksum_mismatch" : /signature/i.test(error.message) ? "signature_invalid" : "download_or_update_failed";
    await updateProgress(state, { phase: "failed", errorCode: code });
    // Merely observing the prior version is not evidence of rollback; only a
    // signed root progress event can authorize that terminal status.
    const terminal = state.rootPhase === "rolled_back" && recovered === state.previousVersion ? "rolled_back" : "failed";
    await report(state, attemptBody(state, terminal, {
      ...(terminal === "rolled_back" ? { rollbackVersion: state.previousVersion } : {}),
      error: safeError(error),
    }));
    return;
  } finally {
    clearInterval(timer);
    activeState = null;
  }
  const installed = await observedVersion(state).catch(() => null);
  await report(state, installed === state.assignment.version && localApiHealthy && state.rootPhase === "healthy"
    ? attemptBody(state, "success")
    : state.rootPhase === "rolled_back" && installed === state.previousVersion
      ? attemptBody(state, "rolled_back", { rollbackVersion: state.previousVersion })
      : attemptBody(state, "failed", { error: "root recovery did not confirm a healthy assigned release" }));
}

let delay = pollInterval;
const notifySocket = process.env.NOTIFY_SOCKET;
if (!testMode && ["/run/systemd/notify", "@/org/freedesktop/systemd1/notify"].includes(notifySocket)) {
  const watchdogTimer = setInterval(() => {
    const child = spawn("/usr/bin/systemd-notify", [`--pid=${process.pid}`, "WATCHDOG=1"], {
      stdio: "ignore", env: { NOTIFY_SOCKET: notifySocket },
    });
    const timeout = setTimeout(() => child.kill("SIGKILL"), 5000);
    child.once("close", () => clearTimeout(timeout));
    child.once("error", () => clearTimeout(timeout));
  }, 30000);
  watchdogTimer.unref();
}
do {
  try { await tick(); delay = retrySoon ? 15000 : pollInterval; retrySoon = false; }
  catch (error) { console.error(`Routly Control agent: ${safeError(error)}`); delay = Math.min(delay * 2, 900000); }
  if (!oneShot) await sleep(delay);
} while (!oneShot);