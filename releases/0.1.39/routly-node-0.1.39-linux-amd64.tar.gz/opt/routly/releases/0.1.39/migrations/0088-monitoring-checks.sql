ALTER TABLE monitoring_hosts
  ADD COLUMN icmp_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN poll_interval_seconds integer NOT NULL DEFAULT 5 CHECK (poll_interval_seconds IN (5, 10, 30, 60, 300)),
  ADD COLUMN next_poll_at timestamptz,
  ADD COLUMN polling_until timestamptz;
ALTER TABLE monitoring_host_samples
  ADD COLUMN latency_ms double precision,
  ADD COLUMN packet_loss_percent double precision,
  ADD COLUMN temperature_celsius double precision,
  ADD COLUMN check_status text,
  ADD COLUMN icmp_error text,
  ADD COLUMN snmp_error text;
ALTER TABLE monitoring_host_aggregates
  ADD COLUMN latency_ms double precision,
  ADD COLUMN packet_loss_percent double precision,
  ADD COLUMN temperature_celsius double precision;
