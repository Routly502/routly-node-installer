ALTER TABLE customer_services ADD COLUMN billing_start_date date;
CREATE TABLE customer_import_batches (
  id text PRIMARY KEY,
  source text NOT NULL,
  owner_user_id integer NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  router_id integer REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
  encrypted_snapshot text,
  selection_hash text,
  result jsonb,
  expires_at timestamptz NOT NULL,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX customer_import_batches_expiry_idx ON customer_import_batches(expires_at);
