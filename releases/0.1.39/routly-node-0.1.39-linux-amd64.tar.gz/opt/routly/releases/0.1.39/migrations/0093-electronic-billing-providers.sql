ALTER TABLE electronic_billing_settings ADD COLUMN encrypted_credentials text;
ALTER TABLE electronic_billing_settings DROP CONSTRAINT electronic_billing_settings_pkey;
ALTER TABLE electronic_billing_settings ADD PRIMARY KEY (country, provider, environment);
