CREATE TABLE electronic_billing_settings (
  country text NOT NULL,
  environment text NOT NULL,
  provider text NOT NULL,
  tax_id text NOT NULL,
  username text NOT NULL,
  encrypted_password text NOT NULL,
  connection_status text NOT NULL DEFAULT 'not_tested',
  last_checked_at timestamp with time zone,
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (country, environment)
);
