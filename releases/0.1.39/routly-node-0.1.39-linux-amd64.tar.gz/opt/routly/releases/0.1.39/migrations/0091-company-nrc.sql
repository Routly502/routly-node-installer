-- Preserve the NIT and existing company settings; NRC is an independent value.
ALTER TABLE company_settings ADD COLUMN IF NOT EXISTS nrc text NOT NULL DEFAULT '';
