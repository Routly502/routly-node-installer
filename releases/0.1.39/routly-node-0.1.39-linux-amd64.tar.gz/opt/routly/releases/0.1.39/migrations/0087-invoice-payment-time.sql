ALTER TABLE invoice_payments
  ADD COLUMN IF NOT EXISTS paid_at_time time without time zone;
