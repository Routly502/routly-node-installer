CREATE TABLE IF NOT EXISTS mikrotik_notice_configs (
  router_id integer PRIMARY KEY REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
  proxy_before jsonb NOT NULL,
  notice_origin text NOT NULL,
  status text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
