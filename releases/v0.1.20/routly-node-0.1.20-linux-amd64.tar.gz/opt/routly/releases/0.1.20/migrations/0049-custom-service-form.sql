ALTER TABLE custom_services ADD COLUMN IF NOT EXISTS fiscal_code TEXT;
ALTER TABLE custom_services ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE custom_services ADD CONSTRAINT custom_services_fiscal_code_check
  CHECK (fiscal_code IS NULL OR length(fiscal_code) <= 80);
ALTER TABLE custom_services ADD CONSTRAINT custom_services_description_check
  CHECK (description IS NULL OR length(description) <= 1000);

CREATE TABLE customer_custom_service_assignments (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  custom_service_id INTEGER NOT NULL REFERENCES custom_services(id) ON DELETE RESTRICT,
  price NUMERIC(12, 2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  recurring BOOLEAN NOT NULL DEFAULT FALSE,
  CONSTRAINT customer_custom_service_status_check CHECK (status IN ('active', 'suspended', 'retired')),
  CONSTRAINT customer_custom_service_price_check CHECK (price BETWEEN -999999999 AND 999999999)
);
CREATE INDEX customer_custom_service_catalog_idx ON customer_custom_service_assignments(custom_service_id);
CREATE INDEX customer_custom_service_customer_idx ON customer_custom_service_assignments(customer_id);
