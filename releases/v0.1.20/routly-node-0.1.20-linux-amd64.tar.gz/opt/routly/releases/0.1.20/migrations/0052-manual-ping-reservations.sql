CREATE TABLE IF NOT EXISTS manual_ping_reservations (
  token uuid PRIMARY KEY,
  user_id integer NOT NULL,
  router_id integer NOT NULL,
  active_until timestamptz NOT NULL,
  user_until timestamptz NOT NULL,
  router_until timestamptz NOT NULL,
  expires_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS manual_ping_reservations_user_idx ON manual_ping_reservations (user_id);
CREATE INDEX IF NOT EXISTS manual_ping_reservations_router_idx ON manual_ping_reservations (router_id);
