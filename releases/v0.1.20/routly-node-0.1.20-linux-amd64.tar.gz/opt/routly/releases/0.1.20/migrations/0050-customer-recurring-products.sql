ALTER TABLE customer_custom_service_assignments ALTER COLUMN custom_service_id DROP NOT NULL;
ALTER TABLE customer_custom_service_assignments
  ADD COLUMN product_id integer REFERENCES warehouse_products(id) ON DELETE SET NULL,
  ADD COLUMN name text,
  ADD COLUMN description text,
  ADD COLUMN serial_number text,
  ADD COLUMN mac_address text,
  ADD COLUMN tax_percentage numeric(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN installment_count integer NOT NULL DEFAULT 1,
  ADD COLUMN start_date date NOT NULL DEFAULT CURRENT_DATE,
  ADD COLUMN request_key uuid,
  ADD COLUMN created_at timestamptz NOT NULL DEFAULT now(),
  ADD CONSTRAINT customer_recurring_installments_check CHECK (installment_count BETWEEN 1 AND 24),
  ADD CONSTRAINT customer_recurring_tax_check CHECK (tax_percentage BETWEEN 0 AND 100);
UPDATE customer_custom_service_assignments a SET name = s.name, description = s.description,
  tax_percentage = s.tax_percentage FROM custom_services s WHERE s.id = a.custom_service_id;
CREATE UNIQUE INDEX customer_recurring_request_unique ON customer_custom_service_assignments(customer_id, request_key);
CREATE TABLE recurring_invoice_applications (
  id serial PRIMARY KEY,
  assignment_id integer NOT NULL REFERENCES customer_custom_service_assignments(id) ON DELETE CASCADE,
  invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  billing_period text NOT NULL,
  installment_number integer NOT NULL,
  amount numeric(12,2) NOT NULL
);
CREATE UNIQUE INDEX recurring_invoice_assignment_unique ON recurring_invoice_applications(invoice_id, assignment_id);
CREATE INDEX recurring_applications_assignment_idx ON recurring_invoice_applications(assignment_id);
