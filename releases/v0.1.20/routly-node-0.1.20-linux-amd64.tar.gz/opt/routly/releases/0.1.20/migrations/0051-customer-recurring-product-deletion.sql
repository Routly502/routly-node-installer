ALTER TABLE customer_custom_service_assignments
  DROP CONSTRAINT customer_custom_service_status_check;
ALTER TABLE customer_custom_service_assignments
  ADD CONSTRAINT customer_custom_service_status_check
  CHECK (status IN ('active', 'suspended', 'retired', 'deleted'));
