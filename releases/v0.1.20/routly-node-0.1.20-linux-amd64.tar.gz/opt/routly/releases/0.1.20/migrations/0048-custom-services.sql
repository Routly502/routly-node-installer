CREATE TABLE IF NOT EXISTS custom_services (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  price NUMERIC(12, 2) NOT NULL,
  tax_percentage NUMERIC(5, 2) NOT NULL DEFAULT 0,
  CONSTRAINT custom_services_name_check CHECK (length(btrim(name)) BETWEEN 1 AND 160),
  CONSTRAINT custom_services_price_check CHECK (price BETWEEN -999999999 AND 999999999),
  CONSTRAINT custom_services_tax_check CHECK (tax_percentage BETWEEN 0 AND 100)
);
