#!/usr/bin/env node
/* Unprivileged polling agent. It downloads only signed HTTPS packages and
 * delegates activation to the one fixed sudoers command. */
import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, unlink, writeFile, open } from "node:fs/promises";
import { createHash } from "node:crypto";
import { dirname } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
const exec = promisify(execFile);
const required = name => { if (!process.env[name]) throw new Error(`${name} is required`); return process.env[name]; };
const base = required("ROUTLY_CONTROL_URL").replace(/\/$/, "");
const id = required("ROUTLY_CONTROL_INSTALLATION_ID");
const token = required("ROUTLY_CONTROL_INSTALLATION_TOKEN");
const versionUrl = required("ROUTLY_VERSION_URL");
const testMode = process.env.ROUTLY_TEST_MODE === "1" && process.env.ROUTLY_FILESYSTEM_ROOT && process.env.ROUTLY_FILESYSTEM_ROOT !== "/";
let serverInstanceId = process.env.ROUTLY_SERVER_INSTANCE_ID?.trim();
if (!serverInstanceId) {
  try { serverInstanceId = (await readFile(process.env.ROUTLY_SERVER_INSTANCE_ID_FILE || "/etc/routly/instance-id", "utf8")).trim(); }
  catch (error) {
    if (!testMode || error.code !== "ENOENT") throw error;
  }
}
if (serverInstanceId && !/^[a-f0-9]{64}$/i.test(serverInstanceId)) throw Error("ROUTLY_SERVER_INSTANCE_ID must be a 64-character host identity");
const statePath = process.env.ROUTLY_CONTROL_STATE_FILE || "/var/lib/routly/agent/state.json";
const origin = required("ROUTLY_UPDATE_ORIGIN");
let originUrl;
try { originUrl = new URL(origin); } catch { throw Error("ROUTLY_UPDATE_ORIGIN must be an HTTPS origin"); }
if ((!testMode && originUrl.protocol !== "https:") || !["http:", "https:"].includes(originUrl.protocol) || originUrl.pathname !== "/" || originUrl.search || originUrl.hash) throw Error("ROUTLY_UPDATE_ORIGIN must be an HTTPS origin");
const staging = testMode && process.env.ROUTLY_STAGING_DIR ? process.env.ROUTLY_STAGING_DIR : "/var/lib/routly/agent/staging";
const helper = testMode && process.env.ROUTLY_SUDO_COMMAND ? process.env.ROUTLY_SUDO_COMMAND : "/usr/bin/sudo";
const updater = "/usr/bin/routly-package-updater";
const interval = Math.max(10000, Number(process.env.ROUTLY_CONTROL_POLL_MS || 60000));
const oneShot = process.argv.includes("--once");
const headers = { "content-type": "application/json", "X-Routly-Installation-Token": token };
const strict = v => /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(v);
const version = async () => { const r = await fetch(versionUrl, { signal: AbortSignal.timeout(10000) }); if (!r.ok) throw Error(`version endpoint returned ${r.status}`); const v = (await r.text()).trim().replace(/^"|"$/g, ""); if (!strict(v)) throw Error("local version is not strict semver"); return v; };
const post = async (path, body) => { const r = await fetch(`${base}${path}`, { method: "POST", headers, body: JSON.stringify(body) }); if (!r.ok) throw Error(`Control returned ${r.status}`); return r.json(); };
const load = async () => { try { const s = JSON.parse(await readFile(statePath, "utf8")); if (s.installationId !== id || !s.assignment?.assignmentId || !strict(s.assignment.version) || !s.attemptId || !strict(s.previousVersion)) throw Error("invalid persisted state"); return s; } catch (e) { if (e.code === "ENOENT") return null; throw e; } };
const save = async s => { await mkdir(dirname(statePath), { recursive: true, mode: 0o700 }); const t = `${statePath}.${process.pid}.tmp`; await writeFile(t, JSON.stringify(s) + "\n", { mode: 0o600 }); await rename(t, statePath); };
const clear = async () => unlink(statePath).catch(e => { if (e.code !== "ENOENT") throw e; });
const body = (s, status, extra = {}) => ({ attemptId: s.attemptId, assignmentId: s.assignment.assignmentId, targetVersion: s.assignment.version, previousVersion: s.previousVersion, status, ...extra });
const report = async (s, b) => { s.pendingReport = b; await save(s); await post(`/api/control/agent/installations/${id}/attempts`, b); await clear(); };
async function download(s) {
  const a = s.assignment;
  // Legacy disposable harnesses provide an activation executable instead of
  // a package URL. Production installations never set this variable.
   if (!a.artifactUrl || !a.packageSignature || (!testMode ? !/^https:\/\//.test(a.artifactUrl) : !/^https?:\/\//.test(a.artifactUrl))) throw Error("Control supplied an incomplete signed artifact");
  const artifact = new URL(a.artifactUrl);
  if (artifact.origin !== originUrl.origin) throw Error("Control supplied an artifact from an unpinned origin");
  if (!/^[0-9a-f]{64}$/.test(a.artifactChecksum)) throw Error("Control supplied an invalid checksum");
  await mkdir(staging, { recursive: true, mode: 0o700 });
  // ISP links can be slow or congested. Keep a finite ceiling, but allow enough
  // time for a validated release archive to download before declaring failure.
  const r = await fetch(a.artifactUrl, { signal: AbortSignal.timeout(600000) }); if (!r.ok) throw Error(`artifact returned ${r.status}`);
  const limit = 1024 * 1024 * 1024; let size = 0;
  if (!r.body) throw Error("artifact response has no body");
  const archive = `${staging}/routly-node-${a.version}-linux-amd64.tar.gz`;
  const temporary = `${archive}.${process.pid}.part`;
  const handle = await open(temporary, "wx", 0o600);
  const hash = createHash("sha256");
  for await (const chunk of r.body) {
    size += chunk.length;
    if (size > limit) { await handle.close(); await unlink(temporary).catch(() => {}); throw Error("artifact exceeds bounded download size"); }
    hash.update(chunk); await handle.write(chunk);
  }
  if (r.headers.get("content-length") && Number(r.headers.get("content-length")) > limit) {
    await handle.close(); await unlink(temporary).catch(() => {}); throw Error("artifact exceeds bounded download size");
  }
  if (hash.digest("hex") !== a.artifactChecksum) {
    await handle.close(); await unlink(temporary).catch(() => {}); throw Error("artifact checksum mismatch");
  }
  await handle.sync(); await handle.close(); await rename(temporary, archive);
  const sidecar = `${archive}.sha256`, sidecarTemp = `${sidecar}.${process.pid}.part`;
  const sidecarHandle = await open(sidecarTemp, "wx", 0o600);
  try {
    await sidecarHandle.write(`${a.artifactChecksum}  ${archive.split("/").pop()}\n`);
    await sidecarHandle.sync();
  } finally { await sidecarHandle.close(); }
  await rename(sidecarTemp, sidecar);
  await writeFile(`${staging}/release-metadata.json`, JSON.stringify({ version: a.version, artifactUrl: a.artifactUrl, packageSha256: a.artifactChecksum }) + "\n", { mode: 0o600 });
  await writeFile(`${staging}/release-metadata.sig`, Buffer.from(a.packageSignature, "base64"), { mode: 0o600 });
  await exec(helper, helper === "/usr/bin/sudo" ? [updater, a.version] : [a.version]);
}
async function tick() {
  let state = await load();
  const observed = await version().catch(error => {
    if (state?.previousVersion) return state.previousVersion;
    throw error;
  });
  const poll = await post(`/api/control/agent/installations/${id}/heartbeat`, { currentVersion: observed, status: state ? "updating" : "updated", ...(serverInstanceId ? { serverInstanceId } : {}) });
  if (state?.pendingReport) { await post(`/api/control/agent/installations/${id}/attempts`, state.pendingReport); await clear(); return; }
  if (state && observed === state.assignment.version) { await report(state, body(state, "success")); return; }
  if (!state) { if (!poll.assignment) return; state = { installationId: id, assignment: poll.assignment, attemptId: randomUUID(), previousVersion: observed }; await save(state); }
  await post(`/api/control/agent/installations/${id}/attempts`, body(state, "updating"));
  try { await download(state); } catch (e) {
    const recovered = await version().catch(() => null);
    const terminal = recovered === state.previousVersion ? "rolled_back" : "failed";
    await report(state, body(state, terminal, { rollbackVersion: terminal === "rolled_back" ? state.previousVersion : undefined, error: String(e).slice(0, 4000) }));
    return;
  }
  const installed = await version().catch(() => null);
  await report(state, installed === state.assignment.version
    ? body(state, "success")
    : installed === state.previousVersion
      ? body(state, "rolled_back", { rollbackVersion: state.previousVersion, error: "activation rolled back" })
      : body(state, "failed", { error: "activation did not report assigned version" }));
}
let delay = interval;
do { try { await tick(); delay = interval; } catch (e) { console.error(`Routly Control agent: ${e}`); delay = Math.min(delay * 2, 900000); } if (!oneShot) await new Promise(r => setTimeout(r, delay)); } while (!oneShot);