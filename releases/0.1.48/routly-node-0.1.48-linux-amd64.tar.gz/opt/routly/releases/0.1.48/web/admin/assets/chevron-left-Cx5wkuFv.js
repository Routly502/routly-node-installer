import{c as e}from"./index-Dq5QdWP3.js";const o=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],t=e("chevron-left",o);export{t as C};
