ALTER TABLE whatsapp_settings ADD COLUMN IF NOT EXISTS encrypted_api_key text;
ALTER TABLE whatsapp_settings ADD COLUMN IF NOT EXISTS next_send_at timestamptz;
CREATE INDEX IF NOT EXISTS whatsapp_outbox_attempted_idx ON whatsapp_outbox(attempted_at);
-- Do not transfer Meta credentials or send its pending messages through a different provider.
UPDATE whatsapp_settings SET
  config = (config - 'phoneNumberId' - 'businessAccountId' - 'apiVersion' - 'publicBaseUrl')
    || '{"provider":"automatizado-vip","enabled":false,"characterLimit":780,"messagePauseSeconds":2}'::jsonb,
  encrypted_access_token=NULL, encrypted_app_secret=NULL, encrypted_verify_token=NULL,
  templates='[]'::jsonb, webhook_verified_at=NULL, checked_at=NULL, connection_status='unconfigured',
  updated_at=now()
WHERE config->>'provider' IS DISTINCT FROM 'automatizado-vip';
UPDATE whatsapp_outbox SET status='cancelled',error='Conexión Meta sustituida; no se trasladan envíos pendientes al nuevo proveedor',updated_at=now()
WHERE status='pending';
UPDATE whatsapp_events SET processed_at=now() WHERE processed_at IS NULL;
