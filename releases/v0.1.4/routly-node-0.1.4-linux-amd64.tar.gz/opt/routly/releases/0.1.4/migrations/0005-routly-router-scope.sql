ALTER TABLE app_users
  ADD COLUMN IF NOT EXISTS all_routers boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS receive_support_email boolean NOT NULL DEFAULT false;

-- Preserve existing access. New employees receive an explicit scope.
UPDATE app_users SET all_routers = true;

CREATE TABLE IF NOT EXISTS employee_router_access (
  user_id integer NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS employee_router_access_user_router_unique
  ON employee_router_access(user_id,router_id);
CREATE INDEX IF NOT EXISTS employee_router_access_router_idx
  ON employee_router_access(router_id);