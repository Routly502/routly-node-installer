CREATE TABLE IF NOT EXISTS locations (
  id serial PRIMARY KEY,
  name text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS locations_name_unique ON locations(lower(name));
ALTER TABLE customers ADD COLUMN IF NOT EXISTS location_id integer REFERENCES locations(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS customers_location_id_idx ON customers(location_id);