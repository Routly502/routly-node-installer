-- Routly Node baseline.  The installer migration runner supplies the transaction.
CREATE TABLE IF NOT EXISTS app_users (
  id serial PRIMARY KEY, clerk_user_id text UNIQUE, email text NOT NULL, name text NOT NULL,
  address text, phone text, document_type text, document_number text, nit text,
  monthly_salary numeric(12,2) NOT NULL DEFAULT '0', role text NOT NULL DEFAULT 'support',
  active boolean NOT NULL DEFAULT true, all_routers boolean NOT NULL DEFAULT false,
  receive_support_email boolean NOT NULL DEFAULT false, deleted_at timestamptz, password_hash text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS app_sessions (
  id serial PRIMARY KEY, user_id integer NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE, expires_at timestamptz NOT NULL, revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS company_settings (
  id integer PRIMARY KEY DEFAULT 1, company_name text NOT NULL DEFAULT '', address text NOT NULL DEFAULT '',
  phone text NOT NULL DEFAULT '', identification_type text NOT NULL DEFAULT 'NIT',
  identification_number text NOT NULL DEFAULT '', timezone text NOT NULL DEFAULT 'America/El_Salvador',
  backup_email text NOT NULL DEFAULT '', support_email text NOT NULL DEFAULT '', billing_email text NOT NULL DEFAULT '',
  validate_customer_identification boolean NOT NULL DEFAULT false, router_alert_emails text NOT NULL DEFAULT '[]',
  router_alert_phones text NOT NULL DEFAULT '[]', payment_report_emails text NOT NULL DEFAULT '[]',
  main_logo_path text, billing_logo_path text, updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS payroll_entries (
  id serial PRIMARY KEY, user_id integer NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  payroll_month text NOT NULL, entry_date date NOT NULL, kind text NOT NULL, amount numeric(12,2) NOT NULL,
  hours numeric(8,2), hourly_rate numeric(12,2), category text, description text,
  created_by_user_id integer REFERENCES app_users(id), deleted_at timestamptz,
  deleted_by_user_id integer REFERENCES app_users(id), created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS payroll_periods (
  id serial PRIMARY KEY, user_id integer NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  payroll_month text NOT NULL, base_salary numeric(12,2) NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS payroll_periods_user_month_unique ON payroll_periods(user_id,payroll_month);
CREATE TABLE IF NOT EXISTS payroll_closures (
  id serial PRIMARY KEY, payroll_month text NOT NULL UNIQUE,
  closed_by_user_id integer NOT NULL REFERENCES app_users(id), closed_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS employee_shifts (
  id serial PRIMARY KEY, user_id integer NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  work_date date NOT NULL, start_time text NOT NULL, end_time text NOT NULL,
  overtime_minutes integer NOT NULL DEFAULT 0, notes text, created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS employee_shifts_user_date_unique ON employee_shifts(user_id,work_date);
CREATE TABLE IF NOT EXISTS plans (
  id serial PRIMARY KEY, name text NOT NULL, download_mbps integer NOT NULL, upload_mbps integer NOT NULL,
  monthly_price double precision NOT NULL, has_tax boolean NOT NULL DEFAULT false,
  tax_percentage double precision NOT NULL DEFAULT 0, status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS locations (
  id serial PRIMARY KEY, name text NOT NULL, active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS locations_name_unique ON locations(lower(name));
CREATE TABLE IF NOT EXISTS mikrotik_routers (
  id serial PRIMARY KEY, name text NOT NULL, location text, host text NOT NULL, port integer NOT NULL DEFAULT 8729,
  use_tls boolean NOT NULL DEFAULT true, certificate_fingerprint text, username text NOT NULL,
  encrypted_password text NOT NULL, management_mode text NOT NULL, model text, routeros_version text,
  active boolean NOT NULL DEFAULT true, sync_interval_minutes integer NOT NULL DEFAULT 15,
  sync_lease_until timestamptz, sync_lease_token text, last_sync_at timestamptz, last_sync_attempt_at timestamptz,
  consecutive_sync_failures integer NOT NULL DEFAULT 0, sync_failure_alert_threshold integer NOT NULL DEFAULT 3,
  sync_failure_alert_active boolean NOT NULL DEFAULT false, sync_failure_incident_key text, last_sync_error text,
  connection_status text NOT NULL DEFAULT 'pending', last_checked_at timestamptz,
  snmp_enabled boolean NOT NULL DEFAULT false, snmp_version text NOT NULL DEFAULT 'v2c',
  snmp_port integer NOT NULL DEFAULT 161, encrypted_snmp_community text, snmp_v3_username text,
  encrypted_snmp_v3_auth_password text, encrypted_snmp_v3_priv_password text, snmp_v3_auth_protocol text,
  snmp_v3_priv_protocol text, snmp_v3_security_level text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS ipv4_networks (
  id serial PRIMARY KEY, router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
  name text NOT NULL, network_address text NOT NULL, cidr_prefix integer NOT NULL,
  usage_type text NOT NULL DEFAULT 'static', active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS ipv4_networks_router_network_unique ON ipv4_networks(router_id,network_address,cidr_prefix);
CREATE TABLE IF NOT EXISTS customers (
  id serial PRIMARY KEY, name text NOT NULL, email text NOT NULL, phone text NOT NULL, address text NOT NULL,
  identification_type text, identification_number text, plan_name text NOT NULL, monthly_amount double precision NOT NULL,
  status text NOT NULL DEFAULT 'pending', connection_type text NOT NULL,
  location_id integer REFERENCES locations(id) ON DELETE SET NULL,
  router_id integer REFERENCES mikrotik_routers(id) ON DELETE SET NULL,
  ipv4_network_id integer REFERENCES ipv4_networks(id) ON DELETE SET NULL,
  service_mode text, service_address text, service_mac_address text, service_username text,
  encrypted_service_password text, provisioning_status text NOT NULL DEFAULT 'not_requested',
  provisioning_error text, installation_date date, coordinates text, equipment_type text, equipment_model text,
  equipment_serial text, admin_ip text, nap_box text, nap_port text, joined_at date NOT NULL,
  last_payment_at date, updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS customers_location_id_idx ON customers(location_id);
CREATE TABLE IF NOT EXISTS invoices (
  id serial PRIMARY KEY, invoice_number text NOT NULL UNIQUE, customer_id integer NOT NULL REFERENCES customers(id),
  billing_period text NOT NULL DEFAULT 'legacy', subtotal double precision, tax_percentage double precision,
  tax_amount double precision, amount double precision NOT NULL, due_date date NOT NULL, status text NOT NULL,
  paid_at date, payment_method text, voided_at timestamptz, void_reason text, deleted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS invoices_customer_billing_period_active_unique
  ON invoices(customer_id,billing_period)
  WHERE billing_period <> 'legacy' AND status <> 'voided' AND deleted_at IS NULL;
CREATE TABLE IF NOT EXISTS network_nodes (
  id serial PRIMARY KEY, name text NOT NULL, location text NOT NULL, type text NOT NULL, status text NOT NULL,
  availability double precision NOT NULL, connected_customers integer NOT NULL DEFAULT 0,
  last_checked_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS mikrotik_clients (
  id serial PRIMARY KEY, router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
  customer_id integer REFERENCES customers(id) ON DELETE SET NULL, remote_key text NOT NULL, remote_id text,
  name text NOT NULL, address text, mac_address text, disabled boolean NOT NULL DEFAULT false,
  dynamic boolean NOT NULL DEFAULT false, present boolean NOT NULL DEFAULT true, online boolean,
  status_checked_at timestamptz, last_online_at timestamptz, missing_since timestamptz,
  upload_mbps integer, download_mbps integer, operation_pending boolean NOT NULL DEFAULT false,
  operation_started_at timestamptz, last_synced_at timestamptz NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS mikrotik_clients_router_remote_unique ON mikrotik_clients(router_id,remote_key);
CREATE UNIQUE INDEX IF NOT EXISTS mikrotik_clients_customer_unique ON mikrotik_clients(customer_id);
CREATE TABLE IF NOT EXISTS employee_router_access (
  user_id integer NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS employee_router_access_user_router_unique
  ON employee_router_access(user_id,router_id);
CREATE INDEX IF NOT EXISTS employee_router_access_router_idx
  ON employee_router_access(router_id);
CREATE TABLE IF NOT EXISTS activities (
  id serial PRIMARY KEY, type text NOT NULL, title text NOT NULL, description text NOT NULL, tone text NOT NULL,
  actor_user_id integer REFERENCES app_users(id), actor_name text, occurred_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS revenue_metrics (
  id serial PRIMARY KEY, label text NOT NULL, amount double precision NOT NULL, position integer NOT NULL
);