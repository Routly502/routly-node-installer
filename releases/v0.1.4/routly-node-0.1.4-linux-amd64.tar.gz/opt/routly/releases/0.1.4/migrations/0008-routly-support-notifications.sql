CREATE TABLE IF NOT EXISTS support_notification_events (
  id serial PRIMARY KEY,
  event_key text NOT NULL UNIQUE,
  subject text NOT NULL,
  message text NOT NULL,
  requested_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  requested_by_name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS support_notification_deliveries (
  id serial PRIMARY KEY,
  event_id integer NOT NULL REFERENCES support_notification_events(id) ON DELETE CASCADE,
  recipient text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  attempt_count integer NOT NULL DEFAULT 0,
  provider_message_id text,
  error text,
  attempted_at timestamptz,
  sent_at timestamptz
);
CREATE UNIQUE INDEX IF NOT EXISTS support_notification_deliveries_event_recipient_unique
  ON support_notification_deliveries(event_id,recipient);