ALTER TABLE mikrotik_clients
  ADD COLUMN IF NOT EXISTS online boolean,
  ADD COLUMN IF NOT EXISTS status_checked_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_online_at timestamptz;