ALTER TABLE app_users ADD COLUMN IF NOT EXISTS username text;
ALTER TABLE app_users ADD COLUMN IF NOT EXISTS must_change_credentials boolean NOT NULL DEFAULT false;
CREATE UNIQUE INDEX IF NOT EXISTS app_users_username_unique ON app_users (username);
ALTER TABLE app_users
  ADD COLUMN IF NOT EXISTS all_routers boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS receive_support_email boolean NOT NULL DEFAULT false;