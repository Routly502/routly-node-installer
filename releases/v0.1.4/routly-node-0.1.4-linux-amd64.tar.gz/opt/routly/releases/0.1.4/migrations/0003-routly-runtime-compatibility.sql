-- Additive compatibility for development schemas created before the packaged
-- Node baseline.  Existing rows are never removed.
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS sync_interval_minutes integer NOT NULL DEFAULT 15;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS sync_lease_until timestamptz;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS sync_lease_token text;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS last_sync_at timestamptz;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS last_sync_attempt_at timestamptz;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS consecutive_sync_failures integer NOT NULL DEFAULT 0;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS sync_failure_alert_threshold integer NOT NULL DEFAULT 3;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS sync_failure_alert_active boolean NOT NULL DEFAULT false;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS sync_failure_incident_key text;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS last_sync_error text;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS snmp_enabled boolean NOT NULL DEFAULT false;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS snmp_version text NOT NULL DEFAULT 'v2c';
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS snmp_port integer NOT NULL DEFAULT 161;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS encrypted_snmp_community text;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS snmp_v3_username text;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS encrypted_snmp_v3_auth_password text;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS encrypted_snmp_v3_priv_password text;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS snmp_v3_auth_protocol text;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS snmp_v3_priv_protocol text;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS snmp_v3_security_level text;
ALTER TABLE mikrotik_clients ADD COLUMN IF NOT EXISTS missing_since timestamptz;
ALTER TABLE monitoring_host_samples ADD COLUMN IF NOT EXISTS cpu_cores jsonb;
ALTER TABLE monitoring_host_samples ADD COLUMN IF NOT EXISTS uptime_seconds bigint;
ALTER TABLE monitoring_hosts ADD COLUMN IF NOT EXISTS model text;
ALTER TABLE monitoring_hosts ADD COLUMN IF NOT EXISTS firmware_version text;
ALTER TABLE monitoring_hosts ADD COLUMN IF NOT EXISTS system_object_id text;
ALTER TABLE monitoring_host_samples ADD COLUMN IF NOT EXISTS cpu_cores jsonb;
ALTER TABLE router_alert_deliveries ADD COLUMN IF NOT EXISTS router_name text;
ALTER TABLE router_alert_deliveries ADD COLUMN IF NOT EXISTS event_occurred_at timestamptz;
ALTER TABLE router_alert_deliveries ADD COLUMN IF NOT EXISTS consecutive_failures integer;
ALTER TABLE router_alert_deliveries ADD COLUMN IF NOT EXISTS last_error text;
ALTER TABLE router_alert_deliveries ADD COLUMN IF NOT EXISTS attempt_count integer NOT NULL DEFAULT 0;
ALTER TABLE router_alert_deliveries ADD COLUMN IF NOT EXISTS next_attempt_at timestamptz NOT NULL DEFAULT now();
UPDATE router_alert_deliveries d SET router_name = COALESCE(d.router_name, r.name),
  event_occurred_at = COALESCE(d.event_occurred_at, d.attempted_at)
  FROM mikrotik_routers r WHERE d.router_id = r.id
  AND (d.router_name IS NULL OR d.event_occurred_at IS NULL);
ALTER TABLE router_alert_deliveries ALTER COLUMN router_name SET NOT NULL;
ALTER TABLE router_alert_deliveries ALTER COLUMN event_occurred_at SET NOT NULL;
ALTER TABLE routly_local_license ADD COLUMN IF NOT EXISTS trusted_keys jsonb;
ALTER TABLE routly_local_license ADD COLUMN IF NOT EXISTS last_trusted_time timestamptz NOT NULL DEFAULT now();