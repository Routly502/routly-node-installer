-- Runtime monitoring and local licensing tables are part of the Node baseline.
CREATE TABLE IF NOT EXISTS router_monitoring_samples (
 id serial PRIMARY KEY, router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
 sampled_at timestamptz NOT NULL DEFAULT now(), available boolean NOT NULL, cpu_percent double precision,
 memory_used_bytes bigint, memory_total_bytes bigint, failure_reason text
);
CREATE INDEX IF NOT EXISTS router_monitoring_samples_router_sampled_at_idx ON router_monitoring_samples(router_id,sampled_at);
CREATE INDEX IF NOT EXISTS router_monitoring_samples_sampled_at_idx ON router_monitoring_samples(sampled_at);
CREATE TABLE IF NOT EXISTS router_interface_monitoring_samples (
 id serial PRIMARY KEY, router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
 sampled_at timestamptz NOT NULL, interface_index integer NOT NULL, name text NOT NULL, status text NOT NULL,
 in_octets bigint NOT NULL, out_octets bigint NOT NULL
);
CREATE INDEX IF NOT EXISTS router_interface_monitoring_samples_router_sampled_at_idx ON router_interface_monitoring_samples(router_id,interface_index,sampled_at);
CREATE INDEX IF NOT EXISTS router_interface_monitoring_samples_router_time_idx ON router_interface_monitoring_samples(router_id,sampled_at);
CREATE TABLE IF NOT EXISTS router_monitoring_aggregates (
 id serial PRIMARY KEY, router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
 bucket_start timestamptz NOT NULL, bucket_minutes integer NOT NULL, sample_count integer NOT NULL,
 available_count integer NOT NULL, cpu_percent double precision, memory_used_bytes bigint, memory_total_bytes bigint
);
CREATE UNIQUE INDEX IF NOT EXISTS router_monitoring_aggregates_router_bucket_unique ON router_monitoring_aggregates(router_id,bucket_minutes,bucket_start);
CREATE INDEX IF NOT EXISTS router_monitoring_aggregates_bucket_start_idx ON router_monitoring_aggregates(bucket_minutes,bucket_start);
CREATE TABLE IF NOT EXISTS router_alert_deliveries (
 id serial PRIMARY KEY, router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
 incident_key text NOT NULL, event text NOT NULL, channel text NOT NULL, recipient text NOT NULL,
 router_name text NOT NULL, event_occurred_at timestamptz NOT NULL, consecutive_failures integer, last_error text,
 status text NOT NULL, attempt_count integer NOT NULL DEFAULT 0, next_attempt_at timestamptz NOT NULL DEFAULT now(),
 provider_message_id text, error text, attempted_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS router_alert_deliveries_incident_recipient_unique ON router_alert_deliveries(incident_key,event,channel,recipient);
CREATE TABLE IF NOT EXISTS monitoring_hosts (
 id serial PRIMARY KEY, name text NOT NULL, ip_address text NOT NULL, description text,
 equipment_type text NOT NULL DEFAULT 'network', model text, firmware_version text, system_object_id text,
 active boolean NOT NULL DEFAULT true, snmp_enabled boolean NOT NULL DEFAULT false, snmp_version text NOT NULL DEFAULT 'v2c',
 snmp_port integer NOT NULL DEFAULT 161, encrypted_snmp_community text, snmp_v3_username text,
 encrypted_snmp_v3_auth_password text, encrypted_snmp_v3_priv_password text, snmp_v3_auth_protocol text,
 snmp_v3_priv_protocol text, snmp_v3_security_level text, created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS monitoring_host_samples (
 id serial PRIMARY KEY, host_id integer NOT NULL REFERENCES monitoring_hosts(id) ON DELETE CASCADE,
 sampled_at timestamptz NOT NULL DEFAULT now(), available boolean NOT NULL, cpu_percent double precision,
 cpu_cores jsonb, memory_used_bytes bigint, memory_total_bytes bigint, uptime_seconds bigint, failure_reason text
);
CREATE TABLE IF NOT EXISTS monitoring_host_interfaces (
 id serial PRIMARY KEY, host_id integer NOT NULL REFERENCES monitoring_hosts(id) ON DELETE CASCADE,
 interface_index integer NOT NULL, name text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(host_id,interface_index)
);
CREATE TABLE IF NOT EXISTS monitoring_host_interface_samples (
 id serial PRIMARY KEY, host_id integer NOT NULL REFERENCES monitoring_hosts(id) ON DELETE CASCADE,
 sampled_at timestamptz NOT NULL, interface_index integer NOT NULL, name text NOT NULL, status text NOT NULL,
 in_octets bigint NOT NULL, out_octets bigint NOT NULL
);
CREATE TABLE IF NOT EXISTS monitoring_host_aggregates (
 id serial PRIMARY KEY, host_id integer NOT NULL REFERENCES monitoring_hosts(id) ON DELETE CASCADE,
 bucket_start timestamptz NOT NULL, bucket_minutes integer NOT NULL, sample_count integer NOT NULL,
 available_count integer NOT NULL, cpu_percent double precision, memory_used_bytes bigint, memory_total_bytes bigint
);
CREATE INDEX IF NOT EXISTS monitoring_host_samples_host_sampled_at_idx ON monitoring_host_samples(host_id,sampled_at);
CREATE INDEX IF NOT EXISTS monitoring_host_samples_sampled_at_idx ON monitoring_host_samples(sampled_at);
CREATE INDEX IF NOT EXISTS monitoring_host_interface_samples_host_sampled_at_idx ON monitoring_host_interface_samples(host_id,interface_index,sampled_at);
CREATE INDEX IF NOT EXISTS monitoring_host_interface_samples_host_time_idx ON monitoring_host_interface_samples(host_id,sampled_at);
CREATE UNIQUE INDEX IF NOT EXISTS monitoring_host_aggregates_host_bucket_unique ON monitoring_host_aggregates(host_id,bucket_minutes,bucket_start);
CREATE INDEX IF NOT EXISTS monitoring_host_aggregates_bucket_start_idx ON monitoring_host_aggregates(bucket_minutes,bucket_start);
CREATE TABLE IF NOT EXISTS routly_local_license (
 singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton), installation_id integer NOT NULL,
 encrypted_refresh_secret text NOT NULL, license_id text NOT NULL, payload jsonb NOT NULL, signature text NOT NULL,
 key_id text NOT NULL, algorithm text NOT NULL, trusted_keys jsonb, last_trusted_time timestamptz NOT NULL DEFAULT now(),
 refreshed_at timestamptz NOT NULL DEFAULT now()
);