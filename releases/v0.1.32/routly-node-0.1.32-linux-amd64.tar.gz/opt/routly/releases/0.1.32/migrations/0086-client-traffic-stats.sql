CREATE TABLE IF NOT EXISTS client_traffic_stats (
 router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
 customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
 service_id integer NOT NULL REFERENCES customer_services(id) ON DELETE CASCADE,
 bucket_start timestamptz NOT NULL,
 download_bytes bigint NOT NULL DEFAULT 0,
 upload_bytes bigint NOT NULL DEFAULT 0,
 PRIMARY KEY (router_id,customer_id,service_id,bucket_start)
);
CREATE INDEX IF NOT EXISTS client_traffic_stats_customer_bucket_idx ON client_traffic_stats(customer_id,bucket_start);
CREATE INDEX IF NOT EXISTS client_traffic_stats_service_bucket_idx ON client_traffic_stats(service_id,bucket_start);

-- Upgrades stop the Node API before migrations. Lock against any remaining
-- writer while importing the previously attributed history, without guessing IPs.
LOCK TABLE traffic_flow_records IN SHARE ROW EXCLUSIVE MODE;
INSERT INTO client_traffic_stats
 (router_id,customer_id,service_id,bucket_start,download_bytes,upload_bytes)
SELECT router_id,customer_id,service_id,date_trunc('hour',ended_at,'UTC'),
 sum(download_bytes),sum(upload_bytes)
FROM traffic_flow_records
GROUP BY router_id,customer_id,service_id,date_trunc('hour',ended_at,'UTC')
ON CONFLICT (router_id,customer_id,service_id,bucket_start) DO NOTHING;
