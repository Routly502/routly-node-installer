ALTER TABLE traffic_flow_settings
 ADD COLUMN IF NOT EXISTS reception_dropped bigint NOT NULL DEFAULT 0,
 ADD COLUMN IF NOT EXISTS last_reception_error text,
 ADD COLUMN IF NOT EXISTS last_reception_error_at timestamptz;
