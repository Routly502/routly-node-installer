CREATE TABLE IF NOT EXISTS traffic_flow_settings (
 router_id integer PRIMARY KEY REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
 enabled boolean NOT NULL DEFAULT false, interfaces text NOT NULL DEFAULT 'all',
 source_address text NOT NULL, collector_address text NOT NULL, exporter_address text NOT NULL,
 cache_entries text NOT NULL DEFAULT '128k', target_id text, target_source_address text, target_collector_address text,
 sync_state text NOT NULL DEFAULT 'pending', last_error text,
 last_received_at timestamptz, packets bigint NOT NULL DEFAULT 0, flows bigint NOT NULL DEFAULT 0,
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS traffic_flow_records (
 id bigserial PRIMARY KEY, flow_key text NOT NULL,
 router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
 customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
 service_id integer NOT NULL REFERENCES customer_services(id) ON DELETE CASCADE,
 started_at timestamptz NOT NULL, ended_at timestamptz NOT NULL,
 received_at timestamptz NOT NULL DEFAULT now(), remote_ip text NOT NULL, remote_port integer NOT NULL,
 protocol integer NOT NULL, download_bytes bigint NOT NULL DEFAULT 0, upload_bytes bigint NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX IF NOT EXISTS traffic_flow_record_key_unique ON traffic_flow_records(router_id,flow_key,service_id);
CREATE INDEX IF NOT EXISTS traffic_flow_customer_end_idx ON traffic_flow_records(customer_id,ended_at);
CREATE INDEX IF NOT EXISTS traffic_flow_service_end_idx ON traffic_flow_records(service_id,ended_at);
CREATE TABLE IF NOT EXISTS customer_connection_sessions (
 id bigserial PRIMARY KEY,
 router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
 customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
 service_id integer NOT NULL REFERENCES customer_services(id) ON DELETE CASCADE,
 session_key text, source text NOT NULL, started_at timestamptz NOT NULL,
 last_seen_at timestamptz NOT NULL, ended_at timestamptz, ipv4 text, mac text, router_address text NOT NULL
);
CREATE INDEX IF NOT EXISTS customer_connection_session_period_idx ON customer_connection_sessions(customer_id,started_at);
CREATE UNIQUE INDEX IF NOT EXISTS customer_connection_session_open_unique ON customer_connection_sessions(service_id) WHERE ended_at IS NULL;
