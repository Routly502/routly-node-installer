-- A zero final total is settled without recording cash or changing its document.
UPDATE invoices
SET status = 'paid',
    paid_at = COALESCE(paid_at, issue_date)
WHERE amount = 0
  AND status IN ('pending', 'overdue', 'partial')
  AND deleted_at IS NULL;
