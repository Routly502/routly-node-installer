ALTER TABLE company_settings
  ADD COLUMN IF NOT EXISTS email text NOT NULL DEFAULT '';
