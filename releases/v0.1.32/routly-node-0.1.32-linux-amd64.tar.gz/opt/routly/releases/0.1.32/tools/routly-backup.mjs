#!/usr/bin/env node
import { spawnSync } from "node:child_process";

const [id, extra] = process.argv.slice(3);
if (process.getuid?.() !== 0 || extra || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(id || "")) process.exit(2);
const root = "/opt/routly/current/api";
const result = spawnSync("/usr/bin/systemd-run", [
  "--quiet", "--collect", `--unit=routly-backup-${id}`,
  // A persistent timer lets the API acknowledge the request before maintenance
  // stops it. The job survives API shutdown and does not depend on its process.
  "--on-active=3s", "--timer-property=AccuracySec=1s",
  "--property=EnvironmentFile=/etc/routly/routly.env",
  "--setenv=NODE_ENV=production", "--setenv=ROUTLY_NODE_MODE=node",
  "--property=RuntimeMaxSec=1800", "--property=TimeoutStopSec=180",
  `--property=ExecStopPost=/usr/bin/flock /run/lock/routly.lock /usr/bin/node ${root}/backupSupervisor.mjs ${id} recover`,
  "/usr/bin/flock", "-n", "/run/lock/routly.lock",
  "/usr/bin/node", `${root}/backupSupervisor.mjs`, id, "run",
], { env: { PATH: "/usr/sbin:/usr/bin:/sbin:/bin" }, stdio: "ignore", timeout: 15_000 });
process.exit(result.status === 0 ? 0 : 1);
