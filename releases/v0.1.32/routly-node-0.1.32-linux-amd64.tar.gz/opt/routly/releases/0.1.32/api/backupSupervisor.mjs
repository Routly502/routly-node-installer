import { createRequire as __bannerCrReq } from 'node:module';
import __bannerPath from 'node:path';
import __bannerUrl from 'node:url';

globalThis.require = __bannerCrReq(import.meta.url);
globalThis.__filename = __bannerUrl.fileURLToPath(import.meta.url);
globalThis.__dirname = __bannerPath.dirname(globalThis.__filename);
    

// src/backupSupervisor.ts
import { spawnSync } from "node:child_process";
var [id, mode = "run"] = process.argv.slice(2);
if (process.getuid?.() !== 0 || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(id || "") || !["run", "recover"].includes(mode)) process.exit(2);
function command(program, args, timeout = 30 * 6e4) {
  const result = spawnSync(program, args, { stdio: "ignore", timeout });
  if (result.status !== 0 || result.error) throw new Error("Backup supervisor command failed");
}
try {
  if (mode === "run") command("/usr/bin/systemctl", ["stop", "routly-api.service"], 6e4);
  command("/usr/sbin/runuser", ["-u", "routly", "--", "/usr/bin/node", "/opt/routly/current/api/backupWorker.mjs", id, mode]);
  if (mode === "recover") command("/usr/bin/systemctl", ["start", "routly-api.service"], 6e4);
} catch {
  process.exitCode = 1;
}
//# sourceMappingURL=backupSupervisor.mjs.map
