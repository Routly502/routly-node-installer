ALTER TABLE company_settings
  ADD COLUMN iptv_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN iptv_source text NOT NULL DEFAULT 'url',
  ADD COLUMN iptv_playlist_url text NOT NULL DEFAULT '',
  ADD COLUMN iptv_base_url text NOT NULL DEFAULT '',
  ADD COLUMN iptv_channels jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN iptv_only_active_clients boolean NOT NULL DEFAULT true,
  ADD COLUMN iptv_revision text NOT NULL DEFAULT '',
  ADD CONSTRAINT company_settings_iptv_source CHECK (iptv_source IN ('url', 'content')),
  ADD CONSTRAINT company_settings_iptv_channels CHECK (jsonb_typeof(iptv_channels) = 'array');
