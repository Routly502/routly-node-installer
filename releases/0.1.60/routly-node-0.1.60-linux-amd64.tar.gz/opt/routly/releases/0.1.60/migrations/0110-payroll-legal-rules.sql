ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS tax_treatment text;
ALTER TABLE payroll_periods ADD COLUMN IF NOT EXISTS legal_snapshot jsonb;
CREATE TABLE IF NOT EXISTS payroll_legal_profiles (
  id serial PRIMARY KEY,
  user_id integer NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  year integer NOT NULL,
  country text NOT NULL,
  currency text NOT NULL,
  first_month text NOT NULL,
  previous_gross numeric(12,2) NOT NULL CHECK (previous_gross >= 0),
  previous_taxable numeric(12,2) NOT NULL CHECK (previous_taxable >= 0),
  previous_withheld numeric(12,2) NOT NULL CHECK (previous_withheld >= 0),
  monthly_incentive numeric(12,2) NOT NULL CHECK (monthly_incentive >= 0),
  projected_other_income numeric(12,2) NOT NULL CHECK (projected_other_income >= 0),
  annual_personal_deduction numeric(12,2) CHECK (annual_personal_deduction > 0),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS payroll_legal_profiles_user_year_unique ON payroll_legal_profiles(user_id, year);
