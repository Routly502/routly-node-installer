ALTER TABLE app_users ADD COLUMN IF NOT EXISTS dashboard_preferences jsonb;
ALTER TABLE installation_registrations ADD COLUMN IF NOT EXISTS completed_at timestamptz;
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS created_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL;
-- Historical completion dates are unknown. Do not substitute updated_at.
CREATE INDEX IF NOT EXISTS installation_registrations_completed_at_idx
  ON installation_registrations(completed_at) WHERE completed_at IS NOT NULL;
CREATE INDEX IF NOT EXISTS tickets_author_created_idx ON tickets(created_by_user_id,created_at);
