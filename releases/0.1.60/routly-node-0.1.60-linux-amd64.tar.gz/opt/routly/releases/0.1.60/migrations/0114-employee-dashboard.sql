ALTER TABLE app_users ADD COLUMN IF NOT EXISTS dashboard_blocks jsonb;
