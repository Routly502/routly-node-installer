-- Leave existing employees unclassified; do not infer their contractual status.
ALTER TABLE app_users ADD COLUMN IF NOT EXISTS employment_type text;
-- The migration ledger applies this statement once, inside its transaction.
-- Plain DDL remains compatible with the planner installed on existing Nodes.
ALTER TABLE app_users ADD CONSTRAINT app_users_employment_type_check
  CHECK (employment_type IN ('payroll', 'technical_services'));
