ALTER TABLE installation_registrations ADD COLUMN IF NOT EXISTS evidence_object_path text;
ALTER TABLE installation_registrations ADD COLUMN IF NOT EXISTS evidence_original_name text;
ALTER TABLE installation_registrations ADD COLUMN IF NOT EXISTS evidence_content_type text;
