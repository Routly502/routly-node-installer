ALTER TABLE company_settings ADD COLUMN IF NOT EXISTS portal_primary_color text NOT NULL DEFAULT '#072146'
  CONSTRAINT company_settings_portal_primary_color CHECK (portal_primary_color ~ '^#[0-9A-Fa-f]{6}$');
ALTER TABLE company_settings ADD COLUMN IF NOT EXISTS portal_accent_color text NOT NULL DEFAULT '#3ffdb9'
  CONSTRAINT company_settings_portal_accent_color CHECK (portal_accent_color ~ '^#[0-9A-Fa-f]{6}$');
ALTER TABLE company_settings ADD COLUMN IF NOT EXISTS portal_login_image_transparency integer NOT NULL DEFAULT 60
  CONSTRAINT company_settings_portal_transparency CHECK (portal_login_image_transparency BETWEEN 0 AND 100);
CREATE UNIQUE INDEX IF NOT EXISTS portal_branding_one_login_background ON portal_branding_assets (kind) WHERE kind = 'login-background';
