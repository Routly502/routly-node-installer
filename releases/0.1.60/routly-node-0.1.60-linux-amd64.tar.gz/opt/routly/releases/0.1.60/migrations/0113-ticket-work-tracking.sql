CREATE TABLE IF NOT EXISTS ticket_work_events (
  id serial PRIMARY KEY,
  ticket_id integer NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  cycle integer NOT NULL,
  action text NOT NULL,
  actor_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  actor_name text NOT NULL,
  technician_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  technician_name text,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  note text
);
CREATE UNIQUE INDEX IF NOT EXISTS ticket_work_events_milestone_idx ON ticket_work_events(ticket_id, cycle, action);
