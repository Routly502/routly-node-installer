ALTER TABLE ticket_work_events ADD COLUMN IF NOT EXISTS attachment_object_path text;
ALTER TABLE ticket_work_events ADD COLUMN IF NOT EXISTS attachment_original_name text;
ALTER TABLE ticket_work_events ADD COLUMN IF NOT EXISTS attachment_content_type text;
