ALTER TABLE ticket_replies ADD COLUMN IF NOT EXISTS visibility text NOT NULL DEFAULT 'public';
CREATE TABLE IF NOT EXISTS notifications (
  id serial PRIMARY KEY,
  recipient_type text NOT NULL CHECK (recipient_type IN ('client','operator')),
  recipient_id integer NOT NULL,
  role_target text,
  ticket_id integer NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  reply_id integer REFERENCES ticket_replies(id) ON DELETE CASCADE,
  event_key text NOT NULL,
  kind text NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  sender text NOT NULL,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS notifications_recipient_idx ON notifications(recipient_type,recipient_id,is_read,id);
CREATE UNIQUE INDEX IF NOT EXISTS notifications_event_recipient_idx ON notifications(ticket_id,event_key,recipient_type,recipient_id);
