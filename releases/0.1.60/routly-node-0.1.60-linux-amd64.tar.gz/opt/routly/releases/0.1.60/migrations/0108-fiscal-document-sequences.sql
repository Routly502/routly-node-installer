CREATE TABLE fiscal_document_sequences (
  tax_id text NOT NULL,
  environment text NOT NULL,
  establishment_code text NOT NULL,
  point_of_sale text NOT NULL,
  document_type text NOT NULL,
  next_sequence numeric(16,0) NOT NULL,
  PRIMARY KEY (tax_id, environment, establishment_code, point_of_sale, document_type)
);
