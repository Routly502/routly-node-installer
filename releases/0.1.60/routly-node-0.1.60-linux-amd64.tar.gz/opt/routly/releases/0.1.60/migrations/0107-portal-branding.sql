CREATE TABLE portal_branding_assets (
  id text PRIMARY KEY,
  kind text NOT NULL,
  storage_path text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX portal_branding_one_logo ON portal_branding_assets (kind) WHERE kind = 'logo';
