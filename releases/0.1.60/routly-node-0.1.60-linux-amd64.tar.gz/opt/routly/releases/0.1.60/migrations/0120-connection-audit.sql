ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS connection_observation_seconds integer NOT NULL DEFAULT 60;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS last_connection_observation_at timestamptz;
ALTER TABLE mikrotik_routers ADD COLUMN IF NOT EXISTS last_connection_observation_attempt_at timestamptz;
ALTER TABLE customer_connection_sessions ADD COLUMN IF NOT EXISTS first_observed_at timestamptz;
ALTER TABLE customer_connection_sessions ADD COLUMN IF NOT EXISTS end_reason text;
CREATE TABLE IF NOT EXISTS router_connection_checks (
  router_id integer NOT NULL REFERENCES mikrotik_routers(id) ON DELETE CASCADE,
  observed_at timestamptz NOT NULL,
  PRIMARY KEY(router_id,observed_at)
);
CREATE INDEX IF NOT EXISTS customer_connection_service_period_idx
  ON customer_connection_sessions(service_id,router_id,started_at);
