-- Reconcile existing customer labels without changing services or RouterOS.
WITH service_states AS (
  SELECT customer_id,
    count(*) FILTER (WHERE status <> 'retired') AS total,
    count(*) FILTER (WHERE status = 'active') AS active,
    count(*) FILTER (WHERE status = 'suspended') AS suspended
  FROM customer_services
  GROUP BY customer_id
), desired AS (
  SELECT c.id,
    CASE WHEN coalesce(s.total, 0) = 0 THEN 'retired'
      WHEN s.active > 0 THEN 'active'
      WHEN s.suspended > 0 THEN 'suspended'
      ELSE 'pending' END AS status
  FROM customers c
  LEFT JOIN service_states s ON s.customer_id = c.id
  WHERE c.status IN ('active', 'suspended')
    AND c.provisioning_status NOT IN ('deleting', 'deletion_error', 'provisioning')
)
UPDATE customers c
SET status = d.status
FROM desired d
WHERE c.id = d.id AND c.status <> d.status;
