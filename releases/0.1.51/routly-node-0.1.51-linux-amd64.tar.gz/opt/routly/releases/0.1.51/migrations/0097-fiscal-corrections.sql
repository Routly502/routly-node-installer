ALTER TABLE fiscal_documents ADD COLUMN IF NOT EXISTS rejection_code text;
ALTER TABLE fiscal_documents ADD COLUMN IF NOT EXISTS revision integer NOT NULL DEFAULT 1;
