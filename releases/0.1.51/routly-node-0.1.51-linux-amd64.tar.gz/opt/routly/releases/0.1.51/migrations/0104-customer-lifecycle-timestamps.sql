-- Do not invent historical dates from updated_at: profile edits and polling
-- also update it. Unknown historical suspension/retirement dates stay NULL.
ALTER TABLE customers ADD COLUMN suspended_at timestamptz;
ALTER TABLE customers ADD COLUMN retired_at timestamptz;
ALTER TABLE customer_services ADD COLUMN suspended_at timestamptz;
ALTER TABLE customer_services ADD COLUMN retired_at timestamptz;
