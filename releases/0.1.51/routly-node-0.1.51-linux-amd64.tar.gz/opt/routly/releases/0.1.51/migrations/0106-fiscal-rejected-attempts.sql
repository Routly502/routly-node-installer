ALTER TABLE fiscal_documents
  ADD COLUMN IF NOT EXISTS rejected_attempts jsonb NOT NULL DEFAULT '[]'::jsonb;
