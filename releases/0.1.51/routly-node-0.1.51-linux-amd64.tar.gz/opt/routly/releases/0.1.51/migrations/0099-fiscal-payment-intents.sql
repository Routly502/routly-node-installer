CREATE TABLE fiscal_payment_intents (
  id text PRIMARY KEY,
  customer_id integer NOT NULL,
  invoice_ids integer[] NOT NULL,
  kind text NOT NULL,
  created_by_user_id integer,
  request_hash text NOT NULL,
  request jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX fiscal_payment_intents_customer_idx ON fiscal_payment_intents(customer_id);
ALTER TABLE fiscal_documents ADD COLUMN payment_intent_id text;
ALTER TABLE fiscal_documents ADD COLUMN payment_completed integer NOT NULL DEFAULT 1;

-- Preserve fiscal snapshots while a provider request is outside a transaction.
-- Only the certified intent may settle its invoices; cash remains uncommitted
-- until the same transaction completes both the ledger and this intent.
CREATE FUNCTION guard_fiscal_payment_invoice() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE target_id integer; active_id text; active_status text;
BEGIN
  IF TG_TABLE_NAME = 'invoices' THEN
    IF TG_OP = 'DELETE' THEN target_id := OLD.id; ELSE target_id := NEW.id; END IF;
  ELSE
    IF TG_OP = 'DELETE' THEN target_id := OLD.invoice_id; ELSE target_id := NEW.invoice_id; END IF;
  END IF;
  SELECT id,status INTO active_id,active_status FROM fiscal_payment_intents
    WHERE target_id = ANY(invoice_ids) AND status IN ('pending','certified') LIMIT 1;
  IF active_id IS NOT NULL AND NOT (
    active_status = 'certified' AND active_id = coalesce(current_setting('routly.fiscal_payment_intent',true),'')
  ) THEN
    RAISE EXCEPTION 'Hay un cobro fiscal pendiente. Consulta su documento original antes de modificar la factura o sus pagos.';
  END IF;
  IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER fiscal_payment_invoice_guard BEFORE UPDATE OR DELETE ON invoices
  FOR EACH ROW EXECUTE FUNCTION guard_fiscal_payment_invoice();
CREATE TRIGGER fiscal_payment_item_guard BEFORE INSERT OR UPDATE OR DELETE ON invoice_items
  FOR EACH ROW EXECUTE FUNCTION guard_fiscal_payment_invoice();
CREATE TRIGGER fiscal_payment_cash_guard BEFORE INSERT OR UPDATE OR DELETE ON invoice_payments
  FOR EACH ROW EXECUTE FUNCTION guard_fiscal_payment_invoice();
