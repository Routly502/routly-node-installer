-- Only existing-subscriber imports populate customer_services.billing_start_date.
-- Preserve an installation date already entered by the ISP, and leave ordinary
-- service registrations (without an import billing start) unchanged.
UPDATE customer_services
SET installation_date = billing_start_date
WHERE installation_date IS NULL
  AND billing_start_date IS NOT NULL;
