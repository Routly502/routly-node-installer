ALTER TABLE customers ADD COLUMN fiscal_profile jsonb;
