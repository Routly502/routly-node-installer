ALTER TABLE app_users ADD COLUMN IF NOT EXISTS photo_logo_path text;
