CREATE TABLE customer_portal_accounts (
  customer_id integer PRIMARY KEY REFERENCES customers(id) ON DELETE CASCADE,
  username text UNIQUE,
  avatar_path text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT customer_portal_username_format CHECK (username IS NULL OR username ~ '^[a-z][a-z0-9_.-]{2,39}$')
);
CREATE TABLE customer_portal_sessions (
  id text PRIMARY KEY,
  customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  credential_fingerprint text NOT NULL,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz
);
CREATE INDEX customer_portal_sessions_customer_idx ON customer_portal_sessions(customer_id);
CREATE TABLE customer_portal_attempts (
  key text PRIMARY KEY,
  count integer NOT NULL DEFAULT 1,
  expires_at timestamptz NOT NULL
);
CREATE TABLE customer_portal_requests (
  customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  request_key text NOT NULL,
  fingerprint text NOT NULL,
  kind text NOT NULL,
  ticket_id integer NOT NULL,
  reply_id integer,
  invoice_id integer,
  method text,
  reference text,
  amount_cents integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (customer_id, request_key)
);
