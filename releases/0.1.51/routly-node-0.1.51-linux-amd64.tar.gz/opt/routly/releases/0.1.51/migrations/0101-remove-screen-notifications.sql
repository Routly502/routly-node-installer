-- Retire the feature without touching router state or historical job events.
DELETE FROM automation_jobs WHERE key = 'screenNotice';
ALTER TABLE billing_templates DROP COLUMN IF EXISTS screen_notification_enabled;
-- mikrotik_notice_configs is retained only as cleanup provenance. Its proxy
-- snapshot must never be restored automatically against a shared router.
