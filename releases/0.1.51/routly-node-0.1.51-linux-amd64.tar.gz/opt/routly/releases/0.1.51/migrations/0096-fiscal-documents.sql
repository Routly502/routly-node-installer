CREATE TABLE fiscal_issuance_config (
  id integer PRIMARY KEY DEFAULT 1,
  config jsonb NOT NULL
);
CREATE TABLE fiscal_documents (
  id serial PRIMARY KEY,
  invoice_id integer NOT NULL UNIQUE REFERENCES invoices(id) ON DELETE CASCADE,
  customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  invoice_number text NOT NULL,
  document_type text NOT NULL CHECK (document_type IN ('01', '03')),
  environment text NOT NULL CHECK (environment IN ('test', 'production')),
  generation_code text NOT NULL UNIQUE,
  tax_id text NOT NULL,
  recipient jsonb NOT NULL,
  payload jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sending','issued','rejected','uncertain')),
  message text NOT NULL DEFAULT 'Emisión pendiente. El pago ya fue registrado.',
  control_number text,
  reception_seal text,
  pdf_path text,
  json_path text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX fiscal_documents_customer_idx ON fiscal_documents(customer_id);
