CREATE TABLE IF NOT EXISTS payment_promises (
  id serial PRIMARY KEY,
  invoice_id integer NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  promised_date date NOT NULL,
  amount_cents integer NOT NULL CONSTRAINT payment_promises_amount_positive CHECK (amount_cents > 0),
  notes text,
  status text NOT NULL DEFAULT 'active' CONSTRAINT payment_promises_status_valid CHECK (status IN ('active', 'cancelled')),
  operator_name text NOT NULL,
  revision integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS payment_promises_active_invoice_unique ON payment_promises(invoice_id) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS payment_promises_date_idx ON payment_promises(promised_date);
