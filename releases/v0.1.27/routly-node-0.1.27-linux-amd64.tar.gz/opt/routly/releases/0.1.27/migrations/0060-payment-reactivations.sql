CREATE TABLE payment_reactivations (
  payment_id integer PRIMARY KEY,
  invoice_id integer NOT NULL,
  customer_id integer NOT NULL,
  payment_date date NOT NULL,
  targets jsonb NOT NULL,
  completed_at timestamptz,
  last_error text,
  next_attempt_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX payment_reactivations_due_idx ON payment_reactivations (completed_at, next_attempt_at);
