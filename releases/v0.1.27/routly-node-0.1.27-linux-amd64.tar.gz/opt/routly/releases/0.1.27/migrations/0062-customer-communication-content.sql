ALTER TABLE transactional_email_deliveries ADD COLUMN IF NOT EXISTS subject text;
ALTER TABLE transactional_email_deliveries ADD COLUMN IF NOT EXISTS sender text;
ALTER TABLE transactional_email_deliveries ADD COLUMN IF NOT EXISTS body text;
