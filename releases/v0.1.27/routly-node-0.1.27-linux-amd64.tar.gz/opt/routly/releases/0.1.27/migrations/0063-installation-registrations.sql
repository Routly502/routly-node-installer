CREATE TABLE IF NOT EXISTS installation_registrations (
  id serial PRIMARY KEY,
  request_id text NOT NULL UNIQUE,
  name text NOT NULL,
  identification_number text NOT NULL DEFAULT '',
  address text NOT NULL,
  phone text NOT NULL DEFAULT '',
  mobile text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  scheduled_at timestamptz NOT NULL,
  location_id integer REFERENCES locations(id) ON DELETE SET NULL,
  location_name text NOT NULL DEFAULT '',
  technician_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  technician_name text NOT NULL DEFAULT '',
  notes text NOT NULL DEFAULT '',
  created_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  revision integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS installation_registrations_created_idx ON installation_registrations(created_at,id);
CREATE INDEX IF NOT EXISTS installation_registrations_owner_idx ON installation_registrations(created_by_user_id,technician_id);
