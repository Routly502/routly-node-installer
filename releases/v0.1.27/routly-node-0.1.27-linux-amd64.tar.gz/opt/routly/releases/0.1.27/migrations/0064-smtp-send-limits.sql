ALTER TABLE email_provider_settings ADD COLUMN IF NOT EXISTS smtp_hourly_limit integer NOT NULL DEFAULT 100;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'email_provider_settings_smtp_hourly_limit_check' AND conrelid = 'email_provider_settings'::regclass) THEN
    ALTER TABLE email_provider_settings ADD CONSTRAINT email_provider_settings_smtp_hourly_limit_check CHECK (smtp_hourly_limit BETWEEN 1 AND 10000);
  END IF;
END $$;
CREATE TABLE IF NOT EXISTS smtp_send_attempts (
  id serial PRIMARY KEY,
  attempted_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS smtp_send_attempts_time_idx ON smtp_send_attempts(attempted_at);
ALTER TABLE transactional_email_deliveries ADD COLUMN IF NOT EXISTS retry_at timestamptz;
ALTER TABLE transactional_email_deliveries ADD COLUMN IF NOT EXISTS retry_context jsonb;
CREATE INDEX IF NOT EXISTS transactional_email_deliveries_retry_idx ON transactional_email_deliveries(status, retry_at);
