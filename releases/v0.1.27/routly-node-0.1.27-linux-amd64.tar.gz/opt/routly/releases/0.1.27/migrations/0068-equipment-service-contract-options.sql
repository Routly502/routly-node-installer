ALTER TABLE warehouse_products ADD COLUMN IF NOT EXISTS service_id integer REFERENCES customer_services(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS warehouse_products_service_idx ON warehouse_products(service_id);
CREATE OR REPLACE FUNCTION validate_warehouse_equipment_service() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF (TG_OP = 'UPDATE' AND OLD.customer_id IS DISTINCT FROM NEW.customer_id)
     OR NEW.equipment_state IS NULL OR NEW.equipment_state NOT IN ('loaned','rented','sold') THEN
    NEW.service_id := NULL;
  END IF;
  IF NEW.service_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM customer_services WHERE id=NEW.service_id AND customer_id=NEW.customer_id
  ) THEN
    RAISE EXCEPTION 'El equipo y el servicio deben pertenecer al mismo cliente' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS warehouse_equipment_service_guard ON warehouse_products;
CREATE TRIGGER warehouse_equipment_service_guard BEFORE INSERT OR UPDATE OF customer_id,service_id,equipment_state ON warehouse_products
FOR EACH ROW EXECUTE FUNCTION validate_warehouse_equipment_service();
ALTER TABLE customer_contracts DROP CONSTRAINT IF EXISTS customer_contracts_status_check;
ALTER TABLE customer_contracts ADD CONSTRAINT customer_contracts_status_check CHECK (status IN ('pending_approval','active','cancelled','finished'));
