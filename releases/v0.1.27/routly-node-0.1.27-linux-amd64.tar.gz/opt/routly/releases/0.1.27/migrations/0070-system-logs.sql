CREATE TABLE IF NOT EXISTS system_logs (
  id serial PRIMARY KEY,
  category text NOT NULL DEFAULT 'system',
  occurred_at timestamptz NOT NULL DEFAULT now(),
  client_id integer REFERENCES customers(id) ON DELETE SET NULL,
  actor_user_id integer,
  actor_name text NOT NULL,
  ip text,
  detail text NOT NULL,
  changes text[] NOT NULL DEFAULT '{}'::text[],
  status text NOT NULL DEFAULT 'info',
  source text NOT NULL,
  legacy_activity_id integer
);
CREATE INDEX IF NOT EXISTS system_logs_category_date_idx ON system_logs(category,occurred_at,id);
CREATE UNIQUE INDEX IF NOT EXISTS system_logs_legacy_activity_unique ON system_logs(legacy_activity_id);
INSERT INTO system_logs(category,occurred_at,actor_user_id,actor_name,detail,status,source,legacy_activity_id)
SELECT 'system',occurred_at,actor_user_id,coalesce(actor_name,'[SISTEMA]'),
  left(title || ' · ' || description,2000),
  CASE WHEN tone='critical' THEN 'error' ELSE 'info' END,'activity',id
FROM activities ON CONFLICT(legacy_activity_id) DO NOTHING;
CREATE OR REPLACE FUNCTION routly_activity_to_system_log() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO system_logs(category,occurred_at,actor_user_id,actor_name,detail,status,source,legacy_activity_id)
  VALUES('system',NEW.occurred_at,NEW.actor_user_id,coalesce(NEW.actor_name,'[SISTEMA]'),
    left(NEW.title || ' · ' || NEW.description,2000),
    CASE WHEN NEW.tone='critical' THEN 'error' ELSE 'info' END,'activity',NEW.id)
  ON CONFLICT(legacy_activity_id) DO NOTHING;
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS routly_activity_system_log ON activities;
CREATE TRIGGER routly_activity_system_log AFTER INSERT ON activities
  FOR EACH ROW EXECUTE FUNCTION routly_activity_to_system_log();
