ALTER TABLE email_provider_settings ADD COLUMN IF NOT EXISTS smtp_pause_started_at timestamptz;
-- Existing unresolved pauses start their observation window at upgrade.
UPDATE email_provider_settings SET smtp_pause_started_at = clock_timestamp()
WHERE smtp_temporary_failures > 0 AND smtp_pause_started_at IS NULL;
