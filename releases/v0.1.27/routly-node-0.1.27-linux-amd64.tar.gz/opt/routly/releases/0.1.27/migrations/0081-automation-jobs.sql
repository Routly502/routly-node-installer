CREATE TABLE automation_jobs (
  key text PRIMARY KEY,
  time text NOT NULL CHECK (time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'),
  last_success_date date,
  status text NOT NULL DEFAULT 'idle',
  message text NOT NULL DEFAULT '',
  count integer NOT NULL DEFAULT 0,
  started_at timestamptz,
  finished_at timestamptz,
  claim_token text,
  claim_until timestamptz,
  next_attempt_at timestamptz
);
INSERT INTO automation_jobs(key,time) VALUES
 ('reminder1','08:30'),('reminder2','13:30'),('reminder3','17:00'),
 ('screenNotice','16:30'),('cutoff','08:00'),('billing','00:50'),('backup','17:11');
ALTER TABLE invoices ADD COLUMN automatic_late_fee_applied_at timestamptz;
