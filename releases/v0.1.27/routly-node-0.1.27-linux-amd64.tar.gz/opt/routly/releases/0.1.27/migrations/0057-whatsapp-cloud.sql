CREATE TABLE IF NOT EXISTS whatsapp_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  config jsonb NOT NULL DEFAULT '{}',
  encrypted_access_token text,
  encrypted_app_secret text,
  encrypted_verify_token text,
  connection_status text NOT NULL DEFAULT 'unconfigured',
  checked_at timestamptz,
  webhook_verified_at timestamptz,
  activated_at timestamptz,
  templates jsonb NOT NULL DEFAULT '[]',
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS whatsapp_consents (
  customer_id integer PRIMARY KEY REFERENCES customers(id) ON DELETE CASCADE,
  phone text NOT NULL,
  consent boolean NOT NULL DEFAULT false,
  note text NOT NULL DEFAULT '',
  recorded_by integer,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS whatsapp_outbox (
  id serial PRIMARY KEY,
  event_key text NOT NULL,
  code text NOT NULL,
  recipient text NOT NULL,
  customer_id integer REFERENCES customers(id) ON DELETE CASCADE,
  invoice_id integer REFERENCES invoices(id) ON DELETE CASCADE,
  payment_id integer REFERENCES invoice_payments(id) ON DELETE CASCADE,
  data jsonb NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  attempts integer NOT NULL DEFAULT 0,
  provider_message_id text,
  error text,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  attempted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT whatsapp_outbox_status_check CHECK (status IN ('pending','sending','accepted','sent','delivered','read','failed','uncertain','cancelled'))
);
CREATE UNIQUE INDEX IF NOT EXISTS whatsapp_outbox_event_recipient_unique ON whatsapp_outbox(event_key, code, recipient);
CREATE UNIQUE INDEX IF NOT EXISTS whatsapp_outbox_provider_unique ON whatsapp_outbox(provider_message_id);
CREATE INDEX IF NOT EXISTS whatsapp_outbox_pending_idx ON whatsapp_outbox(status, next_attempt_at);
CREATE TABLE IF NOT EXISTS whatsapp_events (
  event_key text PRIMARY KEY, code text NOT NULL,
  customer_id integer REFERENCES customers(id) ON DELETE CASCADE,
  invoice_id integer REFERENCES invoices(id) ON DELETE CASCADE,
  payment_id integer REFERENCES invoice_payments(id) ON DELETE CASCADE,
  occurred_at timestamptz NOT NULL DEFAULT now(), processed_at timestamptz
);
CREATE INDEX IF NOT EXISTS whatsapp_events_pending_idx ON whatsapp_events(processed_at, occurred_at);

CREATE OR REPLACE FUNCTION routly_capture_whatsapp_event() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  config_value jsonb;
  event_code text;
  event_id text;
  cid integer;
  iid integer;
  pid integer;
BEGIN
  SELECT config INTO config_value FROM whatsapp_settings WHERE id = 1;
  IF config_value IS NULL OR config_value->>'enabled' IS DISTINCT FROM 'true' THEN RETURN NEW; END IF;
  IF TG_TABLE_NAME = 'customers' THEN
    event_code := 'SMS_BIENVENIDA'; event_id := 'welcome:' || NEW.id; cid := NEW.id;
  ELSIF TG_TABLE_NAME = 'invoices' THEN
    IF NEW.deleted_at IS NOT NULL OR NEW.status IN ('paid','voided') THEN RETURN NEW; END IF;
    event_code := 'NUEVA_FACTURA_SMS'; event_id := 'invoice:' || NEW.id; cid := NEW.customer_id; iid := NEW.id;
  ELSIF TG_TABLE_NAME = 'invoice_payments' THEN
    IF NEW.amount <= 0 THEN RETURN NEW; END IF;
    event_code := 'SMS_CONFIRMACION_PAGO'; event_id := 'payment:' || NEW.id; cid := NEW.customer_id; iid := NEW.invoice_id; pid := NEW.id;
  ELSIF TG_TABLE_NAME = 'customer_services' THEN
    IF NEW.status <> 'suspended' OR OLD.status = 'suspended' THEN RETURN NEW; END IF;
    event_code := 'SMS_CORTE_SERVICIO'; event_id := 'cut:' || NEW.id || ':' || txid_current(); cid := NEW.customer_id;
  ELSIF TG_TABLE_NAME = 'mikrotik_routers' THEN
    IF NEW.sync_failure_alert_active IS NOT DISTINCT FROM OLD.sync_failure_alert_active THEN RETURN NEW; END IF;
    event_code := CASE WHEN NEW.sync_failure_alert_active THEN 'SMS_ROUTER_CAIDO' ELSE 'SMS_ROUTER_CONECTADO' END;
    event_id := 'router:' || NEW.id || ':' || txid_current();
  ELSIF TG_TABLE_NAME = 'emitter_snmp_incidents' THEN
    IF TG_OP = 'INSERT' THEN
      event_code := 'SMS_EMISOR_CAIDO'; event_id := 'emitter-down:' || NEW.incident_key;
    ELSE
      IF NEW.recovered_at IS NULL OR OLD.recovered_at IS NOT NULL THEN RETURN NEW; END IF;
      event_code := 'SMS_EMISOR_CONECTADO'; event_id := 'emitter-up:' || NEW.incident_key;
    END IF;
  END IF;
  IF event_code IS NOT NULL AND EXISTS (
    SELECT 1 FROM jsonb_array_elements(config_value->'events') e WHERE e->>'code' = event_code AND e->>'enabled' = 'true'
  ) THEN
    INSERT INTO whatsapp_events(event_key,code,customer_id,invoice_id,payment_id)
    VALUES(event_id,event_code,cid,iid,pid) ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS whatsapp_customer_created ON customers;
CREATE TRIGGER whatsapp_customer_created AFTER INSERT ON customers FOR EACH ROW EXECUTE FUNCTION routly_capture_whatsapp_event();
DROP TRIGGER IF EXISTS whatsapp_invoice_created ON invoices;
CREATE TRIGGER whatsapp_invoice_created AFTER INSERT ON invoices FOR EACH ROW EXECUTE FUNCTION routly_capture_whatsapp_event();
DROP TRIGGER IF EXISTS whatsapp_payment_created ON invoice_payments;
CREATE TRIGGER whatsapp_payment_created AFTER INSERT ON invoice_payments FOR EACH ROW EXECUTE FUNCTION routly_capture_whatsapp_event();
DROP TRIGGER IF EXISTS whatsapp_service_cut ON customer_services;
CREATE TRIGGER whatsapp_service_cut AFTER UPDATE OF status ON customer_services FOR EACH ROW EXECUTE FUNCTION routly_capture_whatsapp_event();
DROP TRIGGER IF EXISTS whatsapp_router_transition ON mikrotik_routers;
CREATE TRIGGER whatsapp_router_transition AFTER UPDATE OF sync_failure_alert_active ON mikrotik_routers FOR EACH ROW EXECUTE FUNCTION routly_capture_whatsapp_event();
DROP TRIGGER IF EXISTS whatsapp_emitter_transition ON emitter_snmp_incidents;
CREATE TRIGGER whatsapp_emitter_transition AFTER INSERT OR UPDATE OF recovered_at ON emitter_snmp_incidents FOR EACH ROW EXECUTE FUNCTION routly_capture_whatsapp_event();
