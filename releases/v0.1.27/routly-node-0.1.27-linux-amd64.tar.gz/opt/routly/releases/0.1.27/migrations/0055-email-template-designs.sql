-- Email layouts share the existing template catalog without changing legacy
-- notification keys, provider settings, delivery flags or event scheduling.
ALTER TABLE document_templates
  ADD COLUMN IF NOT EXISTS subject text NOT NULL DEFAULT '';
