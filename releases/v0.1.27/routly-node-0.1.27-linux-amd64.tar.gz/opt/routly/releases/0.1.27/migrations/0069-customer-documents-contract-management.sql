ALTER TABLE customer_contracts ADD COLUMN revision integer NOT NULL DEFAULT 1;
ALTER TABLE customer_contracts ADD COLUMN last_edit_key text;
ALTER TABLE customer_contracts ADD COLUMN last_edit_fingerprint text;
CREATE TABLE customer_documents (
  id serial PRIMARY KEY,
  customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  request_key text NOT NULL,
  fingerprint text NOT NULL,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  filename text NOT NULL,
  file_path text NOT NULL,
  file_size integer NOT NULL CHECK(file_size > 0 AND file_size <= 20971520),
  show_to_customer boolean NOT NULL DEFAULT false,
  created_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  creator_name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT customer_documents_customer_id_request_key_unique UNIQUE(customer_id,request_key)
);
CREATE INDEX customer_documents_customer_idx ON customer_documents(customer_id,id);
