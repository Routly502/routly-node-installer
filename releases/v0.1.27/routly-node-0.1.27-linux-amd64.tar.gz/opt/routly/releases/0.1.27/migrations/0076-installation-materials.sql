CREATE TABLE IF NOT EXISTS installation_materials (
  id serial PRIMARY KEY,
  registration_id integer NOT NULL REFERENCES installation_registrations(id) ON DELETE CASCADE,
  product_id integer REFERENCES warehouse_products(id) ON DELETE SET NULL,
  request_id uuid NOT NULL UNIQUE,
  input_signature text NOT NULL,
  category text NOT NULL CHECK (category IN ('product','accessory')),
  name text NOT NULL,
  serial_number text,
  mac_address text,
  equipment_type text,
  condition text CHECK (condition IN ('free','loan','sale')),
  description text NOT NULL DEFAULT '',
  quantity numeric(12,3) NOT NULL CHECK (quantity > 0),
  unit_of_measure text NOT NULL CHECK (unit_of_measure IN ('units','meters')),
  assigned_name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  removed_at timestamptz
);
CREATE INDEX IF NOT EXISTS installation_materials_registration_idx ON installation_materials(registration_id);
CREATE UNIQUE INDEX IF NOT EXISTS installation_materials_equipment_unique ON installation_materials(product_id)
  WHERE category='product' AND removed_at IS NULL;
