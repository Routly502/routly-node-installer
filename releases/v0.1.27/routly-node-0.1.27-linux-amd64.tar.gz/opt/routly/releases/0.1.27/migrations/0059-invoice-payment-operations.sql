CREATE TABLE invoice_payment_operations (
  operation_id text PRIMARY KEY,
  invoice_id integer NOT NULL,
  created_by_user_id integer,
  request_hash text NOT NULL,
  payment_id integer NOT NULL,
  invoice_snapshot jsonb NOT NULL,
  reactivation_pending integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
