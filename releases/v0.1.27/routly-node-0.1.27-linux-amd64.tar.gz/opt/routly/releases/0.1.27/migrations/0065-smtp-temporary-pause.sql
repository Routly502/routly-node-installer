ALTER TABLE email_provider_settings ADD COLUMN IF NOT EXISTS smtp_pause_until timestamptz;
ALTER TABLE email_provider_settings ADD COLUMN IF NOT EXISTS smtp_pause_reason text;
ALTER TABLE email_provider_settings ADD COLUMN IF NOT EXISTS smtp_temporary_failures integer NOT NULL DEFAULT 0;
