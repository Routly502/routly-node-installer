CREATE TABLE IF NOT EXISTS customer_contracts (
  id serial PRIMARY KEY,
  customer_id integer NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  request_key text NOT NULL,
  request_fingerprint text NOT NULL,
  title text NOT NULL,
  external_number text NOT NULL DEFAULT '',
  start_date date NOT NULL,
  "end_date" date NOT NULL,
  duration_months integer NOT NULL,
  status text NOT NULL DEFAULT 'pending_approval',
  signed boolean NOT NULL DEFAULT false,
  show_to_customer boolean NOT NULL DEFAULT false,
  show_logo boolean NOT NULL DEFAULT false,
  created_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  router_ids integer[] NOT NULL DEFAULT '{}',
  snapshot jsonb NOT NULL,
  pdf_path text NOT NULL DEFAULT '',
  CONSTRAINT customer_contracts_duration_check CHECK (duration_months BETWEEN 1 AND 60),
  CONSTRAINT customer_contracts_dates_check CHECK (end_date >= start_date),
  CONSTRAINT customer_contracts_status_check CHECK (status IN ('pending_approval'))
);
CREATE UNIQUE INDEX IF NOT EXISTS customer_contracts_request_unique ON customer_contracts(customer_id,request_key);
CREATE INDEX IF NOT EXISTS customer_contracts_customer_idx ON customer_contracts(customer_id,id);
