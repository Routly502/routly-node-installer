-- Existing sessions enter the same idle window without disconnecting everyone
-- immediately. Activity may renew only the session that supplied the token.
UPDATE app_sessions
SET expires_at = LEAST(expires_at, CURRENT_TIMESTAMP + INTERVAL '30 minutes')
WHERE revoked_at IS NULL AND expires_at > CURRENT_TIMESTAMP;
