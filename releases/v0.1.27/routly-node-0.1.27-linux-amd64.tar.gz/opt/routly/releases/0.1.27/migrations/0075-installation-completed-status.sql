ALTER TABLE installation_registrations ADD COLUMN IF NOT EXISTS installed boolean NOT NULL DEFAULT false;
