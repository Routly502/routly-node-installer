ALTER TABLE installation_registrations
  ADD COLUMN IF NOT EXISTS installed_service_id integer REFERENCES customer_services(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS installation_registrations_service_idx ON installation_registrations(installed_service_id);

-- Recover earlier completed enrollments only when identity, name and service
-- are unambiguous. Never guess from a name alone or choose among subscriptions.
WITH matches AS (
  SELECT r.id, min(s.id) AS service_id
  FROM installation_registrations r
  JOIN customers c ON btrim(c.identification_number)=btrim(r.identification_number)
    AND lower(btrim(c.name))=lower(btrim(r.name))
  JOIN customer_services s ON s.customer_id=c.id
  WHERE r.installed AND r.accepted_at IS NOT NULL AND r.installed_service_id IS NULL
    AND btrim(r.identification_number)<>''
    AND NOT EXISTS (SELECT 1 FROM installation_registrations other
      WHERE other.id<>r.id AND btrim(other.identification_number)=btrim(r.identification_number))
  GROUP BY r.id HAVING count(*)=1
)
UPDATE installation_registrations r SET installed_service_id=m.service_id
FROM matches m WHERE r.id=m.id;
