-- Only replace identification labels; keep template customization, numbers,
-- company tax identifiers and already-issued document snapshots unchanged.
WITH updated AS (
  SELECT id,
    regexp_replace(replace(replace(replace(replace(replace(
      regexp_replace(content_html,
        'Identificación:(</(td|span)>[[:space:]]*<(td|span)[^>]*>[[:space:]]*\{IDENTIFICACION_CLIENTE\})',
        'Número de identificación:\1', 'g'),
      'N.º identificación', 'Número de identificación'),
      'identificado(a) con DUI No.', 'número de identificación:'),
      'identificado con DUI No.', 'número de identificación:'),
      'DUI {IDENTIFICACION_CLIENTE}', 'Número de identificación: {IDENTIFICACION_CLIENTE}'),
      'DUI {identificacion_representante}', 'Número de identificación: {identificacion_representante}'),
      '(<br[[:space:]]*/?>)[[:space:]]*\{IDENTIFICACION_CLIENTE\}',
      '\1Número de identificación: {IDENTIFICACION_CLIENTE}', 'g') AS content
  FROM document_templates
  WHERE code IN ('FACTURA','FACTURA_GT','FACTURA_SV','RECIBO','RECIBO_POS',
    'CONTRATO','IMPRESION_TICKET','HOJA_INSTALACION')
)
UPDATE document_templates AS template
SET content_html = updated.content, updated_at = now()
FROM updated WHERE template.id = updated.id AND template.content_html <> updated.content;
