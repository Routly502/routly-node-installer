ALTER TABLE installation_registrations ADD COLUMN IF NOT EXISTS accepted_at timestamptz;
CREATE TABLE IF NOT EXISTS installation_email_deliveries (
  request_id text PRIMARY KEY,
  registration_id integer NOT NULL REFERENCES installation_registrations(id) ON DELETE CASCADE,
  revision integer NOT NULL,
  created_by_user_id integer REFERENCES app_users(id) ON DELETE SET NULL,
  recipient text NOT NULL,
  status text NOT NULL DEFAULT 'sending',
  created_at timestamptz NOT NULL DEFAULT now()
);
