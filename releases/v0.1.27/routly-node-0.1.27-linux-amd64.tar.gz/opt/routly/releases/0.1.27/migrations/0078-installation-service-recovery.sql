-- Earlier enrollments could change the person's name in the customer wizard.
-- Recover only a unique identity with corroborating contact data (or name),
-- one installation and one service. Never choose between subscriptions.
WITH matches AS (
  SELECT r.id, min(s.id) AS service_id
  FROM installation_registrations r
  JOIN customers c ON btrim(c.identification_number)=btrim(r.identification_number)
  JOIN customer_services s ON s.customer_id=c.id
  WHERE r.installed AND r.accepted_at IS NOT NULL AND r.installed_service_id IS NULL
    AND btrim(r.identification_number)<>''
    AND (
      lower(btrim(c.name))=lower(btrim(r.name))
      OR (btrim(r.mobile)<>'' AND btrim(c.phone)=btrim(r.mobile))
      OR (btrim(r.email)<>'' AND lower(btrim(c.email))=lower(btrim(r.email)))
    )
    AND (SELECT count(*) FROM customers other
      WHERE btrim(other.identification_number)=btrim(r.identification_number))=1
    AND NOT EXISTS (SELECT 1 FROM installation_registrations other
      WHERE other.id<>r.id AND (btrim(other.identification_number)=btrim(r.identification_number)
        OR other.installed_service_id=s.id))
  GROUP BY r.id HAVING count(*)=1
)
UPDATE installation_registrations r SET installed_service_id=m.service_id,
  revision=revision+1,updated_at=now()
FROM matches m WHERE r.id=m.id;
