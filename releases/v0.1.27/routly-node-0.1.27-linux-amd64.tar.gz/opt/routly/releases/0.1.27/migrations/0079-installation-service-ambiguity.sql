-- A legacy contact match cannot establish which customer was enrolled if
-- another profile matches the installation's name and contact information.
-- Leave this ambiguous case unlinked rather than expose another service.
UPDATE installation_registrations r
SET installed_service_id=NULL,revision=r.revision+1,updated_at=now()
FROM customer_services s JOIN customers c ON c.id=s.customer_id
WHERE r.installed_service_id=s.id
  AND btrim(r.identification_number)<>''
  AND btrim(r.identification_number)=btrim(c.identification_number)
  AND lower(btrim(r.name))<>lower(btrim(c.name))
  AND EXISTS (
    SELECT 1 FROM customers other
    WHERE other.id<>c.id
      AND lower(btrim(other.name))=lower(btrim(r.name))
      AND (
        (btrim(r.mobile)<>'' AND btrim(other.phone)=btrim(r.mobile))
        OR (btrim(r.email)<>'' AND lower(btrim(other.email))=lower(btrim(r.email)))
      )
  );
