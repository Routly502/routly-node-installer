CREATE TABLE IF NOT EXISTS document_templates (
  id serial PRIMARY KEY,
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  category text NOT NULL DEFAULT 'documentos',
  content_html text NOT NULL,
  page_size text NOT NULL DEFAULT 'Letter',
  page_orientation text NOT NULL DEFAULT 'VERTICAL',
  custom_width_mm real NOT NULL DEFAULT 220,
  custom_height_mm real NOT NULL DEFAULT 280,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT document_templates_size_check CHECK (page_size IN ('Letter','A4','Custom','80mm')),
  CONSTRAINT document_templates_orientation_check CHECK (page_orientation IN ('VERTICAL','HORIZONTAL')),
  CONSTRAINT document_templates_width_check CHECK (custom_width_mm BETWEEN 40 AND 1000),
  CONSTRAINT document_templates_height_check CHECK (custom_height_mm BETWEEN 40 AND 2000)
);
