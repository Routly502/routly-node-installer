CREATE TABLE IF NOT EXISTS message_templates (
  id serial PRIMARY KEY,
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  channel text NOT NULL,
  content_text text NOT NULL,
  category text NOT NULL DEFAULT 'messaging',
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT message_templates_channel_check CHECK (channel IN ('sms', 'telegram')),
  CONSTRAINT message_templates_category_check CHECK (category = 'messaging')
);
