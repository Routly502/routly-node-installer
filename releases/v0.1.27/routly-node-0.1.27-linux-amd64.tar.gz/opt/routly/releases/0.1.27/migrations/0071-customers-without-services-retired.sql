-- A retained customer file without any current service is retired, not deleted.
UPDATE customers AS customer
SET status = 'retired', provisioning_status = 'retired', provisioning_error = NULL,
    updated_at = now()
WHERE customer.status <> 'retired'
  AND customer.provisioning_status NOT IN ('deleting', 'deletion_error')
  AND NOT EXISTS (
    SELECT 1 FROM customer_services AS service
    WHERE service.customer_id = customer.id AND service.status <> 'retired'
  );
