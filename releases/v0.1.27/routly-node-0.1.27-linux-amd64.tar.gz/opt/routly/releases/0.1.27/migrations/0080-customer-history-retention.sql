ALTER TABLE customers ADD COLUMN IF NOT EXISTS deleted_at timestamptz;
