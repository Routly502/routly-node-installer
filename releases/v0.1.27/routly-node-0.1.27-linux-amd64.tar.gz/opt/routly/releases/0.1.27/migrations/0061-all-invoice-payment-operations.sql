CREATE TABLE all_invoice_payment_operations (
  operation_id text PRIMARY KEY,
  customer_id integer NOT NULL,
  created_by_user_id integer NOT NULL,
  request_hash text NOT NULL,
  result_snapshot jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
