#!/usr/bin/env bash
# Local TLS belongs to the ISP, outside the package-managed HTTP site.
set -euo pipefail
umask 022
DOMAIN=${1:-}
ROOT=
BIN=/usr/sbin
if [[ ${ROUTLY_TEST_MODE:-0} == 1 ]]; then
  ROOT=${ROUTLY_FILESYSTEM_ROOT:?A temporary test root is required}
  [[ "$ROOT" == /tmp/routly-https-* ]] || { echo "Unsafe test root" >&2; exit 1; }
  BIN=${ROUTLY_HTTPS_TEST_BIN:?Test commands are required}
else
  [[ $EUID == 0 ]] || { echo "Ejecute con sudo." >&2; exit 1; }
fi
fail() { printf 'HTTPS: %s\n' "$*" >&2; exit 1; }

python3 - "$DOMAIN" <<'PY'
import ipaddress, re, sys
domain = sys.argv[1]
labels = domain.split(".")
if (len(domain) > 253 or len(labels) < 2 or domain != domain.lower()
    or any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) for label in labels)):
    raise SystemExit("Indique solo el dominio público, sin https:// ni rutas.")
try:
    ipaddress.ip_address(domain)
except ValueError:
    pass
else:
    raise SystemExit("Use un dominio público, no una dirección IP.")
PY

NGINX="$BIN/nginx"
CERTBOT=/usr/bin/certbot
APT=/usr/bin/apt-get
SYSTEMCTL=/usr/bin/systemctl
if [[ ${ROUTLY_TEST_MODE:-0} == 1 ]]; then
  CERTBOT="$BIN/certbot"; APT="$BIN/apt-get"; SYSTEMCTL="$BIN/systemctl"
fi
AVAILABLE="$ROOT/etc/nginx/sites-available/routly-local-https.conf"
ENABLED="$ROOT/etc/nginx/sites-enabled/routly-local-https.conf"
CERT="$ROOT/etc/letsencrypt/live/$DOMAIN"
SOURCE="$ROOT/etc/nginx/sites-available/routly.conf"
[[ -f "$SOURCE" && ! -L "$SOURCE" ]] || fail "Falta el sitio HTTP de Routly."
[[ ! -L "$AVAILABLE" ]] || fail "La configuración HTTPS es un enlace inesperado."
if [[ -e "$ENABLED" || -L "$ENABLED" ]]; then
  [[ -L "$ENABLED" && "$(readlink "$ENABLED")" == /etc/nginx/sites-available/routly-local-https.conf ]] ||
    fail "Ya existe otro sitio HTTPS; no se modificó."
fi

# Interactive Certbot asks for email and explicit acceptance of its terms.
# Unattended installation needs the operator's explicit consent instead.
CERTBOT_ARGS=(certonly --nginx --cert-name "$DOMAIN" -d "$DOMAIN")
INTERACTIVE=0
if [[ ! -s "$CERT/fullchain.pem" || ! -s "$CERT/privkey.pem" ]]; then
  if [[ ${ROUTLY_HTTPS_AGREE_TOS:-0} == 1 && -n ${ROUTLY_HTTPS_EMAIL:-} ]]; then
    [[ "$ROUTLY_HTTPS_EMAIL" != -* && "$ROUTLY_HTTPS_EMAIL" == *@* &&
       "$ROUTLY_HTTPS_EMAIL" != *[$'\r\n ']* ]] || fail "Correo de certificado inválido."
    CERTBOT_ARGS+=(--non-interactive --agree-tos --email "$ROUTLY_HTTPS_EMAIL")
  elif [[ ${ROUTLY_TEST_MODE:-0} != 1 ]] && ( : </dev/tty ) 2>/dev/null; then
    INTERACTIVE=1
  else
    fail "Se requiere una terminal para aceptar las condiciones del certificado, o ROUTLY_HTTPS_EMAIL y ROUTLY_HTTPS_AGREE_TOS=1."
  fi
  "$APT" update
  "$APT" install -y --no-install-recommends certbot python3-certbot-nginx
  if [[ $INTERACTIVE == 1 ]]; then
    "$CERTBOT" "${CERTBOT_ARGS[@]}" </dev/tty
  else
    "$CERTBOT" "${CERTBOT_ARGS[@]}"
  fi
fi
[[ -s "$CERT/fullchain.pem" && -s "$CERT/privkey.pem" ]] || fail "No se obtuvo el certificado; HTTP sigue disponible."

CREATED=0
[[ -e "$AVAILABLE" ]] || CREATED=1
python3 - "$ROOT" "$DOMAIN" <<'PY'
from pathlib import Path
import sys
root, domain = sys.argv[1:]
source = Path(root + "/etc/nginx/sites-available/routly.conf").read_text()
for expected in ("listen 80;", "server_name _;"):
    if source.count(expected) != 1:
        raise SystemExit("El sitio HTTP de Routly no coincide; no se modificó.")
tls = f"""listen 443 ssl;
    ssl_certificate /etc/letsencrypt/live/{domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/{domain}/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;"""
result = source.replace("listen 80;", tls, 1).replace("server_name _;", f"server_name {domain};", 1)
target = Path(root + "/etc/nginx/sites-available/routly-local-https.conf")
if target.exists():
    if target.read_text() != result:
        raise SystemExit("El sitio HTTPS tiene ajustes propios; no se sobrescribió.")
else:
    with target.open("x") as output:
        output.write(result)
    target.chmod(0o644)
PY
mkdir -p "$(dirname "$ENABLED")"
ln -sfn /etc/nginx/sites-available/routly-local-https.conf "$ENABLED"
if ! "$NGINX" -t; then
  if [[ $CREATED == 1 ]]; then rm -f -- "$ENABLED" "$AVAILABLE"; fi
  fail "Nginx rechazó HTTPS. No se recargó el servicio."
fi
HOOK="$ROOT/etc/letsencrypt/renewal-hooks/deploy/routly-local-https"
mkdir -p "$(dirname "$HOOK")"
[[ ! -L "$HOOK" ]] || fail "El hook de renovación es un enlace inesperado."
HOOK_BODY=$'#!/bin/sh\nset -e\n/usr/sbin/nginx -t\n/usr/bin/systemctl reload nginx'
if [[ -e "$HOOK" ]]; then
  [[ "$(cat "$HOOK")" == "$HOOK_BODY" ]] || fail "El hook tiene ajustes propios; no se sobrescribió."
else
  printf '%s\n' "$HOOK_BODY" > "$HOOK"
fi
chmod 0755 "$HOOK"
"$SYSTEMCTL" reload nginx
printf 'HTTPS listo: https://%s/admin/\n' "$DOMAIN"
